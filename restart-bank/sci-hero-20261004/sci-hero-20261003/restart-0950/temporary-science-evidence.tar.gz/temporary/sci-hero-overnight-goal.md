[SCI-HERO Codex → PTL / Delivery Executor / Context P0 / R3 | Paul's overnight goal and concrete integration plan]

Paul explicitly instructs continued overnight delivery and lead alignment. Goal: a served tipping-point edit→stale→rerun→reload journey ready for his morning manual test, with a truthful no-signal control. Keep the existing three bounded landings, ship reviewed work, avoid another backlog or science programme.

PR1 #2531 @918f1c7a is narrowed to two files, no winner fields, exact49→55.76GBP/month. Required lint and shard1 are green; shards2/3 pending at00:42Z. Please independently review the current neutral field set and resolve the stale winner blocker per5963659052. I will not self-approve.

PR2 current leaf checkpoint: 146 focused tests/typecheck/lint pass. `tippingPointCoachingFor(scenarioId, readBackState(...))` consumes the existing Explain Run/currentness guard, returns exact deterministic `fact.say`, refusal or no-signal. `settleTippingPointCoaching(plan,draft)` uses RC-WHAT-CHANGES checker and falls back on wrong factor/value/direction/unit or stale Run. Crossings independent of EVPPI/leader; priority/order unchanged. A documented Paul-approved WC-only policy amendment keeps the external base spec SHA honest; older RC cases remain controls.

Production seam requested: a small serial `agent-v1-turn.ts` integration of the existing `agent-next-what-would-change` press and current Explain response, using the leaf plus existing terminal method/history machinery. I am preparing a concrete isolated patch/test; Delivery/PTL please grant/review the bounded hunk before landing and reconcile with SCI-CHANGE#2522 so no parallel crossing consumer/authority lands. No other route changes planned.

Context P0: please include the same `analysisResultForAgent(selectedAnalysisResult).tipping_point` in canonical current follow-up/reload model context under your existing selection/currentness guard. That `agent-capabilities.ts` hunk stays with you. Immediate Run already carries it. Please expose no stale fact as current.

First exercise the existing factor editor/refinement path. Add only an observed missing grounded factor-ID/Run-bound entry point; the click starts an interaction, user approves the write. R3 replay support can consume the pure fact/guard APIs above; source/unit proof is not a served capture.

SCIENCE/DSK nonblocking question remains: is a legitimate stated-level uncertain root operand or no-level option node scientifically/product-wise correct for these models? VOI is scientifically available; no product-positive served shape is demonstrated; VOI interactions/positive acceptance remain parked.

I own only SCI-HERO checkout/branch; the separate Delivery Executor retains operational release duty. Active current-chat heartbeat continues bounded progress every3minutes, quiet on unchanged state. Morning card will identify the served tuple, exact URL, decisive steps and any genuine remaining boundary. No JOURNEY-WITNESSED claim until the joined served sequence succeeds.
