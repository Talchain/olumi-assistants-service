import { useEffect, useRef, useState, useCallback } from 'react'
import { Share2, Users, UserPlus, AlertTriangle, CheckCircle, XCircle } from 'lucide-react'
import Tooltip from '../Tooltip'
import styles from './TopBar.module.css'
import { UserAvatarMenu } from './UserAvatarMenu'
import { KebabMenu } from './KebabMenu'
import { ScenarioSwitcher } from '../../canvas/components/ScenarioSwitcher'
import { SCENARIO_RENAME_REQUEST_EVENT } from '../../canvas/components/scenarioRenameEvent'
import { VersionsTrigger } from '../../canvas/versions/VersionsTrigger'
import { DecisionBriefTrigger } from '../../canvas/decisionBrief/DecisionBriefTrigger'
import { ownerPanelHash } from '../../collab/panelRoute'
import { MENU_EXCLUSIVE_EVENT } from './LeftSidebar'
import { useUIStore } from '../../stores/uiStore'
import { useIsConfirmedOwner, useIsViewer } from '../../lib/viewerMode'
import { ShareDecisionDialog } from '../sharing/ShareDecisionDialog'

// Custom events for help actions (communicated to ReactFlowGraph)
// Lane 4 (P5): SHOW_ONBOARDING removed — its only dispatcher was the kebab
// "Replay tour" item, which fired into an overlay gated off in every deploy
// context (a control that lied). ReactFlowGraph's literal
// 'topbar:show-onboarding' listener + gated overlay remain as dead code;
// retire-or-revive is a rowed follow-up.
export const HELP_EVENTS = {
  SHOW_KEYBOARD_LEGEND: 'topbar:show-keyboard-legend',
  SHOW_INFLUENCE_EXPLAINER: 'topbar:show-influence-explainer',
  SHOW_TOAST: 'topbar:show-toast',
} as const

interface TopBarProps {
  scenarioTitle: string
  onTitleChange: (title: string) => void
  onSave?: () => Promise<void>
  onShare?: () => void
  isDirty?: boolean
  // C.1a: Supabase persistence status
  saveStatus?: 'saved' | 'saving' | 'error'
  saveError?: string | null
  isPersisted?: boolean
  /**
   * COLLAB: when a PERSISTED scenario is on the canvas, its id — and the bar
   * shows the "Ask your team" entry to the blind-panel owner page. Null/absent
   * hides it: a guest scenario cannot mint a round (CEE refuses — no immutable
   * model version to pin), so showing the entry would be a control that lies.
   */
  panelScenarioId?: string | null
  /**
   * SHARE: when a PERSISTED scenario is on the canvas, its id — and the bar
   * shows the Share control. Null/absent hides it, and that is the whole fix.
   *
   * A guest (or unsaved) canvas has no server-side brief to point at, so the
   * old fallback copied `#/canvas?run=<hash>` — a hash that only resolves
   * against the SENDER's device history (`shareLink.ts`: "local-device only").
   * The copy SUCCEEDED, so it read as a working share, and the empty canvas
   * turned up on a SECOND person's screen. Before a run there was no hash at
   * all and the click did nothing but `console.warn`.
   *
   * Same shape and same reasoning as `panelScenarioId` above: a control that
   * cannot do what it says is not shown.
   */
  shareScenarioId?: string | null
}

/**
 * The top-left pill (Paul, 1 Oct 2026 — see `TopBar.module.css`): 12px from the top, 40px tall, so its bottom edge
 * is 52px. ⚠ NOT a band across the screen any more: `--topbar-h` stays 0 and the dock/canvas start at the top; only
 * the top-LEFT column clears this edge, via `--chrome-top-left`.
 */
export const TOP_PILL_TOP_PX = 12
export const TOP_PILL_HEIGHT_PX = 40
export const TOP_PILL_BOTTOM_PX = TOP_PILL_TOP_PX + TOP_PILL_HEIGHT_PX
/** @deprecated The full-width bar is gone; `--topbar-h` is 0. Kept for one cycle so no reader breaks silently. */
export const TOP_BAR_HEIGHT_PX = 0

export const TopBar = ({
  scenarioTitle,
  onTitleChange,
  onSave,
  onShare,
  isDirty = false,
  saveStatus,
  saveError,
  isPersisted = false,
  panelScenarioId = null,
  shareScenarioId = null,
}: TopBarProps) => {
  const [showSavedPill, setShowSavedPill] = useState(false)
  const isViewer = useIsViewer()
  const isConfirmedOwner = useIsConfirmedOwner()
  const [inviteOpen, setInviteOpen] = useState(false)

  // The kebab menu's open-state lives in uiStore, NOT in component-local
  // `useState`. That is the whole point: `applyV5State` dispatches the AI's
  // ui_directive verbs from a once-per-envelope, non-render side-effect site
  // whose only reach into the UI is `useUIStore.getState()`. A `useState`
  // here made menus, pop-ups and coach-marks structurally unreachable to any
  // assistant gesture. Both selectors return primitives, so no useShallow is
  // needed and no fresh object is created per render.
  const showMenu = useUIStore(s => s.activeOverlaySurface === 'top_bar_menu')
  const overlayOrigin = useUIStore(s => s.overlaySurfaceOrigin)
  const setOverlaySurface = useUIStore(s => s.setOverlaySurface)
  const closeMenu = useCallback(() => {
    // Close only OUR surface. Without this check a stray close would lower
    // whichever surface happened to be raised — including one this component
    // does not own.
    if (useUIStore.getState().activeOverlaySurface === 'top_bar_menu') {
      setOverlaySurface(null)
    }
  }, [setOverlaySurface])

  const menuRef = useRef<HTMLDivElement | null>(null)

  // C.1a: Auto-fade "Saved" pill after 2s
  const prevSaveStatusRef = useRef(saveStatus)
  useEffect(() => {
    if (saveStatus === 'saved' && prevSaveStatusRef.current === 'saving') {
      setShowSavedPill(true)
      const timer = setTimeout(() => setShowSavedPill(false), 2000)
      return () => clearTimeout(timer)
    }
    if (saveStatus === 'saving') {
      setShowSavedPill(false)
    }
    prevSaveStatusRef.current = saveStatus
  }, [saveStatus])

  // The pill covers only the top-LEFT corner, so `--topbar-h` (a band across the whole screen) stays 0 and the dock
  // runs the full height. The pill's bottom edge is published as `--chrome-top-left` for the top-left column only:
  // the canvas tools, the left inspector and the top-centre notices sit below it.
  useEffect(() => {
    if (typeof document === 'undefined') return
    const root = document.documentElement
    const previous = root.style.getPropertyValue('--chrome-top-left')
    root.style.setProperty('--chrome-top-left', `${TOP_PILL_BOTTOM_PX}px`)
    return () => {
      root.style.setProperty('--chrome-top-left', previous || '0px')
    }
  }, [])

  const handleSave = async () => {
    if (!onSave) return
    try {
      await onSave()
    } catch (error) {
      // eslint-disable-next-line no-console
      console.error('Save failed:', error)
    }
  }

  // USER AGENCY over an assistant-raised surface. These dismissals are
  // deliberately unconditional on WHO raised the menu: the assistant may put
  // it on screen, and Escape / click-outside must always take it back.
  useEffect(() => {
    if (!showMenu) return

    const handleClickOutside = (event: MouseEvent) => {
      if (!menuRef.current) return
      if (!menuRef.current.contains(event.target as Node)) {
        closeMenu()
      }
    }

    const handleEscapeKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        closeMenu()
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    document.addEventListener('keydown', handleEscapeKey)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
      document.removeEventListener('keydown', handleEscapeKey)
    }
  }, [showMenu, closeMenu])

  // Close kebab menu when another menu claims exclusivity
  useEffect(() => {
    const handler = (e: Event) => {
      const source = (e as CustomEvent).detail?.source
      if (source !== 'kebab') closeMenu()
    }
    window.addEventListener(MENU_EXCLUSIVE_EVENT, handler)
    return () => window.removeEventListener(MENU_EXCLUSIVE_EVENT, handler)
  }, [closeMenu])

  // KEEP THE STORE TRUTHFUL ABOUT WHAT IS ON SCREEN. An overlay surface is
  // anchored to a control; if that control is not mounted, a raised surface is
  // a claim the screen does not support. Component-local `useState` gave this
  // for free — it died with the component. A store does not, so the owner of a
  // surface must lower it on unmount, or a route change would leave the store
  // asserting a menu that no longer exists (and the next mount would paint it
  // open). Unmount-only: nothing is cleared while the bar is alive, so an
  // assistant gesture is never swallowed mid-session.
  // Empty deps on purpose: this must be strictly unmount-only, so it reads the
  // store directly rather than closing over an action whose identity could
  // drift and turn the cleanup into a mid-life dismissal.
  useEffect(
    () => () => {
      if (useUIStore.getState().activeOverlaySurface === 'top_bar_menu') {
        useUIStore.getState().setOverlaySurface(null)
      }
    },
    [],
  )

  // Claim exclusivity whenever OUR menu becomes raised — by a user click OR by
  // an assistant gesture that never passes through a click handler. Announcing
  // from the state transition rather than from `onToggle` is what makes the two
  // paths equivalent; sibling menus (LeftSidebar's lens, UserAvatarMenu) still
  // own their state and only learn about us through this event.
  useEffect(() => {
    if (!showMenu) return
    window.dispatchEvent(
      new CustomEvent(MENU_EXCLUSIVE_EVENT, { detail: { source: 'kebab' } }),
    )
  }, [showMenu])

  // Help action handlers - emit custom events for ReactFlowGraph to handle
  const handleShowKeyboardLegend = useCallback(() => {
    window.dispatchEvent(new CustomEvent(HELP_EVENTS.SHOW_KEYBOARD_LEGEND))
    closeMenu()
  }, [closeMenu])

  const handleShowInfluenceExplainer = useCallback(() => {
    window.dispatchEvent(new CustomEvent(HELP_EVENTS.SHOW_INFLUENCE_EXPLAINER))
    closeMenu()
  }, [closeMenu])

  // Decision Graph Display v2 Task 13: Analysis metadata
  // A.15: Stage lifecycle pill

  // `data-overlay-origin` is present only while an overlay this bar owns is
  // raised, and names WHO raised it. A surface the assistant put on screen must
  // be attributable rather than appearing to move on its own; this is the hook
  // a visible attribution (and any browser-level check) binds to.
  return (
    <div
      className={styles.topBar}
      role="banner"
      {...(showMenu && overlayOrigin ? { 'data-overlay-origin': overlayOrigin } : {})}
    >
      {/* Left section - logo and title */}
      <div className={styles.topBarLeft}>
        <a href="/" className={styles.logoLink} aria-label="Olumi home">
          <img
            src="/olumi-logo.png"
            alt="Olumi"
            className={styles.logo}
          />
        </a>

        {/* contract v3.1 `.app-top`: logo and model title are spaced by the
            bar's 20px gap — no divider rule between them. */}

        {/* ⭐ THE SINGLE MODEL-NAME CONTROL (Paul, 14 Aug 2026).
            This bar used to render a plain title here AND the switcher below
            it — two controls, both reading "Untitled decision". The plain title
            is removed; the switcher now displays the name this bar is given and
            commits renames through `onTitleChange`, which reaches the framing
            title (-> Supabase) as well as the localStorage record. It also
            still carries scenario switching, save-as, duplicate, delete and
            scenario export/import (.olumi.json). */}
        {/* ACCOUNTS viewer mode: a decision shared WITH this user is view-only. The
            switcher renames, duplicates and deletes, so a viewer gets the name and
            a plain "View only" tag instead (server refuses those writes anyway). */}
        {isViewer ? (
          <>
            <span className="text-sm font-medium text-text-header truncate max-w-[40vw]" data-testid="topbar-viewer-title">
              {scenarioTitle}
            </span>
            <span
              className="text-xs text-text-light px-2 py-0.5 rounded-pill border border-[rgba(38,38,38,0.16)] whitespace-nowrap"
              data-testid="topbar-view-only"
            >
              View only · shared with you
            </span>
          </>
        ) : (
          <ScenarioSwitcher
            dropdownPosition="below"
            displayName={scenarioTitle}
            onRename={onTitleChange}
            // A persisted session's decisions live in Supabase; this control's
            // list/switch/delete read and write localStorage, so they steer the
            // wrong collection there. `ScenarioListPage` is the single owner.
            isPersisted={isPersisted}
          />
        )}

        {/* Dirty indicator (localStorage mode only) */}
        {!isPersisted && isDirty && saveStatus !== 'saving' && (
          <span className={styles.dirtyIndicator} aria-label="Unsaved changes" />
        )}

      </div>

      {/* ⭐ THE CENTRE CHIPS ARE GONE (Paul, 31 Aug 2026).
          This slot carried four readouts — the stage lifecycle pill, the
          scenario count, a Stable/Sensitive stability pill and the last-run
          time. Paul's ruling: *"keep that top menu very simple unless there is
          genuinely valuable information in having something within it"*, and
          "all that type of information for the moment should be in the
          right-hand panel".

          ⚠ NOTHING IS LOST, CHECKED BEFORE DELETING. Every fact here already
          renders in the right-hand panel: the verdict via `AtAGlance`'s tone
          pill and `OptionCards`, the scenario count via `WinGauge`,
          `HowComputedModal` and `certaintyCopy`. This removes a duplicate
          readout, not a source. */}

      {/* Right section */}
      <div className={styles.topBarRight}>
        {/* Save status indicator (replaces save button) */}
        {isPersisted && (() => {
          const isClickable = (saveStatus === 'error') || (isDirty && saveStatus !== 'saving')
          const handleClick = isClickable ? handleSave : undefined

          if (saveStatus === 'saving') {
            return (
              <span className={styles.saveStatus} role="status" aria-live="polite">
                <span className="inline-block w-3 h-3 border-[1.5px] border-current border-t-transparent rounded-full animate-spin text-text-light" aria-hidden="true" />
                <span className="text-text-light">Saving{'\u2026'}</span>
              </span>
            )
          }
          if (saveStatus === 'saved' && showSavedPill) {
            return (
              <span className={styles.saveStatus} role="status" aria-live="polite">
                <CheckCircle size={12} className="text-text-light" aria-hidden="true" />
                <span className="text-text-light">Saved</span>
              </span>
            )
          }
          if (saveStatus === 'error') {
            return (
              <button
                type="button"
                className={`${styles.saveStatus} ${styles.saveStatusClickable}`}
                role="status"
                aria-live="polite"
                onClick={handleClick}
                title={saveError ?? 'Save failed'}
              >
                <XCircle size={12} className="text-danger" aria-hidden="true" />
                <span className="text-danger">Save failed</span>
              </button>
            )
          }
          if (isDirty) {
            return (
              <button
                type="button"
                className={`${styles.saveStatus} ${styles.saveStatusClickable}`}
                role="status"
                aria-live="polite"
                onClick={handleClick}
              >
                <AlertTriangle size={12} className="text-warning" aria-hidden="true" />
                <span className="text-warning">Unsaved</span>
              </button>
            )
          }
          return null
        })()}

        {/* COLLAB: entry to the blind-panel owner page — previously URL-only.
            An anchor, not a navigate(): the app is a HashRouter and this is
            the same pattern as the logo link, so middle-click/new-tab work.
            Rendered only for a persisted scenario (see the prop's doc). */}
        {panelScenarioId != null && panelScenarioId !== '' && (
          <Tooltip content="Ask your team — everyone answers privately, then compare">
            <a
              href={ownerPanelHash(panelScenarioId)}
              className={`${styles.iconButton} ${styles.labelledButton}`}
              // ⚠ THE `aria-label` STAYS EVEN THOUGH THE TEXT IS NOW VISIBLE,
              // and it must keep MATCHING the visible text: it is what makes
              // the accessible name stable if the label is ever shortened, and
              // an accessible name that disagrees with the visible one breaks
              // voice control ("click Ask your team").
              aria-label="Ask your team"
              data-testid="topbar-panel-link"
            >
              <Users size={14} aria-hidden="true" />
              {/* ⭐ VISIBLE LABEL (29 Aug 2026). This was a bare 14px glyph
                  labelled only by `aria-label` and the tooltip above — and it
                  is one of two entry points to blind panel elicitation, the
                  most differentiated capability we ship. Unsupervised, nobody
                  hovers an unexplained icon to find out what it does. */}
              <span>Ask your team</span>
            </a>
          </Tooltip>
        )}

        {/* ⭐ SHARE — ONLY WHEN THE LINK CARRIES THE DECISION (29 Aug 2026).
            Gated exactly like "Ask your team" above: a guest or unsaved canvas
            has no shared brief to link to, and the old fallback copied a
            device-local hash that opened EMPTY for the recipient. The tooltip
            now states what the link carries, because "Generate shareable link"
            was equally true of the link that carried nothing. */}
        {shareScenarioId != null && shareScenarioId !== '' && (
          <Tooltip content="Copy a link to this decision's brief — anyone with the link can open it">
            <button
              type="button"
              onClick={onShare}
              className={styles.shareButton}
              aria-label="Copy link to decision brief"
              data-testid="topbar-share"
            >
              <Share2 size={14} aria-hidden="true" />
            </button>
          </Tooltip>
        )}

        {/* ACCOUNTS "Invite a colleague" (view only): the owner's in-decision entry, beside
            the brief link. Shown only on a CONFIRMED 'owner' answer from scenario_access,
            never while that answer is pending (Codex R4): a viewer's canvas can hold the
            scenario id before its access lands. The server enforces ownership too. */}
        {isConfirmedOwner && shareScenarioId != null && shareScenarioId !== '' && (
          <Tooltip content="Invite a colleague to view this decision">
            <button
              type="button"
              onClick={() => setInviteOpen(true)}
              className={styles.shareButton}
              aria-label="Invite a colleague to view this decision"
              data-testid="topbar-invite"
            >
              <UserPlus size={14} aria-hidden="true" />
            </button>
          </Tooltip>
        )}
        {inviteOpen && isConfirmedOwner && shareScenarioId != null && shareScenarioId !== '' && (
          <ShareDecisionDialog
            scenarioId={shareScenarioId}
            scenarioTitle={scenarioTitle}
            onClose={() => setInviteOpen(false)}
          />
        )}

        {/* ⭐ VERSION HISTORY — THE REAL CONTROL (R4, Paul, 16 Aug 2026).
            This button used to be a LIE: it said "coming soon" and fired an
            informational toast, while the fully built versions feature was
            mounted 57px below it as a floating pill over the canvas (ledger
            L-08). Two controls for one capability, one of them denying the
            capability existed.
            The floating pill is retired and this is now the capability's home:
            history belongs beside the model name and share, with the other
            document-level controls, not hovering over the graph. `VersionsTrigger`
            carries no positioning of its own — this row owns its layout. */}
        {/* Versions are owner-only on CEE (list, save, restore): hidden for a viewer. */}
        {!isViewer && (
          <Tooltip content="Version history — snapshots of the model you authored">
            <VersionsTrigger variant="icon" className={styles.iconButton} data-testid="topbar-versions-trigger" />
          </Tooltip>
        )}

        {/* DECISION BRIEF — the saved model and its latest Run as one shareable page (self-contained; renders
            nothing for a scenario CEE cannot read). */}
        <Tooltip content="Decision brief: the saved model and its latest Run, to print or share">
          <DecisionBriefTrigger className={styles.iconButton} />
        </Tooltip>

        {/* Kebab menu */}
        <KebabMenu
          isOpen={showMenu}
          onToggle={() => {
            // The exclusivity announcement rides the state transition (effect
            // above), so the user path and the assistant path behave alike.
            setOverlaySurface(showMenu ? null : 'top_bar_menu')
          }}
          onClose={closeMenu}
          // The name control is a SIBLING now, not this bar's own state, so the
          // request travels by the same window-event idiom the bar already uses
          // for its other cross-component signals.
          onStartRename={() => {
            window.dispatchEvent(new CustomEvent(SCENARIO_RENAME_REQUEST_EVENT))
            closeMenu()
          }}
          onShowKeyboardLegend={handleShowKeyboardLegend}
          onShowInfluenceExplainer={handleShowInfluenceExplainer}
          menuRef={menuRef}
        />

        {/* User avatar + account dropdown — contract `.app-top .avatar`, 26px. */}
        <div className={styles.avatarSlot}>
          <UserAvatarMenu size="compact" />
        </div>
      </div>
    </div>
  )
}
