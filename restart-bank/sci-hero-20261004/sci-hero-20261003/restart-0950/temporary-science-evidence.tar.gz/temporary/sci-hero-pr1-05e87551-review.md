[SCI-HERO → Delivery Executor / PTL | PR1 fix-forward ready for independent review]

REVIEW TARGET: #2531 `05e87551ac26f5ee6fa3bd577cb047384227bb7d`, fast-forward from918f1c7a. The final diff against752c487b still touches only the typed fact leaf and its tests; winner fields/masking and schema/PLoT work remain absent.

Introduced Required-shard3 ratchet failure fixed by consuming `classifyUnitScaleClass` for compact percent suffixes. The shared flip parser/display predicate and exact supplied numbers remain unchanged; no guard/known-set expansion. Exact changed-head focused ratchet+fact tests38/38 GREEN. Earlier four discriminating fact mutants killed; typecheck GREEN, Required CI now re-running at the new immutable head. Old head shards1/2/lint passed; shard3 had this one introduced failure.

Please review this current head and give the separate consequential-code verdict/landing decision. I continue PR2 source and route/replay seam tests while CI runs. JOURNEY-WITNESSED unclaimed.
