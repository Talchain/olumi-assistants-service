import { goalScopeClaimInput } from '../orchestrator-v5/compose/goal-scope-claim-input.js';
import { claimPermissionsFrom } from '../orchestrator-v5/agent-lane/first-analysis.js';
/**
 * ROADMAP 2.312 track 2 (2) — THE SCENARIO-ADDRESSED GRAPH READ.
 *
 * CEE owns the ONLY live reader of `scenarios.graph`
 * (`supabase-store.ts::loadGraphAndBriefText`) and, until this route, exposed no
 * scenario-addressed way to reach it: every existing caller is an internal
 * turn-context builder. The guest tier can never read the graph directly —
 * `REVOKE ALL ON scenarios FROM anon` stands and is NOT loosened by this work.
 * This route is the CEE-mediated substitute: the browser asks CEE, CEE asks
 * Supabase with the service role, and the browser never touches Supabase.
 *
 * ── WHY POST FOR A READ (the convention DEMANDS it; this is not a preference) ─
 * Two independent reasons, both derived at the tip WHEN WRITTEN. (1)'s premise
 * has since moved and is corrected in place beneath it; (2) is unaffected and is
 * sufficient on its own.
 *
 *   1. IDENTITY LIVES IN THE BODY. `CEE_REQUIRE_USER_JWT` is off on staging, so
 *      `resolveUserIdentity` returns `mode: "off"` and `authorizeScenarioOwnership`
 *      falls back to the CALLER-SUPPLIED `user_id` — which the shared parser
 *      (`parseRequestExtensions`) reads from the request BODY. A GET has no body,
 *      so `claimedUserId` would be null on every request, and a null caller
 *      against a stored owner is precisely the IDOR case the pre-flight refuses.
 *      Every OWNED scenario would be permanently unreadable by its own owner.
 *
 *      ⚠⚠ THE PREMISE OF (1) NO LONGER HOLDS. THE PARAGRAPH ABOVE IS LEFT
 *         STANDING ON PURPOSE — it is an accurate record of the deployment it
 *         was written against, it is FALSE about the deployment today, and both
 *         halves are load-bearing: it is WHY this route is a POST, so a tidy
 *         rewrite would hide that a premise which no longer holds once governed
 *         the shape of the route.
 *
 *         WHEN WRITTEN — staging deployed `CEE_REQUIRE_USER_JWT` OFF, so
 *         `resolveUserIdentity` answered `mode: "off"` and the body-supplied
 *         `user_id` was the only identity this route had.
 *
 *         TODAY (26 Aug 2026) — staging deploys it ON.
 *
 *         HOW THAT WAS ESTABLISHED — BEHAVIOURALLY, at the DEPLOYED build. Not
 *         from `render.yaml`, not from this comment, not from any prose: the
 *         YAML is a drifting subset of the Render dashboard and has been wrong
 *         about this class of question before (trap 18). Witnessed on this
 *         route: a real user token resolves as a VERIFIED SUBJECT and reads a
 *         scenario that subject owns, while a caller presenting no verified
 *         identity is answered the ordinary refusal. Ownership on this surface
 *         is therefore the verified token subject, and a request-supplied
 *         identifier is not an input to it — see
 *         `CALLER_ASSERTED_IDENTITY_NOT_ADMISSIBLE` at the call site below.
 *
 *         ⚠ DO NOT CITE (1) AS AN ARGUMENT ABOUT THE CURRENT DEPLOYMENT. Its
 *           conclusion — "every OWNED scenario would be permanently unreadable
 *           by its own owner" — follows from the flag being OFF and does not
 *           follow while it is ON. A reviewer reading (1) in good faith as a
 *           live statement would reach the wrong verdict about this file.
 *
 *         ⚠⚠ BUT (1)'s CONCLUSION IS NOW THE FLAG-OFF STATE, AND THE FLAG IS
 *            NO LONGER A ROLLBACK LEVER. Ownership on this surface is the
 *            verified token subject ALONE, so CEE_REQUIRE_USER_JWT is
 *            load-bearing, not optional. It defaults to FALSE
 *            (config/index.ts), and nothing in the config layer guards that
 *            direction — the only refine on it fires when it is TRUE. With it
 *            off, every OWNED scenario is refused to its OWN owner across all
 *            six /assist/v1/scenarios/* endpoints, reads and writes alike.
 *            Staging deploys it ON today (witnessed above), so this is about
 *            the DEFAULT and about anyone reaching for the flag in an
 *            incident — not a live outage. Disclosed at boot
 *            (`config.scenario_ownership_posture`, server.ts) and pinned in
 *            the suite as a KNOWN MISCONFIGURATION rather than as correct
 *            behaviour.
 *
 *         WHAT DOES NOT CHANGE — the route stays a POST. Reason (2) below never
 *         depended on the flag, is sufficient on its own, and the method is
 *         part of a shipped wire contract the UI already builds against.
 *
 *         ⚠ AND RE-DERIVE THIS BEFORE YOU RELY ON IT. A flag posture written
 *           into a comment is a hand-maintained mirror of a dashboard value
 *           (trap 12) — which is exactly how (1) came to be false here. The
 *           dated sentence above is a record of a measurement, never a
 *           standing guarantee, and that applies to this sentence too.
 *
 *   2. THE ALTERNATIVE PUTS A USER ID IN A URL. Carrying `user_id` as a query
 *      parameter would write an account identifier into proxy logs, browser
 *      history and referrers. Not acceptable for an identifier that is the
 *      authorization input.
 *
 * The scenario is still addressed in the PATH, so the route is scenario-addressed
 * in the sense that matters: one URL per scenario, cacheable to reason about,
 * and no graph is ever sent by the caller. Every other `/assist/v1/*` route is
 * POST, so this also matches the family it joins.
 *
 * ── THE UI REACHES THIS AS `/bff/cee/scenarios/:id/graph` ───────────────────
 * DERIVED from the UI's `cee-proxy` EDGE FUNCTION on its `staging` branch
 * (`netlify/edge-functions/cee-proxy.ts`, ROADMAP 2.317):
 *     config.path = "/bff/cee/*"      → target https://cee-staging.onrender.com
 *     pathname.replace(/^\/bff\/cee/, "/assist/v1")
 *     methods GET/HEAD/POST/OPTIONS   → POST is allowed
 *     injects X-Olumi-Assist-Key, forwards `authorization` (the user's
 *     Supabase token, which is what this route's identity step reads — this
 *     line said "will read once CEE_REQUIRE_USER_JWT is on", in the future
 *     tense, for the same reason (1) above is now wrong: it was written against
 *     a deployment where the flag was off)
 * The rewrite is a PREFIX replace, so the multi-segment
 * `/bff/cee/scenarios/<uuid>/graph` lands on
 * `/assist/v1/scenarios/<uuid>/graph`. The key never reaches the browser.
 *
 * ⚠ DO NOT RE-DERIVE THIS FROM `netlify.toml` ON THE UI'S `main` BRANCH — that
 *   is where this note first went wrong. `main` still carries the SUPERSEDED
 *   `[[redirects]]` pair, which (a) never executed at all (Netlify processes
 *   `public/_redirects` first, and its SPA catch-all `/* /index.html 200` won
 *   every time, so `/bff/cee/*` answered SPA HTML) and (b) named
 *   `olumi-assistants-service.onrender.com` — measured 3 Aug at
 *   `/v1/status`: version 1.11.1, uptime 9,936,008s (≈115 days), against CEE
 *   staging's 1.12.0. Wrong twice over. The edge function on `staging` is the
 *   live seam and it targets `cee-staging`, which is where this route deploys.
 *
 * ⚠ AND THAT IS EXACTLY WHY THE ASSIST KEY IS NOT AN AUTHORIZATION BOUNDARY
 *   HERE. The edge injects it for ANY visitor, so "holds a valid assist key"
 *   distinguishes nobody from anybody. The key gate (applied globally by
 *   `plugins/auth.ts` to every non-public route — this one included, by
 *   omission from `isPublicRoute`) stops anonymous internet traffic and does
 *   the per-key quota. USER separation is done below, by the same
 *   scenario-ownership pre-flight the turn route runs.
 *
 * ── THE ORDER OF THE CHECKS IS THE DESIGN ──────────────────────────────────
 *   0. identity      — headers only, no state read. FIRST, so that a refusal
 *                      status cannot become a scenario-existence oracle for a
 *                      caller presenting a deliberately bad token (the exact
 *                      regression turn-stop.ts had to hoist away).
 *   1. UUID syntax   — `scenarios.id` is a UUID column, so a non-UUID cannot
 *                      name a row. Refused without a round trip.
 *   2. EXISTENCE     — and it is before ownership FOR A REASON, see below.
 *   3. ownership     — the SAME two shared functions the turn route uses. No
 *                      second ownership rule is written in this file.
 *   4. the read      — only now, and only for a caller who passed 0–3.
 *
 * ⚠ (2) BEFORE (3) IS LOAD-BEARING: A READ MUST NEVER CREATE THE ROW IT READS.
 *   `authorizeScenarioOwnership` → `preflightEnsureScenario` →
 *   `ensureScenarioExists` runs `INSERT … ON CONFLICT (id) DO NOTHING`. Reached
 *   with an id that does not exist, it CREATES that scenario — so a stranger
 *   posting random UUIDs at a read endpoint would grow `scenarios` without
 *   bound. Gating on existence first makes the upsert a pure read (the row
 *   always already exists when it runs, so ON CONFLICT DO NOTHING does
 *   nothing) while still keeping ownership in the shared function where it
 *   belongs. turn-stop.ts ordered these two the same way for the same reason.
 *
 * ── EVERY REFUSAL ANSWERS THE SAME BYTES ───────────────────────────────────
 * "No such scenario", "not your scenario" and "ownership oracle unavailable"
 * are INDISTINGUISHABLE: one status, one code, one message. A refusal that
 * named its reason would hand any holder of a scenario UUID a free oracle over
 * which scenarios exist and who owns them — rebuilt one bit at a time. Guest
 * (unowned) scenarios stay addressable by anyone holding the UUID: that is the
 * accepted PoC posture, it is what the turn route already does, and it is what
 * makes PC5's guest tier work at all.
 *
 * ── RATE LIMITING, AND WHY THE BUCKET IS KEYED ON THE CLIENT ───────────────
 * The first cut of this route shipped with NO route-local limiter, arguing the
 * global `@fastify/rate-limit` (`global: true`) and the auth plugin's per-key
 * quota already covered it. Both of those are real and do apply — but CodeQL
 * flagged `js/missing-rate-limiting` HIGH ("this route handler performs
 * authorization, but is not rate-limited") and it was RIGHT to: every sibling
 * `/assist/v1/*` route carries one, and this is the only route in the estate
 * that returns another user's decision graph. A coarse global limiter is not
 * the same control as a per-route one on a data-read endpoint.
 *
 * It is applied as route-level `config.rateLimit` on the repo's own
 * `@fastify/rate-limit` registration (the `proxy-v5-turn.ts` stop-rung
 * pattern), NOT as a bespoke in-handler check — see the note at the config
 * itself for why that distinction earned its own revision.
 *
 * ⚠ THE BUCKET IS PER CLIENT (`req.ip`, the plugin default), deliberately —
 *   the inverse of the sibling routes' `keyId || req.ip`. Through the
 *   `/bff/cee/*` edge EVERY visitor arrives carrying the SAME injected assist
 *   key, so any key-derived bucket is a single shared-fate bucket in which one
 *   busy tab throttles every other user of the product. `req.ip` resolves from
 *   `x-forwarded-for` in production (`trustProxy: nodeEnv === "production"`),
 *   so it is per-visitor, which is also the granularity that actually limits
 *   the threat here: one host enumerating many scenario ids.
 *
 * ── WHAT THIS ROUTE DOES NOT DO ────────────────────────────────────────────
 * · It does not write. Not the graph, not the row, not a turn.
 * · It does not MINT AN IDENTITY SCHEME. `graph_identity_hash` is
 *   `computeGraphIdentityHash` — identity.v1, the single normaliser authority
 *   named by the CAS migration itself.
 *
 *   ⚠ IT IS AN OPAQUE CEE-ISSUED TOKEN. Consumers STORE it and compare it
 *     CEE-to-CEE, gated on `.projection_version`; they must NEVER recompute it
 *     locally. There is no client-side way to reproduce this value and no
 *     promise that there ever will be — the normalisation, the strip list and
 *     the projection are CEE's, and they are versioned precisely so they can
 *     move without a consumer noticing.
 *
 *   ⚠ AN EARLIER REVISION OF THIS COMMENT CLAIMED "the UI's rebase detection
 *     compares the same value CEE's own compare-and-swap does". THAT WAS FALSE
 *     and it was never measured — a claim about ANOTHER REPO'S live path,
 *     asserted from this side of the seam (CLAUDE.md trap 16). Verified at the
 *     bytes at UI tip `8d0f3a76` (`rg -a` over the whole repo, excluding
 *     `.git`): `graph_identity_hash` appears in ZERO files and
 *     `projection_version` in ZERO files. The UI's #561 detector is a
 *     VALUE comparison and hashes nothing; no compatible projection exists
 *     UI-side. The field is new surface for consumers to adopt, not a
 *     rendezvous with something already there.
 * · It does not carry layout. `scenarios.graph` holds no positions (the UI
 *   merges those locally), and `layout_present` REPORTS that by measuring the
 *   returned bytes rather than promising it in prose.
 */

import type { FastifyInstance } from "fastify";

import { parseRequestExtensions } from "../orchestrator-v5/boundary/request-extensions.js";
import type { GraphStateIngress } from "../orchestrator-v5/boundary/request-extensions.js";
import { deriveNotModelledManifest } from "../cee/context-integrity/not-modelled-manifest.js";
import {
  authorizeScenarioOwnership,
  CALLER_ASSERTED_IDENTITY_NOT_ADMISSIBLE,
  resolveVerifiedIdentityOrRefuse,
} from "../orchestrator/route-v2-preflight.js";
import { computeGraphIdentityHash } from "../orchestrator-v5/context/graph-identity.js";
import { computeAnalysisAffectingGraphHash } from "../orchestrator-v5/context/graph-hash.js";
import { getSessionStore } from "../orchestrator-v5/session/index.js";
import { scenarioAccessDecision } from '../orchestrator-v5/agent-lane/scenario-access.js';
import { resolveCeeRateLimit } from "../cee/config/limits.js";
import { buildErrorV1 } from "../utils/errors.js";
import { getRequestId } from "../utils/request-id.js";
import { log } from "../utils/telemetry.js";
// ROADMAP 2.1271 — the additive analysis payload. All composition lives in the
// helper; this route contributes the security ladder and the graph it read.
import { readScenarioAnalysis } from "./scenario-graph-analysis-read.js";
import { projectAnalysisAdmission } from './analysis-admission-projection.js';
import { isAgentAnswerRow } from "../orchestrator-v5/session/conversation-as-seen.js";

/** Wire schema discriminator. Frozen — the UI lane builds against this. */
export const SCENARIO_GRAPH_SCHEMA = "scenario_graph.v1" as const;

/**
 * `scenarios.id` is a UUID column, so a non-UUID id cannot name an existing
 * row. Same pattern and same rationale as turn-stop.ts.
 */
const UUID_PATTERN =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Keys that would mean canvas LAYOUT had been persisted into `scenarios.graph`.
 *
 * ⚠ THIS IS A HAND-WRITTEN LIST, AND IT KNOWS IT (trap 12d). Deriving
 * `layout_present` from a list proves the consumers agree with the list; it can
 * never prove the list is complete. So the list is deliberately INCLUSIVE — the
 * asymmetry runs one way: a false TRUE is a harmless over-report the UI can
 * ignore, a false FALSE is a promise of "no layout" made over bytes that carry
 * it. Paired with a positive control in the spec that proves the derivation
 * fires at all, rather than passing by never firing.
 */
const LAYOUT_KEYS = new Set(["position", "positions", "layout", "x", "y"]);

/**
 * Does the graph we are about to return carry any layout/position data?
 *
 * MEASURED, NOT ASSERTED. A hardcoded `false` would be a hand-maintained mirror
 * of a schema fact (trap 12) that keeps answering "no layout" for exactly as
 * long as nobody re-checks it. Today this returns false for every real
 * `scenarios.graph`; the day it returns true, the UI gets a signal instead of a
 * stale promise.
 */
function detectLayout(graph: unknown): boolean {
  if (graph === null || typeof graph !== "object") return false;
  const g = graph as Record<string, unknown>;

  for (const key of Object.keys(g)) {
    if (LAYOUT_KEYS.has(key.toLowerCase())) return true;
  }

  for (const collection of ["nodes", "edges", "options"] as const) {
    const entries = g[collection];
    if (!Array.isArray(entries)) continue;
    for (const entry of entries) {
      if (entry === null || typeof entry !== "object") continue;
      for (const key of Object.keys(entry as Record<string, unknown>)) {
        if (LAYOUT_KEYS.has(key.toLowerCase())) return true;
      }
    }
  }

  return false;
}

/** Most turns a reload restores; the oldest beyond it are left out (the Agent's own window is 20). */
export const CONVERSATION_TURNS_CAP = 50;
/** The raw rows read so that {@link CONVERSATION_TURNS_CAP} answer rows survive the drop (each Agent turn also writes a
 *  claim row and its sub-turns). */
export const CONVERSATION_ROWS_READ = CONVERSATION_TURNS_CAP * 4;

/** One restored turn: text only, as stored. */
export interface ConversationTurnRead {
  readonly turn_id: string;
  readonly created_at: string;
  readonly user_message: string | null;
  readonly assistant_message: string | null;
}

function wantsConversationTurns(body: unknown): boolean {
  return body !== null && typeof body === "object" && !Array.isArray(body)
    && (body as Record<string, unknown>).include_conversation_turns === true;
}

/**
 * ⛔ ONLY WHAT THE USER SAW (Canvas #75 5910906799; root cause MG 5910983526; DL 5911089211; AIQ 5911161828).
 *
 * `v5_conversation_turns` holds more than the conversation. The Agent's tools reach the product through in-process
 * turns (`/orchestrate/v2/turn`), and each commits its own row: served MRR `3b6369b0` 01:44:03 stored the MODEL's tool
 * reason as `user_message` ("The user asked to run the analysis after confirming how MRR is calculated.") and the
 * HANDLER's text as `assistant_message` ("… scored highest in 100% of runs"). The user saw neither: they typed "Run the
 * analysis" and read the Agent's answer, which the Agent route writes as its OWN row. Restoring every row put words in
 * the user's mouth and showed text they never read.
 *
 * The rows the user saw are the Agent route's answer rows, and every one of them carries the route's own request
 * hash: `agent_turn:` (`agentTurnRequestHash`, `agent-v1-turn.ts`). The turn executor's rows carry `sha256:`, a
 * registration `graph_registration:`. So the restore keeps `agent_turn:` rows only. That is a marker already stored
 * on every row, so rows written before this change are dropped too. A board edit forwarded from the canvas is left
 * out as well: its narration was shown when it happened, and a restore omits it rather than risk text the user never
 * saw.
 */
export { AGENT_ANSWER_REQUEST_HASH_PREFIX } from "../orchestrator-v5/session/conversation-as-seen.js";

/**
 * The scenario's turns, OLDEST first, from the last {@link CONVERSATION_TURNS_CAP} rows, each reduced to its id, time
 * and the two stored texts. `readRecent` answers newest first; only the Agent's answer rows are kept (above), and a turn
 * with no text on either side (the Agent's claim row) is not a message and is left out. Never throws: a failed read is
 * `null` and the graph read stands.
 */
async function readConversationTurns(
  store: { readRecent(scenarioId: string, limit?: number): Promise<readonly { turn_id: string; created_at: string; request_hash?: string; user_message?: string | null; assistant_message?: string | null }[]> },
  scenarioId: string,
  requestId: string,
): Promise<ConversationTurnRead[] | null> {
  try {
    const rows = await store.readRecent(scenarioId, CONVERSATION_ROWS_READ);
    return [...rows].reverse()
      .filter(isAgentAnswerRow)
      .map((r) => ({
        turn_id: r.turn_id,
        created_at: r.created_at,
        user_message: typeof r.user_message === "string" ? r.user_message : null,
        assistant_message: typeof r.assistant_message === "string" ? r.assistant_message : null,
      }))
      .filter((t) => t.user_message !== null || t.assistant_message !== null)
      .slice(-CONVERSATION_TURNS_CAP); // the cap counts AFTER the drop (CURRENT-READ-v1 row 5)
  } catch (err) {
    log.warn(
      {
        event: "v5.scenario_graph.conversation_turns_read_failed",
        request_id: requestId,
        scenario_id: scenarioId,
        err: err instanceof Error ? err.message : String(err),
      },
      "Scenario graph read — conversation turns read failed; answering null, the graph stands",
    );
    return null;
  }
}

export default async function route(app: FastifyInstance) {
  // Tier `read`, DERIVED from RATE_BUCKET_REGISTRY (the single place the
  // route→tier assignment lives; its drift test enforces both directions).
  const RATE_LIMIT_MAX = resolveCeeRateLimit("CEE_SCENARIO_GRAPH_RATE_LIMIT_RPM");

  app.post<{ Params: { scenario_id: string } }>(
    "/assist/v1/scenarios/:scenario_id/graph",
    {
      // THE REPO'S OWN LIMITER, applied per-route — the `proxy-v5-turn.ts`
      // stop-rung pattern. `@fastify/rate-limit` is registered `global: true`
      // in server.ts and this config overrides its max for exactly this route.
      //
      // ⚠ THIS REPLACED A HAND-ROLLED IN-HANDLER LIMITER, and the reason is
      //   worth keeping. The custom version enforced correctly (its specs and
      //   mutants proved it), but CodeQL kept raising `js/missing-rate-limiting`
      //   HIGH against this handler: the query models RECOGNISED middleware, and
      //   a bespoke `tryConsume()` call inside a handler is invisible to it. A
      //   control that a scanner cannot see is a control every future reviewer
      //   has to re-derive by hand. Expressing the same limit through the
      //   sanctioned plugin is strictly better on every axis — it is
      //   Redis-backed in production rather than per-instance memory, it yields
      //   the app-standard `error.v1 RATE_LIMITED` body via server.ts's
      //   `errorResponseBuilder` instead of a second bespoke 429 shape, and it
      //   deletes code rather than adding a 15th copy of the `pruneBuckets` /
      //   `checkRateLimit` pair that 17 route files already carry (trap 12).
      //
      // ⚠ THE BUCKET IS PER CLIENT, and that falls out of the plugin's DEFAULT
      //   keyGenerator (`req.ip`) rather than being configured here. It is the
      //   behaviour this route needs and it is pinned by a spec, because it is
      //   a default someone could change: through the `/bff/cee/*` edge every
      //   visitor arrives carrying the SAME injected assist key, so any
      //   key-derived bucket would be one product-wide shared-fate throttle in
      //   which a single busy tab 429s everybody. `req.ip` resolves from
      //   `x-forwarded-for` in production (`trustProxy: nodeEnv === "production"`),
      //   so it is per-visitor — which is also the granularity that bounds the
      //   real threat here: one host walking scenario ids.
      config: {
        rateLimit: {
          max: RATE_LIMIT_MAX,
          timeWindow: "1 minute",
        },
      },
    },
    async (req, reply) => {
      const requestId = getRequestId(req);
      const scenarioId = req.params.scenario_id;

      /**
       * THE ONE REFUSAL. Absent scenario, someone else's scenario, malformed
       * id, ownership oracle down — all answer these exact bytes. See the
       * header: a refusal that named its reason would be an enumeration oracle
       * over other people's decisions.
       */
      const refuse = () =>
        reply
          .code(404)
          .send(
            buildErrorV1(
              "NOT_FOUND",
              "No readable graph for that scenario.",
              {},
              requestId,
            ),
          );

      /**
       * A read that could not complete is an UNKNOWN, never an absence and
       * never an empty graph. Answering 404 or `graph: null` on a DB blip
       * would tell the UI the user's decision does not exist / is empty, and
       * the UI would render that as an empty canvas over live data.
       */
      const unavailable = () =>
        reply
          .code(503)
          .send(
            buildErrorV1(
              "INTERNAL",
              "The graph could not be read right now.",
              {},
              requestId,
            ),
          );

      // The rate limit runs BEFORE this handler — it is the plugin's
      // onRequest hook, driven by the `config.rateLimit` above.

      // ── 0. Identity, from headers only, before ANY read of server state ──
      const resolved = await resolveVerifiedIdentityOrRefuse(req, requestId);
      if (!resolved.ok) {
        return reply.code(resolved.status).send(resolved.error);
      }

      // ── 1. Syntax: a non-UUID cannot name a row. No round trip. ─────────
      if (!UUID_PATTERN.test(scenarioId)) {
        return refuse();
      }

      const store = getSessionStore();
      const extensions = parseRequestExtensions(req.body, requestId);
      if (!extensions.ok) return refuse();

      // Production reads one existing row: absence stays distinct from a guest owner,
      // and this read has no create-on-read path. Legacy stores retain their original ladder.
      let snapshot: Awaited<ReturnType<NonNullable<typeof store.readExistingScenario>>> | undefined;
      // True only when access came from viewer membership (never for the owner or a guest row). See §6.
      let memberRead = false;
      if (typeof store.readExistingScenario === "function") {
        try {
          snapshot = await store.readExistingScenario(scenarioId);
        } catch {
          return unavailable();
        }
        if (snapshot === null) return refuse();
        const caller = resolved.identity.mode === 'verified' ? resolved.identity.userId : null;
        let access = scenarioAccessDecision(snapshot.userId, caller);
        // ⭐ A VIEWER MEMBER MAY READ (ACCOUNTS "Invite a colleague", DL #85 5947426886). THIS ROUTE ONLY: it is a
        // read, and every write door (turns, register, versions, the Supabase saves) keeps its owner-only check, so a
        // member is a non-owner everywhere else. Only a VERIFIED caller on an OWNED row is asked. A membership read
        // that fails answers the SAME refusal bytes (logged), never 503: a distinct status for "exists but your
        // membership could not be checked" would tell a stranger the scenario exists.
        if (access !== 'allow' && caller !== null && snapshot.userId !== null && typeof store.isScenarioMember === 'function') {
          let member = false;
          try {
            member = await store.isScenarioMember(scenarioId, caller);
          } catch (err) {
            log.warn(
              {
                event: 'v5.scenario_graph.member_check_failed',
                request_id: requestId,
                scenario_id: scenarioId,
                err: err instanceof Error ? err.message : String(err),
              },
              'Scenario graph read — membership check failed; refusing',
            );
          }
          if (member) {
            access = 'allow';
            memberRead = true;
            log.info({ event: 'v5.scenario_graph.member_read', request_id: requestId, scenario_id: scenarioId }, 'Scenario graph read by a viewer member');
          }
        }
        if (access !== 'allow') return refuse();
      } else {
        // ── 2. EXISTENCE — before ownership, so the read cannot CREATE ──────
        // Error discipline is the INVERSE of turn-stop's fail-open: a Stop
        // fails open because a DB blip must not cost a user their Stop, and the
        // worst case is a spurious tombstone. Here the worst case is serving or
        // fabricating someone's decision graph, so a thrown read fails CLOSED
        // and says 503 — it never degrades into 404 or into an empty graph.
        //
        // ⚠ A MISSING `scenarioExists` FAILS CLOSED, and this is the one place
        //   this route deliberately diverges from turn-stop.ts's structural
        //   probe. `scenarioExists` is OPTIONAL on the SessionStore interface.
        //   turn-stop can skip it when absent, because skipping only costs it a
        //   hardening check. Skipping it HERE would fall straight through to the
        //   ownership pre-flight — the call that UPSERTS — so "I could not check
        //   whether this scenario exists" would become "create it and read it".
        //   Defaulting to `true` (assume it exists) is exactly the dangerous
        //   direction, and it would make the invariant this route advertises
        //   ("a read never creates the row it reads") conditional on a store
        //   shape rather than structural. An unverifiable precondition is
        //   refused, not assumed.
        let exists: boolean;
        try {
          if (typeof store.scenarioExists !== "function") {
            log.error(
              {
                event: "v5.scenario_graph.existence_check_unavailable",
                request_id: requestId,
              },
              "Scenario graph read — store cannot check scenario existence; refusing rather than risking a create-on-read",
            );
            return unavailable();
          }
          exists = await store.scenarioExists(scenarioId);
        } catch (err) {
          log.warn(
            {
              event: "v5.scenario_graph.existence_read_failed",
              request_id: requestId,
              scenario_id: scenarioId,
              err: err instanceof Error ? err.message : String(err),
            },
            "Scenario graph read — existence read failed; failing closed",
          );
          return unavailable();
        }
        if (!exists) {
          return refuse();
        }

        // ── 3. Ownership — the SAME pre-flight the turn route runs ──────────
        // The caller-supplied `user_id` is read by the SAME parser the turn
        // route uses, not a hand-rolled `body.user_id` read that would drift the
        // day the extension contract moves.
        let owned: Awaited<ReturnType<typeof authorizeScenarioOwnership>>;
        try {
          owned = await authorizeScenarioOwnership(
            scenarioId,
            // Ownership on this surface is derived from the verified token
            // subject. A request-supplied identifier is not an input to that
            // decision, so the sentinel is passed rather than the parsed
            // extension. See the constant for why this is expressed here and not
            // in the shared function.
            CALLER_ASSERTED_IDENTITY_NOT_ADMISSIBLE,
            resolved.identity,
            requestId,
          );
        } catch (err) {
          log.warn(
            {
              event: "v5.scenario_graph.ownership_read_failed",
              request_id: requestId,
              scenario_id: scenarioId,
              err: err instanceof Error ? err.message : String(err),
            },
            "Scenario graph read — ownership pre-flight threw; failing closed",
          );
          return unavailable();
        }
        if (!owned.ok) {
          // Reason is LOGGED, never returned — including the oracle-down case,
          // which is fail-CLOSED here (see the header).
          log.warn(
            {
              event: "v5.scenario_graph.refused_not_owner",
              request_id: requestId,
              scenario_id: scenarioId,
              reason: owned.reason,
            },
            "Scenario graph read — caller is not authorized for this scenario",
          );
          return refuse();
        }

      }

      // ── 4. The read ─────────────────────────────────────────────────────
      let graph: unknown;
      let briefText: string | null;
      try {
        const loaded = snapshot ?? await store.loadGraphAndBriefText(scenarioId);
        graph = loaded.graph;
        briefText = loaded.briefText;
      } catch (err) {
        log.warn(
          {
            event: "v5.scenario_graph.read_failed",
            request_id: requestId,
            scenario_id: scenarioId,
            err: err instanceof Error ? err.message : String(err),
          },
          "Scenario graph read — graph read failed; failing closed",
        );
        return unavailable();
      }

      if (typeof store.readMostRecentPendingActions !== 'function') return unavailable();
      let scopeInput: ReturnType<typeof goalScopeClaimInput>;
      try {
        scopeInput = goalScopeClaimInput(await store.readMostRecentPendingActions(scenarioId, { validation: 'strict' }), graph);
      } catch { return unavailable(); }
      const scopeIssues = scopeInput.issues;

      // An EMPTY graph is a valid answer, not an error: every scenario starts
      // there, and 404-ing it would make "no graph yet" indistinguishable from
      // "not yours" — collapsing the very distinction the UI needs.
      const graphPresent = graph !== null && graph !== undefined;

      // ── 5. THE ADDITIVE ANALYSIS PAYLOAD (ROADMAP 2.1271) ───────────────
      //
      // ADDITIVE BY CONSTRUCTION. Two new keys, both nullable; not one existing
      // key is rewritten, reordered or conditioned on them. A client that has
      // never heard of them sees a byte-identical body — asserted against a
      // capture taken on the PR BASE, not against a fixture this lane wrote
      // (`__tests__/scenario-graph-analysis-additive.test.ts`).
      //
      // WHY IT BELONGS ON THIS ROUTE RATHER THAN A NEW ONE. The security ladder
      // above — identity → UUID → existence-before-ownership → ownership
      // pre-flight → per-IP limiter — is 120 lines of hard-won reasoning, and a
      // dedicated `/assist/v1/scenarios/:id/analysis` would need every line of
      // it a second time. Same route, same ownership check, same limiter, same
      // scenario's own data: the caller entitled to read this graph is exactly
      // the caller entitled to read the analysis OF that graph.
      //
      // It reads the SAME graph object this response returns, so the freshness
      // verdict cannot describe a different model than the one being delivered.
      // Never throws; on any failure both keys are `null` and the graph stands.
      const analysis = await readScenarioAnalysis({
        scenarioId,
        graph: graphPresent ? graph : null,
        requestId,
        goalScopeClaimInput: scopeInput,
        ...(snapshot !== undefined && snapshot !== null ? { analysisInvalidatedAt: snapshot.analysisInvalidatedAt } : {}),
      });
      // The selected block already has one public carrier, `analysis_result`.
      // The current-read sidecar exposes its bounded identity and typed figures
      // without a second copy of raw enrichment/probability fields.
      const { result: _selectedBlock, ...currentReadWire } = analysis.current_read;
      // Compatibility projection reads the common canonical claim, never the
      // issue count. The pending actions remain explanatory data only.
      const scopePermissions = claimPermissionsFrom(analysis.analysis_state, undefined);

      // ── 6. THE CONVERSATION, OPT-IN (DL lease #75 5907582591; Canvas 5907308286) ──
      //
      // "The chat survives a reload": CEE stores every turn's text in
      // `v5_conversation_turns` but served no read of it, so a fresh browser or a
      // second device opened on an empty chat. It rides THIS route for the reason
      // §5 gives: the caller entitled to read the graph is exactly the caller
      // entitled to read its conversation, and the ladder above is not written twice.
      //
      // OPT-IN, because the Agent reads this route internally on every turn
      // (`turnReadCache`): without `include_conversation_turns: true` the body is
      // byte-identical and no extra query runs. The stored `assistant_message` is the
      // POST-WIRE text the user saw (AIQ 5907360564), served as stored — never
      // re-derived. `null` = this leg did not answer, never "no conversation".
      //
      // ⚠ A VIEWER MEMBER GETS THE MODEL AND THE RUN, NEVER THE OWNER'S CONVERSATION. The premise above ("the caller
      // entitled to read the graph is exactly the caller entitled to read its conversation") holds for the owner and
      // a guest row. A colleague the owner shared the decision with was given the decision, not the owner's chat
      // with Olumi. So a member read leaves the field out, exactly as if it had not been asked for.
      const conversationTurns = wantsConversationTurns(req.body) && !memberRead
        ? await readConversationTurns(store, scenarioId, requestId)
        : undefined;

      return reply.code(200).send({
        schema: SCENARIO_GRAPH_SCHEMA,
        scenario_id: scenarioId,
        graph: graphPresent ? graph : null,
        graph_present: graphPresent,
        brief_text: briefText,
        // identity.v1, from the single normaliser authority. Null when the
        // graph is absent or identity-empty — there is no identity to anchor
        // to, and a hash of nothing would be a false anchor.
        graph_identity_hash: graphPresent
          ? computeGraphIdentityHash(graph as GraphStateIngress)
          : null,
        // ⭐⭐ THE WRITE PRECONDITION FOR THE GRAPH THIS RESPONSE CARRIES.
        //
        // A manual edit is a compare-and-set: `option_intervention_edit` (and its
        // siblings) send a base hash, and the writer refuses unless
        // `computeAnalysisAffectingGraphHash(persistedGraph)` equals it. Until
        // now that base reached a client ONLY on a turn response, so a RELOAD —
        // which restores the graph without any turn — left the client with no
        // base and every first edit refused as `needs_fresh_base`. Root hit
        // exactly that natively: a restored scenario, a mounted editor, and a
        // Save that honestly sent nothing. The refusal was correct; the missing
        // precondition was the defect.
        //
        // ⚠⚠ IT IS NOT `graph_identity_hash`, AND THE TWO MUST NEVER BE
        // SUBSTITUTED. identity.v1 answers "is this the same graph object?" over
        // a normalised projection; this answers "may a write be applied to the
        // graph as the analysis sees it?". They differ in projection, in width
        // and in purpose — and on an UNCHANGED graph a wrong choice still
        // matches, so the mistake would surface only once someone edited.
        //
        // ⚠ DERIVED HERE, FROM THE VERY BYTES THIS RESPONSE CARRIES — the same
        // discipline `graph_identity_hash`, `layout_present` and `not_modelled`
        // already follow, and for the same reason: a value taken from anywhere
        // else is a hand-maintained mirror that starts lying the moment the
        // graph moves. It is deliberately NOT threaded out of
        // `readScenarioAnalysis`, and that helper does NOT compute this hash:
        // its freshness comparison uses the CANONICAL analysis hash
        // (`deriveDecisionContextGraphHash` — the projection a run stamps
        // `graph_hash_at_run` over), while this wire `graph_hash` stays the RAW
        // hash of the bytes returned here, the compare-and-set base the writers
        // derive from the persisted graph. The two agree on a graph already in
        // canonical shape and differ only on repaired-shape graphs (CS-AN-2).
        // The helper also answers "not answered" for a graph with no analysis
        // and swallows its own failures, so the write base would inherit an
        // unrelated precondition and vanish exactly when a never-analysed
        // scenario is the one being edited.
        //
        // ⚠ THE SAME KEY THE TURN RESPONSE USES, deliberately. `applyV5State`
        // already stamps `store.lastServerGraphHash` from a turn's top-level
        // `graph_hash`; one concept keeps one name across both carriers, and the
        // client adopts it by the same rule rather than learning a second one.
        //
        // `null` when the graph is absent — there is nothing to write against,
        // and a hash of nothing would be a base that matches nothing.
        graph_hash: graphPresent
          ? computeAnalysisAffectingGraphHash(graph as GraphStateIngress)
          : null,
        layout_present: detectLayout(graphPresent ? graph : null),
        // ROADMAP 2.973 — what of the brief did NOT reach the model.
        //
        // DERIVED HERE, from the very bytes this response carries, for the same
        // reason `layout_present` is: a snapshot taken at draft time is a
        // hand-maintained mirror that starts lying the moment the user edits the
        // graph, whereas a re-derivation cannot disagree with what it was
        // computed from. It is a pure function of (brief_text, graph) — no I/O,
        // no clock — so it costs one pass over bytes already in memory.
        //
        // ⚠ WHEN IT CANNOT LOOK IT SAYS SO. Absent brief or absent graph yields
        // `status: "unavailable"` with `quantities: null`, never a zero tally:
        // on a scenario we know nothing about, "0 dropped" would be a new lie
        // carrying the authority of a measurement.
        not_modelled: deriveNotModelledManifest(
          briefText,
          graphPresent ? graph : null,
        ),
        // ROADMAP 2.1271 — see §5 above. `null` on either means "this leg did
        // not answer", never a state: a consumer must leave what it already
        // believed standing, and in particular must NOT read a null or a
        // `never_run` here as evidence against an in-flight run the DRAFT TURN
        // told it about (the H4 seam — the two authorities answer different
        // questions).
        analysis_state: analysis.analysis_state,
        ...(scopeIssues.length > 0 ? { goal_scope_reconciliation: scopeIssues } : {}),
        ...(scopePermissions.total_goal_claims_allowed === false ? {
          goal_scope_claim_permissions: { total_goal_claims_allowed: false, exploratory_work_allowed: true },
        } : {}),
        analysis_result: analysis.analysis_result,
        // CURRENT-READ-v1: one selected Run's canonical freshness and typed
        // figures. The raw graph_hash above remains the edit/CAS token; the
        // projection's hashes are the analysis selector's separate domain.
        current_read: currentReadWire,
        // The selected fact's own constraint verdict state — present exactly when
        // `analysis_result` is (same fact, same gate). See `ScenarioAnalysisRead`.
        ...(analysis.analysis_constraint_verdict_state !== undefined
          ? { analysis_constraint_verdict_state: analysis.analysis_constraint_verdict_state }
          : {}),
        // The selected fact's leader-limit risks — same fact, same gates as the state above.
        ...(analysis.analysis_leader_limit_risks !== undefined
          ? { analysis_leader_limit_risks: analysis.analysis_leader_limit_risks }
          : {}),
        // B5: the selected fact's per-limit rows — same fact, same gates; absent when it attests none.
        ...(analysis.analysis_limit_verdicts !== undefined
          ? { analysis_limit_verdicts: analysis.analysis_limit_verdicts }
          : {}),
        // 0.63.0: the selected fact's own goal certainty — same fact, same gates; absent = not recorded.
        ...(analysis.analysis_goal_certainty !== undefined
          ? { analysis_goal_certainty: analysis.analysis_goal_certainty }
          : {}),
        // 52f8cd: the Olumi options the selected Run left out of the comparison, and why — same fact, same gates.
        ...(analysis.analysis_option_participation !== undefined
          ? { analysis_option_participation: analysis.analysis_option_participation }
          : {}),
        // C46 × R3-4: the carriers the selected fact's engine evaluated — same fact, same gates; absent when it records none.
        ...(analysis.analysis_identity_evaluated_node_ids !== undefined
          ? { analysis_identity_evaluated_node_ids: analysis.analysis_identity_evaluated_node_ids }
          : {}),
        // R3-9 (#2248): the last successful Run's use of each declared identity — the link writer's own input, not gated.
        ...(analysis.analysis_identity_run_use !== undefined
          ? { analysis_identity_run_use: analysis.analysis_identity_run_use }
          : {}),
        /**
         * ⭐ MAY A RUN BE ADMITTED RIGHT NOW — the question `analysis_state`
         * does not answer. It reports whether a FACT HAS LANDED for this graph;
         * this reports whether one COULD BE STARTED, and what stands in the way.
         * Without it a reload can only learn admissibility by taking a turn.
         *
         * Machine codes only — every user-facing string is dropped in the
         * projection, because this route ships no enforceable prose. `null` when
         * there is no graph to judge: "this leg did not answer", never a state.
         */
        analysis_admission: projectAnalysisAdmission(graph, graphPresent),
        ...(conversationTurns !== undefined ? { conversation_turns: conversationTurns } : {}),
        request_id: requestId,
      });
    },
  );
}
