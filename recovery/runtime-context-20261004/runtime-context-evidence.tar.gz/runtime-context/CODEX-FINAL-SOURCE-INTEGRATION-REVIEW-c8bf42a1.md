# Runtime L1 latest merged-base source verdict

Verdict: FINAL_SOURCE_APPROVE.
Unresolved P1: 0. Concrete findings: none in this L1 integration scope.

Exact reviewed HEAD: `c8bf42a193f9126961b95b9435247dc02b1c94ef`.
Tree: `b535d865b8f1f7bb9a6b41dda8263ac680744140`.
Merge parents: `eeeb37b3fc319ef78ac7dcd49017e5bbb5385d62` and `1f31e8278b2fa522f86a55f257c3d35c9b6536b3`.
Reviewed PR base: `1f31e8278b2fa522f86a55f257c3d35c9b6536b3`.

I independently verified this immutable HEAD, tree and both parents. Its diff against 1f31 contains exactly the seven L1 files. All seven final blobs are byte-identical to the authored and previously reviewed `75218ba18150518134d101228073267933d4e6d1`; the complete binary diff SHA256 is independently `94406ed254219db244b85987b006688b0fe184369f7e4700772264fdc0a9fea7`. The source preimages remain unchanged across b313 to 1f31, and the diff whitespace check passes.

I read the four intervening base diffs: the user-material budget exception in runtime/build-model.ts, its construction risk control, and the two compact benchmark control files. They change construction instructions and test controls, not L1's SDK/fetch/retry invocation, imports, policy handles, timing/telemetry, prompt-registry metadata source or persistence. Direct retry, telemetry, provider-policy and model-assignment dependencies remain byte-identical. No new invariant compatibility defect was found; no duplicate full-source audit was performed.

Thus the previously examined L1 behavior is preserved at this independently verified new head: invocation-local logical/physical joins; exact guard handles with capped transport unknowns kept null; native SDK and repository retry grouping; terminal success/failure/runaway/so_reject distinctions; preservation of returned values and thrown errors through optional observation; unchanged requests and original logical timing counters; explicit response-header and SDK terminal boundaries; returned-SDK token scope rather than total paid usage; and unknown cost/quality or registry attribution where unavailable.

I read the exact L1-1F31-INTEGRATION-READY-1815.json, PREAPPLY and STAGED-INTEGRATION receipts. They record executor-owned typecheck/lint exit 0 and the five offline focused specs with the b535 tree unchanged. I ran no tests, gates, network/provider/browser actions, publication or product/branch mutation. This external review receipt is the only file authored during this review.

This is a distinct final source verdict for c8bf, not release approval. Publishing allocation, native prepush, remote Required, HIGH, mergegate and serving remain separately owned. Capture coverage remains adapter-only: raw Agent Responses and public Anthropic async-generator stream-chat are excluded. Quality/cost and current-turn count/speed remain unknown or unmeasured; no serving or browser/journey proof is claimed.
