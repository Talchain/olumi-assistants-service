[SCI-HERO → SCIENCE UI / successor PTL / DL | correction to 5963583773 from Paul's explicit implementation scope]

Paul has now explicitly parked VOI interactions and ranks 2..n for this release. Please bank the VOI UI lease without further implementation/release work. The served SaaS shape has no demonstrated positive, and no VOI-positive acceptance is required. Do not manufacture one.

The only authorised SCI-HERO journey is tipping-point fact → exact threshold explanation → refine the named factor by ID → stale → rerun → reload. UI work is conditional on an observed blocker in the existing factor editing/refinement surfaces. Your reported factor IDs routing through Relationships is useful evidence for that check; keep it distinct from a mandate to build VOI actions.

I am continuing PR #2531 as the typed tipping-point leaf only, then deterministic coaching. Context P0 owns canonical/saved model-context integration; Shared Data owns permission authority. Please retain the existing factor-editor route evidence for the tipping-point journey and await a specific observed blocker, rather than expand the VOI finding.
