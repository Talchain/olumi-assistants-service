/**
 * V5 — Recent-changes projection for the LLM-facing ContextPack.
 *
 * Projects up to {@link RECENT_CHANGES_CAP} successful mutation facts from
 * `prior_facts` into a compact, decision-language summary the routing LLM
 * can ground its answer on. Fixes the Phase 0 information-starvation
 * finding: prior facts were persisted and read back correctly, but the
 * ContextPack only carried `last_tool_used` (a string), so on a follow-up
 * state-query Sonnet had no payload to reference and fell to the legacy
 * `edit_graph` catch-all.
 *
 * Hard contract:
 *   - **No raw structural identifiers** in the summary string. No
 *     `constraint_id`, `node_id`, `target_id`, edge IDs, UUIDs, or
 *     `provenance` markers. The summary is what a user would say.
 *   - **Cap is hard.** Maximum {@link RECENT_CHANGES_CAP} entries; each
 *     summary is truncated to {@link RECENT_CHANGES_SUMMARY_MAX_CHARS}
 *     characters (with an ellipsis marker if truncated), and each structured
 *     target label is bounded by the same single text limit. The cap protects
 *     the routing prompt token budget — `recent_changes` cannot grow
 *     unbounded as the conversation extends or through one pathological
 *     persisted label.
 *   - **Successful mutations only.** Noop facts (no actual change)
 *     and non-mutation fact types are filtered out.
 *
 * What this module does NOT do:
 *   - Hash identifiers. The projection drops them entirely; do not
 *     "redact" them, leave them out.
 *   - Reach into the live graph. All fields it needs come off the
 *     fact's `before`/`after` snapshots. New edge facts carry sanitised
 *     mutation-time endpoint labels; legacy/unsafe facts stay generic.
 *   - Touch the wire response. `recent_changes` is internal context
 *     only; the boundary `graph_patch` block schema is unchanged.
 */

import { createHash } from 'node:crypto';

import type { HandlerFact } from '@talchain/schemas/orchestrator';

import { isNoopFact } from '../tools/fact-noop.js';
import { sanitiseUserFacingText } from '../../orchestrator/shared/output-safety.js';
import { MUTATION_RECEIPT_FACT_TYPES } from '../mutation-receipt-fact-types.js';
import type { IdentifiedHandlerFact } from '../types/handler-fact.js';
import {
  formatConstraintAdded,
  formatConstraintUpdated,
  formatFactorChange,
} from '../tools/handlers/d1-shared/format-confirmation.js';

/**
 * Maximum number of recent-change entries projected into the ContextPack.
 *
 * Three is enough for "what just changed?" follow-ups (the user is almost
 * always referring to the most recent action) without bloating the prompt.
 * If the conversation has more mutations than this, the oldest fall off
 * the projection — they remain in the database for replay and analytics.
 */
export const RECENT_CHANGES_CAP = 3;

/**
 * Maximum characters per summary string. Targets the ~80 char cap from
 * the implementation brief. Realistic outputs sit at 40–65 chars; the
 * truncation guard catches pathological inputs (very long node labels,
 * unusual unit strings) so a single mutation cannot blow the prompt
 * budget.
 */
export const RECENT_CHANGES_SUMMARY_MAX_CHARS = 80;
const EDGE_ENDPOINT_LABEL_MAX_CHARS = 80;
const GENERIC_EDGE_SUMMARY = 'Adjusted a link in the decision model.';
const GENERIC_EDGE_TARGET = 'a link in the decision model';

/**
 * Permitted change-type discriminators. PRODUCT-DOMAIN VALUES — these
 * strings ship in the LLM-facing payload (and the assistant_text path
 * via the state-query guard), so they are deliberately phrased as
 * decision-language outcomes rather than handler ids. Mapping to the
 * underlying handler set:
 *
 *   constraint_added       ← `add_constraint` handler (D1)
 *   factor_value_updated   ← `set_factor_value` handler (D1)
 *   link_strength_updated  ← `adjust_edge_strength` handler (D1)
 *
 * Keeping this enum separate from `HandlerFact['fact_type']` means
 * Sonnet cannot accidentally echo internal handler ids back at the
 * user. Additions here MUST coincide with a `summariseMutation` branch
 * AND a documented mapping above.
 */
export type RecentChangeAction =
  | 'constraint_added'
  | 'factor_value_updated'
  | 'link_strength_updated'
  // 0.12.0 — DL-7 PR B: LLM-driven graph edits via the `edit_graph`
  // dispatcher. Companion to the three D1 mutation actions above.
  // Mapping: `'graph_edited'` ← `EditGraphHandlerFact` (any
  // `edit_kind`). The fact's `safe_summary` is quoted verbatim as
  // the projection's `summary`; `affected_entities[0].label` becomes
  // the `target_label`. The schema-side `noop=true` filter at
  // `summariseMutation` line 134 already covers the emitter-safety
  // contract for "noop facts not surfaced as successful changes".
  | 'graph_edited';

export interface RecentMutation {
  /** Discriminator. Used by Sonnet and the deterministic state-query guard. */
  readonly action: RecentChangeAction;
  /** Additional qualitative licence; absence retains the existing generic policy. */
  readonly transition?: 'node_label_changed';
  /**
   * One-line decision-language summary. No identifiers, no internal
   * terms. Capped at {@link RECENT_CHANGES_SUMMARY_MAX_CHARS}; truncated
   * with an ellipsis marker when the source string exceeds the cap.
   */
  readonly summary: string;
  /**
   * Decision-language label of the entity the mutation targeted (e.g.
   * "Total cost" for an `add_constraint` on the cost factor; "Customer
   * churn" for a `set_factor_value`). Surfaced separately from
   * `summary` so future deterministic copy paths (state-query guard,
   * follow-up receipts, UI handoff) can reference the target without
   * regex-parsing the summary string.
   *
   * Empty string when the fact lacks a clean label (defensive — production
   * mutation facts always carry one). Edge mutations have no single
   * target label so this falls back to a generic descriptor. Bounded by
   * {@link RECENT_CHANGES_SUMMARY_MAX_CHARS}; an ellipsis makes any shortening
   * explicit rather than silently claiming the complete canonical label.
   */
  readonly target_label: string;
  /**
   * ⭐⭐ THE WRITE-TIME EVALUABILITY VERDICT, CARRIED FORWARD.
   *
   * Present only on a `constraint_added` entry whose limit the analysis cannot
   * check because its target node records no number anywhere. The value is the
   * SAME token the write path's {@link
   * import('../tools/handlers/d1-shared/constraint-write-admissibility.js').ConstraintWriteAdmissibility}
   * carries, so the two moments cannot drift into different vocabularies for
   * one fact.
   *
   * ⚠ ABSENCE IS **NOT** A POSITIVE CLAIM — it is UNKNOWN, and a consumer that
   * reads it as "this limit is fine" recreates the defect this field exists to
   * close. The field is absent whenever the turn read no graph, the target is
   * not in the graph, no verdict was derived, or the limit is genuinely
   * checkable; only the last of those is evidence. Same contract as the pack's
   * `readiness` / `goal_target` keys, and the same reason.
   *
   * ⚠ IT IS A SEPARATE FIELD RATHER THAN AN APPENDED SENTENCE BECAUSE
   * `summary` IS A BUDGET, NOT A PARAGRAPH. {@link
   * RECENT_CHANGES_SUMMARY_MAX_CHARS} is 80 and {@link cap} truncates; the
   * ratified not-checkable sentence is 144 characters before its repair ask, so
   * appending it would silently eat the receipt it is qualifying. The copy is
   * unchanged — this increment moves the set of turns on which the verdict is
   * available, never the words.
   */
  readonly constraint_not_checkable?: 'target_records_no_value';
}

/**
 * Project the recent successful mutations from `prior_facts` into the
 * ContextPack. Caller MUST pass facts ordered newest-first (matching
 * `SessionStore.readFactsFor` which orders by `created_at DESC`).
 *
 * Returns a frozen, possibly-empty array. Never throws — bad/unknown
 * fact shapes are skipped silently so a single corrupt fact cannot
 * blank the entire projection.
 *
 * @param notCheckableConstraintIds the `constraint_id`s the analysis cannot
 *   check on the graph AS IT STANDS THIS TURN, from
 *   `collectNotCheckableConstraintIds`. OPTIONAL, and omission is
 *   byte-identical to the behaviour before it existed: no entry is qualified,
 *   which is what every caller that holds no graph must get. It is deliberately
 *   a DERIVED CLAIM rather than a graph — this module's contract is that it
 *   never reaches into the live graph (see the file header), and handing it one
 *   would break that as well as give it a second graph authority to disagree
 *   with.
 *
 *   ⚠ THE VERDICT IS ABOUT NOW, NOT ABOUT THE TURN THAT WROTE THE ROW, AND
 *   THAT IS THE CORRECT SEMANTICS: if the user has since recorded a number on
 *   the target, the limit IS checkable and the entry stops being qualified. A
 *   verdict frozen at write time would become the mirror defect — a stale
 *   "cannot be checked" re-asserted after the gap was closed.
 */
export function projectRecentChanges(
  priorFacts: readonly HandlerFact[] | undefined,
  entries?: readonly IdentifiedHandlerFact[],
  notCheckableConstraintIds?: ReadonlySet<string>,
): readonly RecentMutation[] {
  if (!priorFacts || priorFacts.length === 0) return Object.freeze([]);

  const out: RecentMutation[] = [];
  for (const [index, fact] of priorFacts.entries()) {
    if (out.length >= RECENT_CHANGES_CAP) break;
    const entry = entries?.[index];
    const transition = entry?.fact === fact ? entry.label_transition : undefined;
    const summarised = summariseMutation(fact, notCheckableConstraintIds);
    if (summarised?.action === 'graph_edited' && transition?.kind === 'node_label_changed') {
      const summary = `Renamed ${JSON.stringify(transition.before_label)} to ${JSON.stringify(transition.after_label)}.`;
      const canShowExact = summary.length <= RECENT_CHANGES_SUMMARY_MAX_CHARS &&
        sanitiseUserFacingText(summary, null).matches.length === 0;
      out.push({
        action: 'graph_edited',
        transition: 'node_label_changed',
        summary: canShowExact ? summary : 'Renamed a model element; its exact labels are withheld from this summary.',
        target_label: canShowExact ? transition.after_label : '',
      });
      continue;
    }
    if (summarised) out.push(summarised);
  }
  return Object.freeze(out);
}

/**
 * Context-audit #1 (keep-list inventory row #4) — the conformance surface for
 * `summariseMutation`'s dispatch. The silent-drop risk: a NEW handler emits a
 * `fact_type` that `summariseMutation` has no branch for, so the mutation
 * never appears in "what just changed" and no test notices.
 *
 * These two sets partition the ENTIRE `HandlerFact['fact_type']` discriminated
 * union (the source of truth is `HandlerFactSchema.options` in
 * `@talchain/schemas/orchestrator`, enumerated by
 * `__tests__/recent-changes.conformance.test.ts`):
 *   - {@link MUTATION_RECEIPT_FACT_TYPES} — types with a receipt branch below.
 *   - {@link MUTATION_DISPATCH_SKIP} — types deliberately not surfaced, each
 *     with a reason.
 * The conformance test asserts receipt ∪ skip == the schema's fact_type set
 * EXACTLY (a new fact_type in neither ⇒ RED) AND binds each set to the actual
 * `projectRecentChanges` behaviour (receipt types produce an entry, skip types
 * produce none), so the sets can never drift into a lie about the dispatch.
 *
 * Adding a mutation handler ⇒ add its `fact_type` here AND a branch below.
 */
export { MUTATION_RECEIPT_FACT_TYPES };

/** Non-surfaced fact types + the reason each carries no `recent_changes` entry. */
export const MUTATION_DISPATCH_SKIP: ReadonlyMap<HandlerFact['fact_type'], string> =
  new Map<HandlerFact['fact_type'], string>([
    ['run_analysis', 'Computation, not a graph mutation — no before/after state change to report.'],
    ['explain_result', 'Read-only explanation (legacy singular) — no state change.'],
    ['explain_results', 'Read-only explanation — no state change.'],
    ['explain_from_structure', 'Read-only explanation — no state change.'],
    ['compare_options', 'Read-only comparison — no state change.'],
    ['what_would_flip', 'Read-only sensitivity answer — no state change.'],
    // 0.34.0 — P4 transport judgement receipts. All three PERSIST a human
    // judgement without touching the graph (carry the signal; compute
    // consequence is a separate design decision), so there is no graph
    // mutation to report in "what just changed". Surfacing them in coaching
    // context is a deliberate FUTURE consumption decision, not a default.
    ['feedback', 'Judgement receipt (thumbs rating) — no graph state change.'],
    ['edge_adjudication', 'Judgement receipt (contested-edge verdict) — no graph state change.'],
    ['prior_range_edit', 'Judgement receipt (user-set prior range) — no graph state change.'],
    // 0.55.0 — `finding_dissent`, the FOURTH judgement receipt. Classified SKIP
    // on 2026-09-11. DERIVED rather than assumed, because the conformance test
    // forces the question and a silent answer is the thing it exists to stop:
    //
    //   1. `recent_changes` answers "What changed in the MODEL?" — the referent
    //      register says so in as many words (`context/turn-referents.ts`),
    //      where this field is named APART from its neighbours precisely
    //      because two questions under one name is this estate's signature
    //      defect. A dissent is a claim ABOUT a finding, not a change to the
    //      model that produced it, so it is not an answer to that question.
    //   2. The event's own transport classification agrees: `finding_dissent`
    //      is `'fact_and_commit'` in `system-events/dispatch.ts`, explicitly
    //      NOT `'mutating'` — it writes no `scenarios.graph` and moves no
    //      `graph_hash`.
    //   3. It is emitted by `buildJudgementFact`, the same function that emits
    //      the three receipts above — all three already skipped for this
    //      reason. It is the same class, not a new one.
    //   4. SKIP is also the CONSERVATIVE reading: `summariseMutation` has no
    //      branch for this fact_type and already falls through to `return
    //      null`, so this entry makes the EXISTING behaviour explicit rather
    //      than changing behaviour to clear a red.
    //
    // The alternative (a receipt) would let `deriveInterveningChange` say
    // "since you changed X" about something that changed nothing, and would
    // trip its `several ⇒ name none` guard on a non-change — a false causal
    // claim, which is the one thing that module exists to avoid.
    ['finding_dissent', 'Judgement receipt (stated dissent from a finding) — no graph state change.'],
  ]);

function summariseMutation(
  fact: HandlerFact,
  notCheckableConstraintIds?: ReadonlySet<string>,
): RecentMutation | null {
  // Successful mutations only — noops carry no user-visible change to
  // reference. `isNoopFact` is the shared predicate (tools/fact-noop.ts);
  // the coaching-signal detector gates on the same one, so the two
  // channels cannot drift apart on what "no change" means.
  if (isNoopFact(fact)) return null;

  if (fact.fact_type === 'add_constraint') {
    return summariseAddConstraint(fact.result, notCheckableConstraintIds);
  }
  if (fact.fact_type === 'set_factor_value') {
    return summariseSetFactorValue(fact.result);
  }
  if (fact.fact_type === 'adjust_edge_strength') {
    return summariseAdjustEdgeStrength(fact.result);
  }
  if (fact.fact_type === 'edit_graph') {
    return summariseEditGraph(fact.result);
  }
  return null;
}

function summariseAdjustEdgeStrength(
  result: Record<string, unknown> | undefined,
): RecentMutation | null {
  if (!result || typeof result !== 'object') return null;
  if (result.status !== 'applied') return null;
  const after = (result as { after?: unknown }).after;
  const before = (result as { before?: unknown }).before;
  const afterRecord = isRecord(after) ? after : null;
  const beforeRecord = isRecord(before) ? before : null;
  if (afterRecord === null && beforeRecord === null) return genericEdgeMutation();

  const afterIdentity = readHistoricalEdgeIdentity(afterRecord);
  const beforeIdentity = readHistoricalEdgeIdentity(beforeRecord);
  if (
    afterIdentity !== null &&
    beforeIdentity !== null &&
    (afterIdentity.from !== beforeIdentity.from || afterIdentity.to !== beforeIdentity.to)
  ) {
    return genericEdgeMutation();
  }

  // Read one internally coherent snapshot. Never combine labels from one
  // snapshot with endpoint identities from the other. Falling back to a
  // complete `before` tuple is safe only after any two identities agree.
  const snapshot =
    readHistoricalEdgeSnapshot(afterRecord) ??
    readHistoricalEdgeSnapshot(beforeRecord);
  if (snapshot === null || snapshot.fromLabel === snapshot.toLabel) {
    return genericEdgeMutation();
  }

  const summary = `Adjusted the link from ${snapshot.fromLabel} to ${snapshot.toLabel}.`;
  const targetLabel = `${snapshot.fromLabel} → ${snapshot.toLabel}`;
  if (
    summary.length > RECENT_CHANGES_SUMMARY_MAX_CHARS ||
    targetLabel.length > RECENT_CHANGES_SUMMARY_MAX_CHARS
  ) {
    return genericEdgeMutation();
  }

  return {
    action: 'link_strength_updated',
    summary,
    target_label: targetLabel,
  };
}

interface HistoricalEdgeIdentity {
  readonly from: string;
  readonly to: string;
}

interface HistoricalEdgeSnapshot extends HistoricalEdgeIdentity {
  readonly fromLabel: string;
  readonly toLabel: string;
}

function readHistoricalEdgeIdentity(
  record: Readonly<Record<string, unknown>> | null,
): HistoricalEdgeIdentity | null {
  if (record === null) return null;
  const from = readNonEmptyString(record.from);
  const to = readNonEmptyString(record.to);
  return from === undefined || to === undefined ? null : { from, to };
}

function readHistoricalEdgeSnapshot(
  record: Readonly<Record<string, unknown>> | null,
): HistoricalEdgeSnapshot | null {
  const identity = readHistoricalEdgeIdentity(record);
  if (identity === null || record === null) return null;
  const endpointIds = [identity.from, identity.to];
  const fromLabel = readSafeHistoricalEndpointLabel(record.from_label, endpointIds);
  const toLabel = readSafeHistoricalEndpointLabel(record.to_label, endpointIds);
  return fromLabel === null || toLabel === null
    ? null
    : { ...identity, fromLabel, toLabel };
}

function genericEdgeMutation(): RecentMutation {
  return {
    action: 'link_strength_updated',
    summary: GENERIC_EDGE_SUMMARY,
    target_label: GENERIC_EDGE_TARGET,
  };
}

function readSafeHistoricalEndpointLabel(
  value: unknown,
  endpointIds: readonly string[],
): string | null {
  const raw = readNonEmptyString(value)?.replace(/\s+/gu, ' ').trim();
  if (
    raw === undefined ||
    raw.length > EDGE_ENDPOINT_LABEL_MAX_CHARS ||
    endpointIds.some((id) => raw.includes(id))
  ) {
    return null;
  }
  if (sanitiseUserFacingText(raw, null).matches.length > 0) return null;
  return raw;
}

/**
 * Project a successful `EditGraphHandlerFact` (DL-7 PR B) into a
 * `RecentMutation`. Reads `safe_summary` verbatim — it has already
 * been sanitised at the emitter (raw-ID scrub + Phase 2A jargon
 * guard + 80-char cap) — so no further sanitisation here, and the
 * `cap()` wrapper is just a defence-in-depth re-application.
 *
 * `target_label` is taken from the first affected entity. The
 * fact's schema requires `safe_summary.min(1)` and each entity's
 * `label.min(1)`, so both are non-empty when the fact arrives here;
 * the `?? 'the decision model'` fallback handles the rare case of
 * an empty `affected_entities` array (allowed by the schema for
 * structural-without-target edits).
 */
function summariseEditGraph(
  result: Record<string, unknown> | undefined,
): RecentMutation | null {
  if (!result || typeof result !== 'object') return null;
  // Defence in depth: the schema's `status` enum is `'applied' | 'noop'`
  // today and the dispatcher's `isSuccessfulAppliedMutation` gate
  // already excludes rejected edits from emitting a fact at all.
  // Filtering on 'noop' AND 'rejected' here is belt-and-braces: if a
  // future schema bump adds a 'rejected' literal (or any non-applied
  // status), the projection treats it as not-surface-able. The
  // top-level `isNoopFact` filter in `summariseMutation` is the
  // primary gate; this is the secondary.
  const status = (result as { status?: unknown }).status;
  if (status === 'noop' || status === 'rejected') return null;
  const safeSummary = (result as { safe_summary?: unknown }).safe_summary;
  if (typeof safeSummary !== 'string' || safeSummary.length === 0) return null;
  const entities = (result as { affected_entities?: unknown }).affected_entities;
  const firstLabel =
    Array.isArray(entities) && entities.length > 0 && typeof entities[0]?.label === 'string'
      ? entities[0].label
      : 'the decision model';
  return {
    action: 'graph_edited',
    summary: cap(safeSummary),
    target_label: cap(firstLabel),
  };
}

function summariseAddConstraint(
  result: Record<string, unknown> | undefined,
  notCheckableConstraintIds?: ReadonlySet<string>,
): RecentMutation | null {
  if (!result || typeof result !== 'object') return null;
  const after = (result as { after?: unknown }).after;
  const before = (result as { before?: unknown }).before;
  if (!isRecord(after)) return null;

  const operator = readOperator(after.operator);
  if (operator === null) return null;
  const value = typeof after.value === 'number' ? after.value : null;
  if (value === null || !Number.isFinite(value)) return null;

  // Defensive: the constraint label is always present on a well-formed
  // GoalConstraint, but if the persisted shape lacks it (older facts,
  // partial writes) we leave the summary generic rather than fabricate
  // a target name.
  const label = readNonEmptyString(after.label) ?? 'this factor';
  const unit = readNonEmptyString(after.unit);

  // `before` is null on a fresh add, populated on an in-place update.
  const isUpdate = isRecord(before);
  const formatter = isUpdate ? formatConstraintUpdated : formatConstraintAdded;
  const summary = formatter({
    targetLabel: label,
    operator,
    value,
    ...(unit !== undefined ? { unit } : {}),
    // R1 S4-core: a change from today is said as the change, never "at most 0.1" (`sayLimitInFrame`).
    ...(typeof after.value_frame === 'string' ? { valueFrame: after.value_frame } : {}),
  });

  // ⭐ THE VERDICT, JOINED BY IDENTITY.
  //
  // `result.target_id` is the CONSTRAINT id, not the node id — derived at
  // `add-constraint.ts:975` (`target_id: newConstraint.constraint_id`), NOT
  // inferred from the field's name, which reads like a node reference and is
  // not one. Joining on it binds this entry to the row that exists in
  // `goal_constraints` RIGHT NOW: a limit the user has since removed is absent
  // from the set and is silently left unqualified, which is the correct
  // direction (we have not established anything about a row that is gone).
  //
  // ⚠ Deliberately NOT `after.node_id`. That would be an open-record read of a
  // field the schema does not declare, and it would keep speaking about a
  // constraint that is no longer on the model.
  const constraintId = result.target_id;
  const notCheckable =
    typeof constraintId === 'string' &&
    notCheckableConstraintIds !== undefined &&
    notCheckableConstraintIds.has(constraintId);

  return {
    action: 'constraint_added',
    summary: cap(summary),
    target_label: cap(label),
    ...(notCheckable ? { constraint_not_checkable: 'target_records_no_value' as const } : {}),
  };
}

function summariseSetFactorValue(
  result: Record<string, unknown> | undefined,
): RecentMutation | null {
  if (!result || typeof result !== 'object') return null;
  const after = (result as { after?: unknown }).after;
  const before = (result as { before?: unknown }).before;
  if (!isRecord(after) || !isRecord(before)) return null;

  // `formatFactorChange` reads raw_value with a fallback to value, plus
  // optional unit and label. We mirror the handler-side resolution.
  const beforeValue = numericFrom(before, ['raw_value', 'value']);
  const afterValue = numericFrom(after, ['raw_value', 'value']);
  if (beforeValue === null || afterValue === null) return null;

  const label =
    readNonEmptyString(after.label) ??
    readNonEmptyString(before.label) ??
    'a factor';

  const beforeUnit = readNonEmptyString(before.unit);
  const afterUnit = readNonEmptyString(after.unit);

  const summary = formatFactorChange({
    label,
    before: {
      raw_value: beforeValue,
      ...(beforeUnit !== undefined ? { unit: beforeUnit } : {}),
    },
    after: {
      raw_value: afterValue,
      ...(afterUnit !== undefined ? { unit: afterUnit } : {}),
    },
  });

  return {
    action: 'factor_value_updated',
    summary: cap(summary),
    target_label: cap(label),
  };
}

// -----------------------------------------------------------------------
// helpers — kept private; tests exercise them through projectRecentChanges
// -----------------------------------------------------------------------

function isRecord(v: unknown): v is Record<string, unknown> {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function readOperator(v: unknown): '>=' | '<=' | null {
  return v === '>=' || v === '<=' ? v : null;
}

function readNonEmptyString(v: unknown): string | undefined {
  return typeof v === 'string' && v.trim().length > 0 ? v : undefined;
}

function numericFrom(
  rec: Record<string, unknown>,
  keys: readonly string[],
): number | null {
  for (const k of keys) {
    const v = rec[k];
    if (typeof v === 'number' && Number.isFinite(v)) return v;
  }
  return null;
}

/**
 * Truncate to {@link RECENT_CHANGES_SUMMARY_MAX_CHARS}. We append a single
 * ellipsis character (U+2026) on truncation so the budget guarantee
 * remains exact and the cut is visible. Strings within budget are
 * returned unchanged.
 */
function cap(s: string): string {
  if (s.length <= RECENT_CHANGES_SUMMARY_MAX_CHARS) return s;
  // Reserve one char for the ellipsis marker so the post-truncation
  // string is exactly RECENT_CHANGES_SUMMARY_MAX_CHARS characters long.
  return `${s.slice(0, RECENT_CHANGES_SUMMARY_MAX_CHARS - 1)}…`;
}

// E4 sentinel returned for empty inputs. Stable, distinguishable from a real
// hash so log readers do not confuse "no recent changes" with a hash that
// happens to render as twelve zero hex digits.
export const RECENT_CHANGES_HASH_EMPTY = 'empty';

// Twelve hex chars = 48 bits = roughly one collision per 16M entries; matches
// the project's existing short-hash conventions (graph hashes, fact hashes).
const RECENT_CHANGES_HASH_LENGTH = 12;

/**
 * E4 — short content hash for the curated `recent_changes` projection.
 *
 * Used as pre-LLM telemetry evidence in the routing payload assembly so
 * operators can prove `recent_changes` reached the LLM-bound context
 * without logging the curated content itself. Returns
 * {@link RECENT_CHANGES_HASH_EMPTY} when the input has no entries.
 *
 * Canonicalisation: stable key order on each entry (`action`, `summary`,
 * `target_label`) and array order preserved (newest-first, matching
 * {@link projectRecentChanges}). SHA-256, truncated to twelve hex
 * characters.
 *
 * ⚠ THE TWO OPTIONAL KEYS ARE SPREAD CONDITIONALLY AND APPENDED LAST, WHICH IS
 * WHAT KEEPS THIS BACKWARD-COMPATIBLE. An unconditional key would move the hash
 * of every entry that does not carry it — i.e. all historic ones — and the
 * telemetry this feeds exists precisely to distinguish "same payload" from
 * "different payload" across calls. Including the verdict when it IS present is
 * equally load-bearing: omitting it would let the verdict be dropped anywhere
 * downstream while the operator evidence still read "unchanged".
 *
 * ⚠ THE CONDITIONAL SPREAD IS BELT-AND-BRACES, AND SAYING SO IS THE HONEST
 * FORM. Making the key unconditional is a DEMONSTRATED-EQUIVALENT mutant at
 * this tip, not a surviving one: `JSON.stringify` drops undefined-valued keys,
 * so both spellings serialise identically (measured, not reasoned about —
 * `{a:1,b:undefined}` → `{"a":1}`). The guarantee therefore has TWO independent
 * sources today and no test can tell them apart. The conditional form is kept
 * because the OTHER source is an implementation detail of the canonicaliser: a
 * future stable-key sorter, or a switch to a serialiser that emits `null` for
 * undefined, would silently move every historic hash. Do not "simplify" it on
 * the grounds that nothing goes red — nothing can.
 *
 * **Not** a security primitive. Two different curated payloads with the
 * same prefix-of-12 hex chars are theoretically possible; for E4 evidence
 * that risk is acceptable because the operator only needs to distinguish
 * "same payload across calls" from "different payload across calls".
 */
export function computeRecentChangesHash(items: readonly RecentMutation[]): string {
  if (items.length === 0) return RECENT_CHANGES_HASH_EMPTY;
  const canonical = items.map((m) => ({
    action: m.action,
    summary: m.summary,
    target_label: m.target_label,
    ...(m.transition !== undefined ? { transition: m.transition } : {}),
    ...(m.constraint_not_checkable !== undefined
      ? { constraint_not_checkable: m.constraint_not_checkable }
      : {}),
  }));
  return createHash('sha256')
    .update(JSON.stringify(canonical))
    .digest('hex')
    .slice(0, RECENT_CHANGES_HASH_LENGTH);
}

/**
 * E4 — derive the pre-LLM telemetry payload for `recent_changes` from a
 * possibly-malformed source. Tolerates the regression case where the
 * field is missing, `null`, or a non-array; in those cases reports
 * `field_present: false`, `count: 0`, and the empty-sentinel hash so
 * the regression is detectable from logs without a code-search.
 *
 * Extracted into its own helper for unit-testability — the route-level
 * emit site in `turn-executor.ts` is hard to reach with a malformed
 * context pack, but the regression signal is exactly what operators
 * need from this telemetry.
 *
 * Type signature deliberately accepts `unknown` as the source field so
 * callers don't have to widen the type at the emit site.
 */
export interface RecentChangesEvidence {
  readonly count: number;
  readonly field_present: boolean;
  readonly hash: string;
}

export function deriveRecentChangesEvidence(
  source: { readonly recent_changes?: unknown },
): RecentChangesEvidence {
  const field = source.recent_changes;
  if (!Array.isArray(field)) {
    return { count: 0, field_present: false, hash: RECENT_CHANGES_HASH_EMPTY };
  }
  const items = field as readonly RecentMutation[];
  return {
    count: items.length,
    field_present: true,
    hash: computeRecentChangesHash(items),
  };
}
