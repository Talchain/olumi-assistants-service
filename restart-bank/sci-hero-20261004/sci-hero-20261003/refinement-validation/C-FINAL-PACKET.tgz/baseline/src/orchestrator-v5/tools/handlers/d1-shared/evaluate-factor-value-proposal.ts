/**
 * Shared evaluator for `set_factor_value` proposal parameters. The single
 * source of truth for the cap / range / unit / delta guards that the
 * handler's `normaliseFactorValue` runs at execute time.
 *
 * The predicate is called from THREE places:
 *
 *   1. The handler (`normaliseFactorValue` delegates to this — task #3
 *      refactor).
 *   2. The validator (validation-registry / validator — task #4 wiring) so
 *      structural-pass proposals that would fail at execute are rejected
 *      earlier with `invalid_parameter`, routing into the existing
 *      recoverable path.
 *   3. The deterministic-value-update synthesis site in TurnExecutor
 *      (task #5) so synthesised proposals never reach the handler with
 *      parameters the handler would reject.
 *
 * Calling the same predicate from all three sites is the parity contract
 * that closes the AC.1 invariant: any proposal accepted by validator AND
 * precheck must never produce `parameter_invalid_at_execute` at the
 * handler — because the handler runs the same rules.
 *
 * The predicate does NOT throw. It returns a discriminated union so
 * callers can compose the rejection into a domain-appropriate response
 * (validator → invalid_parameter; TurnExecutor → clarify downgrade;
 * handler → D1HandlerError(PARAMETER_INVALID)).
 *
 * User-facing copy is uniform across rejection reasons — see
 * `SET_FACTOR_VALUE_USER_GUIDANCE`. The granular `reason` enum is for
 * telemetry only; the user-visible string in `specific_issue` matches
 * the canonical handler copy that `normaliseFactorValue` produces today.
 */

import { formatValueWithUnit } from './format-confirmation.js';
import { recoverScaleFrame } from './scale-frame.js';
import { currencyAlphabetKey } from '../../../../utils/currency-alphabet.js';

/**
 * Operators the handler's `applyOperator` supports. Mirrors the union
 * inside `set-factor-value.ts` — kept here so the predicate is
 * self-contained and the validator wiring doesn't need to import a
 * handler-internal helper.
 *
 * Wire enum from `routing/types.ts` is `'set' | 'increase' | 'decrease'
 * | 'multiply'`; we mirror that exactly.
 */
export type FactorValueOperator = 'set' | 'increase' | 'decrease' | 'multiply';

/**
 * AN EMPTY OR WHITESPACE-ONLY UNIT IS NOT A UNIT. Canonicalise it to
 * `undefined` so exactly one representation of "this has no unit" exists.
 *
 * ⚠ THE DEFECT THIS CLOSES (found in review of the 2.159 salvage, proven at the
 * bytes). Both parse sites already computed `inputHasUnit` as
 * `unit.length > 0` — i.e. they ALREADY treated `''` as "no unit" — while
 * carrying `''` through in the `unit` field itself. Two fields, two answers,
 * from the same input. The consequences of that disagreement:
 *
 *   • `{ value: 5, unit: '' }` on a unitless factor passed guard 2c (whose
 *     exemption was `unit.length > 0`) and the handler then PERSISTED
 *     `unit: ''` via `after.unit = parsed.unit ?? before.unit`;
 *   • from then on `factorUnit === ''`, so 2c was permanently inert for that
 *     factor — falsifying the guard's own claim ("a unit it did not have");
 *   • and every later bare sub-1 edit hit `bare_ratio_on_unit_factor`, whose
 *     copy interpolates the unit: "0.5 looks like a proportion, not a value
 *     in . Tell me the amount in ." — malformed text shown to a user.
 *
 * Canonicalising is preferred over widening 2c to "any defined unit is a
 * declaration": that alternative would REFUSE `{ unit: '' }` and render
 * "applying a value in  would change what it measures" — creating a second
 * malformed-copy path inside the guard meant to remove one. It also leaves the
 * `inputHasUnit` disagreement in place.
 *
 * Applied at BOTH ends, deliberately: at the two parse sites so `''` is never
 * WRITTEN, and at this predicate's entry so a factor already carrying `''`
 * (reachable before any of this work) READS as unitless — which is what
 * retires the malformed-copy path rather than merely stopping new instances.
 */
/**
 * ⭐ A FACTOR STORED AS A 0–1 PROPORTION, BY THE ONE RULE (the docblock at its use in `evaluateFactorValueProposal`):
 * a cap of exactly 1, or a proportion-class unit token that NOTHING CONTRADICTS (no cap, no recoverable
 * `value`/`raw_value` frame). The token alone is not a range declaration. Exported so a second reader
 * (`agent-lane/relative-figure.ts`, a percent read in a share factor's frame) uses this rule, never a copy.
 */
export const PROPORTION_UNIT_TOKENS: ReadonlySet<string> = new Set(['scale', 'unit_interval', 'ratio', 'proportion']);
/**
 * ⛔ A UNIT THAT STATES A SHARE OR A 0–1 RANGE (MG SUCCESSOR #75 5910272624; R3 candidate-2 witness, served CEE 2cd7823).
 * The served drafter writes 0–1 quantities as `share (0-1)`, `fraction of workloads`, `adoption fraction (0-1)`, `0-1`, …:
 * 16 of 18 uncapped 0–1 factors in 75 served drafts, none of them in the closed tokens above, so the user's "25%" on
 * "GCP unit-cost saving" (`share (0-1)`, 0.2) was carded "0.2% → 25%" and the write refused it. Still CLOSED: a head word
 * `share` / `fraction` / `proportion` (never `shares`, a count), or a written `0-1` range; never a `0/1` switch, and never
 * a unit carrying `%` / `percent` ("market share %" holds 23, not 0.23). And a value outside [0, 1] contradicts it.
 */
function statesShareOrUnitRange(unit: string, value: number | undefined): boolean {
  if (value !== undefined && (value < 0 || value > 1)) return false;
  if (/%|percent/.test(unit)) return false;
  // A switch beats a range: `binary (0-1)`, `on/off (0–1)`, `0/1`, `yes/no (0 or 1)` are 0 OR 1, never a share.
  if (/\b0\s*\/\s*1\b|\bbinary\b|\binactive\b|\bon\s*\/\s*off\b|\byes\s*\/\s*no\b/.test(unit)) return false;
  // A written 0–1 range: `0-1`, `0–1`, `0 to 1`, `[0, 1]` — never `0-10`, `0-100` or `0–1,000`.
  if (/(?:^|[^\d.,])0\s*(?:[-\u2013]|to)\s*1(?![\d.]|,\d)/.test(unit) || /\[\s*0\s*,\s*1\s*\]/.test(unit)) return true;
  // Any other bracket states another scale, a currency or a count (`(0-100)`, `(1-5)`, `(£)`, `(pct)`, `(pp)`, `(people)`,
  // P0 PARTNER CR 5910740141): the unit is not a share, whatever its words, even with no stored value to contradict it.
  if (/[([]/.test(unit)) return false;
  // Or a HEAD noun share / fraction / proportion: after a comparative tail ("versus AWS", "vs today", "relative to …") is
  // cut, the word before "of", else the last word; or `proportion` / `fraction` FIRST (served cut-costs: "proportion
  // reduction versus AWS"). Never `share` first ("share price"), never with "per" (`£ per share`), never `shares` (a count)
  // or `fractional FTE`.
  const core = unit.replace(/\b(?:versus|vs\.?|relative to|compared (?:to|with)|against)\b.*$/, '').trim();
  if (/\bper\b/.test(core)) return false;
  const words = core.split(/[^a-z]+/).filter((w) => w !== '');
  const of = words.indexOf('of');
  const head = of > 0 ? words[of - 1] : words[words.length - 1];
  return head === 'share' || head === 'fraction' || head === 'proportion' || words[0] === 'proportion' || words[0] === 'fraction';
}
export function isProportionScaledFactor(f: { unit: unknown; cap: number | undefined; value: number | undefined; raw_value: number | undefined }): boolean {
  const unit = typeof f.unit === 'string' ? f.unit.trim().toLowerCase() : '';
  const isProportionUnit = PROPORTION_UNIT_TOKENS.has(unit) || (unit !== '' && statesShareOrUnitRange(unit, f.value));
  return f.cap === 1 || (isProportionUnit && f.cap === undefined && recoverScaleFrame({ value: f.value, raw_value: f.raw_value }) === undefined);
}

export function canonicaliseUnitForDisplay(unit: string | undefined): string | undefined {
  if (unit === undefined) return undefined;
  const trimmed = unit.trim();
  return trimmed.length > 0 ? trimmed : undefined;
}

/**
 * THE KEY TWO SPELLINGS ARE COMPARED ON — trimmed AND case-folded.
 *
 * ⚠ A DIFFERENT QUESTION FROM `canonicaliseUnitForDisplay`, AND THE TWO MUST NOT
 * BE MERGED. That one answers "what do we PERSIST and SHOW?" and therefore keeps
 * the user's own case; this one answers "are these the SAME UNIT?" and therefore
 * folds it. They were one function called `canonicaliseUnit` until the C4 lane,
 * and that single name is what produced the live defect below.
 *
 * MEASURED at 3ab35d34: a proposal in 'Months' against a factor stored as
 * 'months' was refused `unit_mismatch` with the copy "This factor uses months;
 * the value provided is in Months." — a refusal naming two strings a user reads
 * as identical. PLoT's `classifyUnitCompatibility` reconciled the same pair, so
 * the two services disagreed on the same input.
 *
 * ⚠ FOLDING CASE IS NOT LOOSENING THE GATE. It equates SPELLINGS of one unit and
 * nothing else: 'months' vs 'weeks' (a 4.33x conversion) and the currency pair
 * are still `unit_mismatch`, pinned as opposite-direction twins in
 * `__tests__/unit-comparison-key.test.ts`. Never widen this to strip punctuation
 * or match prefixes — that would bless a real rescale as a spelling.
 *
 * ⭐ TWO MORE SPELLINGS FOLD, ON EXACTLY THE SAME TERMS, AND NOTHING ELSE DOES.
 *   · THE CURRENCY ALPHABET — `£` ≡ `GBP`. Not a new position: `utils/
 *     currency-alphabet.ts` already owns that vocabulary and already declares
 *     the two equal, in a function whose own docblock says "NOT A CONVERSION".
 *     This calls that owner rather than keeping a second table.
 *   · THE RATE SEPARATOR — `a/b` ≡ `a / b` ≡ `a per b`, with the denominator
 *     folded to one spelling from a CLOSED period list. Needed because live
 *     factors are stored both ways (`£/month`, 59 nodes; `contacts per week`).
 *
 *   The rescales stay refusals and are pinned as such in
 *   `routing/__tests__/natural-rate-unit.test.ts`: `£/month` ≠ `£/day`,
 *   `£/month` ≠ `£/year`, `£` ≠ `£/month`, `£/month` ≠ `$/month`, plus the
 *   existing `months` ≠ `weeks` and `%` ≠ `pp`.
 *
 * NOT for percent classification: a unit's IDENTITY ("are these the same unit?")
 * and its SCALE CONVENTION ("what multiplier does this unit imply?") are two more
 * different questions, and this function answers only the first. Do not extend it
 * to classify scales.
 */
/**
 * The periods a rate denominator may name, each folded to ONE spelling. Closed
 * on purpose: an open match would let `£/customer` and `£/customers` fold while
 * quietly folding things that are not periods at all.
 */
const RATE_DENOMINATOR_SPELLINGS: Readonly<Record<string, string>> = {
  second: 'second', seconds: 'second',
  minute: 'minute', minutes: 'minute',
  hour: 'hour', hours: 'hour',
  day: 'day', days: 'day',
  week: 'week', weeks: 'week',
  fortnight: 'fortnight', fortnights: 'fortnight',
  month: 'month', months: 'month',
  quarter: 'quarter', quarters: 'quarter',
  year: 'year', years: 'year',
  annum: 'year',
};

/** `a/b`, `a / b`, `a per b` — the three ways this estate spells one rate. */
const RATE_SEPARATOR_PATTERN = /\s*(?:\/|\bper\b)\s*/;

/** One side of a unit, folded: currency alphabet first, then case. */
function foldUnitSide(side: string): string {
  return currencyAlphabetKey(side.trim()).toLowerCase();
}

export function unitComparisonKey(unit: string | undefined): string | undefined {
  const display = canonicaliseUnitForDisplay(unit);
  if (display === undefined) return undefined;

  // ── RATES ────────────────────────────────────────────────────────────────
  // Split on the FIRST separator only, so `£ ARR per customer` folds as
  // (`£ ARR`, `customer`) and a pathological `a/b/c` is left alone rather than
  // silently reassociated.
  const sepMatch = RATE_SEPARATOR_PATTERN.exec(display);
  if (sepMatch !== null && sepMatch.index > 0) {
    const numerator = display.slice(0, sepMatch.index);
    const denominator = display.slice(sepMatch.index + sepMatch[0].length);
    if (numerator.trim().length > 0 && denominator.trim().length > 0) {
      const foldedDenominator = denominator.trim().toLowerCase();
      const period = Object.prototype.hasOwnProperty.call(
        RATE_DENOMINATOR_SPELLINGS,
        foldedDenominator,
      )
        ? RATE_DENOMINATOR_SPELLINGS[foldedDenominator]!
        : foldedDenominator;
      return `${foldUnitSide(numerator)}/${period}`;
    }
  }

  // ── A BARE PERIOD UNIT ───────────────────────────────────────────────────
  // The same closed table, applied on the side of this function that a rate
  // never reaches. Witnessed on deployed staging (build 9b98fcd): a factor the
  // UI renders as "9 months" REFUSED "change ... to 12 months" with "This
  // factor uses months; the value provided is in month" — because CQE
  // normalises the period to the singular while the canonical unit is plural.
  // The user was refused for typing the unit exactly as it was shown to them.
  //
  // This is the SAME fold on the SAME closed vocabulary, not a widening. Two
  // spellings of ONE period become one key; two DIFFERENT periods stay two
  // keys, which is precisely what a closed table buys over a stemmer — the
  // `months` vs `weeks` pin in `natural-rate-unit.test.ts` holds it down.
  const folded = foldUnitSide(display);
  return Object.prototype.hasOwnProperty.call(RATE_DENOMINATOR_SPELLINGS, folded)
    ? RATE_DENOMINATOR_SPELLINGS[folded]!
    : folded;
}

/**
 * The ONE period a single denominator word names, on the closed table above ("quarters" → quarter, "annum" → year), or null
 * for any other word. Exported so a typed unit's period is read on the SAME vocabulary `unitComparisonKey` folds with
 * (CEE #2468 CHANGES_REQUIRED, DL note to MG): never a second list.
 */
export function ratePeriodWord(word: string): string | null {
  const folded = word.trim().toLowerCase();
  return Object.prototype.hasOwnProperty.call(RATE_DENOMINATOR_SPELLINGS, folded) ? RATE_DENOMINATOR_SPELLINGS[folded]! : null;
}

/**
 * The period a TYPED rate unit is per — its denominator, split exactly as `unitComparisonKey` splits it (the first "/" or
 * "per") and read by `ratePeriodWord` — or null when the unit is no rate over a period ("£", "GBP MRR", "£ per seat").
 * "£ per year" → year, "£/quarter" → quarter, "GBP per annum" → year. Reads a unit string only, never the user's words.
 */
export function ratePeriodOf(unit: string | undefined): string | null {
  const display = canonicaliseUnitForDisplay(unit);
  if (display === undefined) return null;
  const sepMatch = RATE_SEPARATOR_PATTERN.exec(display);
  if (sepMatch === null || sepMatch.index === 0) return null;
  if (display.slice(0, sepMatch.index).trim().length === 0) return null;
  return ratePeriodWord(display.slice(sepMatch.index + sepMatch[0].length));
}

/**
 * Granular rejection reasons. Bound to the telemetry enum — additions
 * here require a plan amendment (see "Locked telemetry enums" in the
 * workstream plan). Reasons are ordered roughly by check sequence:
 * structural → delta-guards → range-guards.
 */
export type ProposalRejectionReason =
  | 'missing_value' // value parameter absent or wrong shape on the proposal
  | 'invalid_operator' // operator is not in the FactorValueOperator union
  | 'non_finite' // rawInput is NaN / Infinity / -Infinity
  | 'cap_non_positive' // cap <= 0 (nonsensical)
  | 'unit_mismatch' // proposal.unit and factor.unit both defined and differ
  | 'delta_no_existing_value' // operator !== 'set' AND factor has no finite raw_value
  | 'delta_no_cap_and_no_unit' // operator !== 'set' AND no cap AND no unit (ambiguous)
  | 'bare_number_outside_cap' // !inputHasUnit AND cap defined AND effectiveRaw outside [0, cap]
  | 'value_exceeds_cap' // inputHasUnit AND cap defined AND effectiveRaw outside [0, cap]
  | 'bare_ratio_on_unit_factor' // !inputHasUnit AND factor has a unit AND 0 < |rawInput| < 1 (looks like a normalised proportion)
  // ROADMAP 2.159 — SILENT SCALE REDECLARATION. The proposal would give a
  // factor that HAS a recorded value a unit / an upper limit it did not have.
  // That is a permanent change to what the factor MEASURES, not to its value,
  // and it happened with no consent step and no renormalisation.
  | 'unit_redeclares_scale'
  | 'cap_redeclares_scale';

/**
 * WHERE THE CEILING BEING ENFORCED CAME FROM. A separate question from
 * "is the value in range", and the two must not be answered by one predicate
 * (CLAUDE.md trap 21 — this estate's signature defect).
 *
 *   · `stated_on_this_proposal` — the ceiling arrived WITH the value, on the
 *     same proposal (`proposalCap`). Judging a proposal against a bound it
 *     supplies itself is coherent whoever authored it: both halves are part of
 *     the one change under judgement.
 *   · `inherited_from_the_factor` — the ceiling is the factor's stored
 *     `observed_state.cap`, an inherited fact the user is now contradicting.
 *
 * ⚠ THE SECOND MEMBER IS DELIBERATELY NOT CALLED "UNATTESTED" OR "AI-DRAFTED",
 * AND THE RESTRAINT IS THE POINT. No field names a cap's provenance under that
 * name: `rg -a` over `src/` for `cap_source|capSource|cap_provenance|
 * capProvenance|cap_confirmed|capConfirmed|cap_extraction` returns **0**, with
 * the contrast `source:` non-zero in the same sweep.
 *
 * ⚠⚠ BUT THAT SWEEP ENUMERATED GUESSED NAMES, AND A POSITIVE RECORD EXISTS
 * UNDER A NAME IT NEVER SPELLED. Corrected on independent review and
 * re-verified at the bytes here: `schemas/cee-v3.ts:133` declares
 * `extractionType: z.enum(["explicit", "inferred", "range", "observed"])` —
 * two fields below `cap:` at `:131`. It is written, not vestigial
 * (`adapters/llm/normalisation.ts:1093`), the draft prompt teaches the model
 * to emit it (`prompts/defaults-v12.ts:151`), and
 * `cee/transforms/provenance-display.ts` already classifies it. A brief
 * reading "£80–120k" is precisely the `range` class.
 *
 * So the accurate statement is NOT "no such record could exist". It is:
 * **a positive record exists and is not threaded to this seam.**
 * `FactorObservedStateSnapshot` (`routing/validator.ts:83-107`) carries `unit`
 * and `cap` and NOT `extractionType`, so this predicate cannot read it today.
 * `inherited ⇒ unconfirmed` therefore stands as the correct conservative
 * default HERE — but it is a WIRING GAP, not a structural absence, and
 * threading `extractionType` into that snapshot is the implementable next
 * step rather than a re-derivation.
 *
 * ⚠ AND `observed_state.source` IS NOT A SUBSTITUTE, WHICH IS WHY THIS
 * FUNCTION DOES NOT READ IT. That field answers *"who authored the VALUE?"*
 * (`transforms/provenance-display.ts` owns it and names the question in those
 * words). The two facts move independently and the divergence is REACHABLE on
 * exactly the path this module exists for: a user edit within the stored cap
 * is stamped with `canonicalise-value-ops.ts`'s exported `USER_EDIT_SOURCE` by
 * `stampUserEditProvenance`, while the cap beside it is untouched — so reading
 * value-authorship here would declare the drafting model's own ceiling
 * "confirmed" because the user once corrected the number underneath it, and
 * would then refuse their NEXT correction. That is the founder's defect,
 * rebuilt out of the field that looked like the fix.
 *
 * ⚠ THE STAMP IS NAMED BY ITS EXPORTED CONSTANT ABOVE, NOT SPELLED OUT, AND
 * THAT IS DELIBERATE. `cee/transforms/__tests__/no-brief-derived-user-override
 * .writers.test.ts` sweeps every non-test file under `src/` for the literal and
 * requires each carrier to sit in a REVIEWED manifest whose one question is
 * *"by what path does the value reach the stamp?"*. This module has no such
 * path — it never touches `observed_state.source` — so an entry claiming one
 * would be a false statement in the register that exists to keep those
 * statements true. Spell the constant, not the string.
 *
 * So the honest reading of a stored cap is the contract's own instruction for
 * an absent provenance stamp, quoted verbatim from `ObservedStateSchema`:
 *
 *   > Absence means the producer stamped no provenance — a consumer MUST NOT
 *   > read absence as any particular class; classify unknown/absent as
 *   > neutral, never guess.
 *
 * Neutral is not "confirmed". A bound may only be enforced against the user on
 * a positive record that someone set it, and no such record reaches this
 * predicate — see the correction above: the record exists on the node
 * (`extractionType`) but is absent from the snapshot this function is given.
 * Hence: inherited ⇒ unconfirmed, on the evidence available HERE.
 */
export type CapBoundOrigin = 'stated_on_this_proposal' | 'inherited_from_the_factor';

/**
 * Classify the ceiling this evaluation will enforce, or `undefined` when the
 * factor is uncapped and no ceiling applies.
 *
 * Computed over the SAME precedence the predicate applies (`proposalCap ??
 * factorCap`), deliberately by reading the identical expression, so the origin
 * cannot come to describe a different number from the one being enforced —
 * the two-same-named-authorities defect in miniature.
 */
export function capBoundOrigin(input: {
  readonly proposalCap?: number;
  readonly factorCap?: number;
}): CapBoundOrigin | undefined {
  if (input.proposalCap !== undefined) return 'stated_on_this_proposal';
  if (input.factorCap !== undefined) return 'inherited_from_the_factor';
  return undefined;
}

/**
 * A ceiling that was enforced against the user although nothing on record
 * confirms it, carried on the rejection so a caller can offer the remedy
 * rather than re-deriving one (a second bound-widening policy would be the
 * hand-maintained mirror this estate keeps paying for).
 *
 * `rescale_cap_to` comes from {@link suggestExtendedCap}, which is already the
 * one policy the validator, the composer's rescale chip and the persisted
 * pending all agree on. It is guaranteed to ADMIT the value it was computed
 * for — pinned in the spec, because a remedy the next turn refuses again is
 * the failure mode nothing else in the suite would see.
 */
export interface UnconfirmedCapBound {
  /** The ceiling that was enforced. */
  readonly cap: number;
  /** A ceiling that would admit the value the user actually stated. */
  readonly rescale_cap_to: number;
}

/**
 * Result of evaluating a proposal. `ok: true` means the handler's
 * `normaliseFactorValue` would not throw for these inputs. `ok: false`
 * carries the granular reason (telemetry) and the canonical user
 * message (`specific_issue`).
 *
 * `unconfirmed_bound` is ADDITIVE AND OPTIONAL, and that is a safety property
 * rather than convenience: every existing consumer branches on `.ok` alone and
 * therefore still REFUSES, so no caller can be upgraded by accident into
 * writing a value its own normalisation cannot represent (`normaliseFactorValue`
 * computes `value = raw / cap` with no clamp — accepting £100,000 against a
 * stored cap of £100 would persist a normalised level of 1,000). A caller opts
 * in by reading the field and applying the widened bound; until it does, it
 * degrades to today's behaviour and never to a corrupt write.
 */
export type FactorValueProposalEvaluation =
  | { readonly ok: true }
  | {
      readonly ok: false;
      readonly reason: ProposalRejectionReason;
      readonly specific_issue: string;
      /**
       * Present EXACTLY when the rejection was decided by a ceiling inherited
       * from the factor, on a proposal that stated its own scale. Absent for a
       * ceiling stated on the proposal, for a bare number (nothing in the
       * input asserts a scale, so the ceiling is the only scale evidence there
       * is), and for every rejection that is not a ceiling breach.
       */
      readonly unconfirmed_bound?: UnconfirmedCapBound;
    };

export interface EvaluateFactorValueProposalInput {
  /** The user-units number on the proposal (operator's right-hand side). */
  readonly rawInput: number;
  /** Operator carried on the proposal parameter. Defaults to `'set'` if undefined. */
  readonly operator?: FactorValueOperator;
  /** Explicit unit on the proposal, if any. */
  readonly unit?: string;
  /** Explicit cap on the proposal, if any. */
  readonly proposalCap?: number;
  /** Cap stored on the factor's observed_state, if any. */
  readonly factorCap?: number;
  /**
   * The factor's stored unit, if any. Used as fallback when the proposal
   * parameter omits the unit.
   */
  readonly factorUnit?: string;
  /**
   * The factor's stored user-units value (`raw_value`), used as the
   * left-hand side of delta operators. Missing / non-finite values
   * short-circuit to `delta_no_existing_value` BEFORE the operator is
   * applied — never silently defaults to 0 (regression of staging
   * 2fcd2221 fixed: AC.3).
   */
  readonly factorExistingRaw?: number;
  /**
   * ROADMAP 2.159 — the factor's stored `observed_state.value` /
   * `observed_state.raw_value`, verbatim. Distinct from `factorExistingRaw`,
   * which is the DE-NORMALISED user-unit LHS for delta operators; these are
   * the un-inverted stored numbers.
   *
   * Read for ONE purpose: to establish that the factor already carries a
   * recorded state, which is what makes a proposal-supplied unit or cap a
   * REDECLARATION (guards 2c / 2d) rather than a first-time declaration.
   * Their MAGNITUDE is deliberately never inspected — see the note above
   * guard 2c for why value magnitude cannot classify a factor's scale.
   *
   * Optional: a caller that omits them (an older test mock, a lookup adapter
   * with no `observed_state`, or `encode-option-interventions.ts`) leaves both
   * gates inert — exactly today's behaviour. Absence never tightens a guard.
   */
  readonly factorObservedValue?: number;
  readonly factorObservedRawValue?: number;
  /**
   * ⭐⭐ TRAP 21 — THE SECOND QUESTION, NAMED APART: "is there a SCALE here for
   * a declaration to overwrite?" (2026-09-11, the journey-witnessed dead end).
   *
   * The two fields above answer *"does this factor carry a VALUE?"*, and 2c /
   * 2d have been asking that in place of the question they actually need. The
   * two answers come apart on exactly one shape, and it is the shape the
   * analysis seam refuses: a capless, unitless baseline outside [0,1] with no
   * recoverable frame (`{value: 250000, raw_value: 250000}`). There IS a
   * value. There is NO scale. A cap or a unit on it is a FIRST declaration.
   *
   * THE LOOP THIS CLOSES, measured on deployed staging. The run refuses with
   * `baseline_scale_unresolved` and its copy asks for a range
   * (`run-analysis.ts:666` — *"recorded as a bare amount with no range for me
   * to measure it against"*). Supplying that range hit 2d; supplying a unit
   * hit 2c — *"This factor is recorded without a unit"*, the second refusal in
   * the witness. Both were sealed by `factorHasRecordedValue`, which the
   * user's OWN accepted edit had just made true. The product asked for a
   * range and then refused the range.
   *
   * ⚠ THE CALLER DERIVES THIS FROM THE ANALYSIS GATE, NEVER FROM A RULE
   * WRITTEN HERE. `set-factor-value.ts` computes it with
   * `findScaleIncoherentBaselineFactorIds` — the same function `run_analysis`
   * calls — so the edit seam and the analysis seam cannot drift into
   * disagreeing about which factors are unusable. That matters more than it
   * looks: the gate's exemptions (a recoverable pair frame, and the ratified
   * round-5 astride-1 class where the factor's own user-authored
   * interventions establish its raw frame) come along for free, and a factor
   * whose analysis COMPUTES today is never admitted here. Re-implementing the
   * test in this module would be the hand-maintained mirror (trap 12) that
   * this estate keeps paying for.
   *
   * ⚠ IT DOES NOT WIDEN THE GATES. Both harms 2c / 2d were written for sit on
   * a factor whose recorded scale is READABLE — the two-turn launder's 0.9 and
   * the one-step cap dodge's 0.7 are both inside [0,1] — so both still refuse,
   * pinned in
   * `__tests__/evaluate-factor-value-proposal-scale-declaration-on-unusable-scale.test.ts`.
   *
   * Optional, and `false` by default: every caller that does not thread it
   * (the validator, `encode-option-interventions.ts`, existing mocks) keeps
   * exactly today's behaviour BY CONSTRUCTION rather than by assumption.
   */
  readonly factorRecordedScaleIsUnusable?: boolean;
  /**
   * When true, the parameter arrived with an explicit unit. Mirrors
   * `parseProposalValue`'s flag — bare numbers vs unit-bearing values
   * have different guard rules (`bare_number_outside_cap` vs
   * `value_exceeds_cap`).
   */
  readonly inputHasUnit: boolean;
}

/**
 * Apply a numeric operator to `current` and `rhs`. Mirrors the handler's
 * `applyOperator` exactly so the predicate computes the same
 * `effectiveRaw` that the handler will. Exported so `set-factor-value.ts`
 * can re-import it from this module (single source of truth).
 *
 * `undefined` operator collapses to `'set'` — same default as the
 * handler.
 */
export function applyFactorValueOperator(
  current: number,
  operator: FactorValueOperator | undefined,
  rhs: number,
): number {
  switch (operator) {
    case undefined:
    case 'set':
      return rhs;
    case 'increase':
      return current + rhs;
    case 'decrease':
      return current - rhs;
    case 'multiply':
      return current * rhs;
  }
}

/**
 * Tagged result of resolving a factor's current user-unit raw value. Making
 * the three outcomes explicit (rather than collapsing to `number | undefined`)
 * keeps the delta and narration policies honest:
 *   - `resolved`  → a reliable user-unit value; usable as a delta LHS and as
 *                   the "from" side of a change receipt.
 *   - `missing`   → the factor has no recorded value at all.
 *   - `ambiguous` → the factor HAS a value but its scale cannot be reliably
 *                   recovered (e.g. a raw-value-less `%` whose divisor is
 *                   unknown). Distinct from `missing` so narration never
 *                   fabricates a numeric "from" value for it.
 * Both `missing` and `ambiguous` fail closed for delta operators and produce a
 * one-sided ("to X") receipt — but the distinction is preserved for clarity
 * and telemetry.
 */
export type ExistingRawResolution =
  | { readonly kind: 'resolved'; readonly raw: number }
  | { readonly kind: 'missing' }
  | { readonly kind: 'ambiguous' };

/**
 * Resolve a factor's current USER-UNIT raw value from its observed_state, for
 * use as the left-hand side of delta operators (increase / decrease / multiply)
 * and for change narration. This is the INVERSE of `normaliseFactorValue`,
 * which stores `value = raw / cap` for EVERY capped factor (including `%`) and
 * `value === raw` when uncapped:
 *
 *   - `raw_value` present         → `resolved` (canonical user-unit value).
 *   - percentage (`unit === '%'`) → reconstruct as `value*100` ONLY when the
 *                                   value is a normalised proportion in [0,1]
 *                                   AND the divisor is unambiguous (no cap, or
 *                                   `cap === 100`). A `%` value OUTSIDE [0,1]
 *                                   (e.g. 5 → 500% via extractor `raw/100`, or
 *                                   5% as a legacy raw value — both plausible)
 *                                   or a `cap !== 100` is `ambiguous` → fail
 *                                   closed; there is no reliable scale provenance.
 *   - non-% value outside [0,1]   → `resolved` as already-raw. A normalised
 *                                   value is always in [0,1], so a stored value
 *                                   >1 (e.g. {value:200000, cap:500000}) or <0
 *                                   is an off-contract graph carrying a raw
 *                                   value (symmetric; the cap-range guard
 *                                   contains out-of-range results).
 *   - capped non-%                → `resolved` = value * cap (inverse of normalise).
 *   - uncapped non-%              → `resolved` = value (uncapped stores value===raw).
 *   - no value at all             → `missing`.
 *
 * Without this de-normalisation, a legacy/capped factor that stored only the
 * normalised `value` (e.g. `{ value: 0.4, cap: 100000 }` = £40,000) would have
 * its delta computed against `0.4` instead of `40000` — corrupting the result
 * (`× 0.3` → £0.12 instead of £12,000) and narrating "from 0.4 to £0.12".
 * Shared so the validator precheck, the executor precheck, and the handler all
 * resolve the LHS identically (validator/handler parity).
 */
export function resolveExistingRawValue(snapshot: {
  readonly raw_value?: number;
  readonly value?: number;
  readonly unit?: string;
  readonly cap?: number;
  /**
   * The factor's SCALE FRAME, when the caller knows it — i.e. the divisor
   * `normaliseFactorValue` used on the way in. Optional and additive: every
   * pre-existing caller omits it and gets byte-identical behaviour.
   *
   * ⭐ WHY THIS PARAMETER EXISTS. The capless WRITE path
   * (`normalise-factor-value.ts`) resolves the frame through the shared owner
   * `resolveScaleFrame` and writes `{value: raw/frame, raw_value: raw}` with NO
   * percent special case — so a percent factor on a frame of 200 is stored
   * `{0.575, 115}`, correctly. This function is that write's INVERSE, and it
   * hard-coded the divisor at 100. The two halves of one round-trip therefore
   * disagreed by `frame/100` on exactly the class the frame ladder produces:
   * `deriveFactorScaleFrame` pins 100 only when `isPercentScaledUnit(unit) &&
   * max <= 100`, so NRR [95,115] frames at 200 and ROI [50,300] at 500.
   *
   * Supply it ONLY from `resolveScaleFrame` — never a locally-computed opinion
   * about the frame, which is the twin-owners defect this estate keeps paying
   * for. Passing 100 is identical to omitting it.
   */
  readonly scaleFrame?: number;
}): ExistingRawResolution {
  const { raw_value, value, unit, cap, scaleFrame } = snapshot;
  if (raw_value !== undefined) return { kind: 'resolved', raw: raw_value };
  if (value === undefined) return { kind: 'missing' };

  if (unit === '%') {
    // A raw-value-less % factor has no reliable scale provenance: a handler-
    // produced % always carries raw_value (short-circuited above), so this is
    // an extractor/legacy state. value=raw/frame is only safe to invert when
    // the value is a normalised proportion in [0,1] and the divisor is
    // unambiguous. A value outside [0,1] (5 → 500%? or legacy 5%?) is
    // genuinely ambiguous and stays fail-closed WITH OR WITHOUT a frame — a
    // frame supplies a divisor, never a licence to guess.
    //
    // The divisor, in precedence order:
    //   · a cap                → the capped convention (cap===100 or nothing);
    //     a stored cap flips the writer to the clamping path, so a capped
    //     factor is by construction NOT a framed one and the cap wins.
    //   · a supplied frame     → the divisor the writer actually used.
    //     Held to the SAME domain `resolveScaleFrame`/`recoverScaleFrame`
    //     prove (finite, strictly > 1), so a frame those would refuse is not
    //     applied here either and the two cannot hand consumers different
    //     classes of answer.
    //   · nothing              → 100, the percentage convention, unchanged.
    const framedDivisor =
      cap === undefined &&
      typeof scaleFrame === 'number' &&
      Number.isFinite(scaleFrame) &&
      scaleFrame > 1
        ? scaleFrame
        : undefined;
    // (A framed divisor implies `cap === undefined`, so it is already inside
    // `unambiguousDivisor` — it changes WHAT the divisor is, never WHETHER the
    // value is invertible. The admission rule is untouched by this parameter.)
    const unambiguousDivisor = cap === undefined || cap === 100;
    if (unambiguousDivisor && value >= 0 && value <= 1) {
      return { kind: 'resolved', raw: value * (framedDivisor ?? 100) };
    }
    return { kind: 'ambiguous' };
  }

  // Non-%: a normalised capped value is always in [0,1]; a value outside that
  // range is an off-contract graph carrying an already-raw value (normalisation
  // never produces >1 or <0). Handle > 1 and < 0 symmetrically; the downstream
  // cap-range guard contains any out-of-range result.
  if (value < 0 || value > 1) return { kind: 'resolved', raw: value };
  // capped → value*cap (inverse of normaliseFactorValue); uncapped →
  // value === raw_value.
  return { kind: 'resolved', raw: cap !== undefined ? value * cap : value };
}

/**
 * Pre-execute evaluation of a `set_factor_value` proposal. Returns
 * `{ ok: true }` when the handler's `normaliseFactorValue` would
 * accept these inputs without throwing; returns `{ ok: false, reason,
 * specific_issue }` otherwise.
 *
 * Check order matches the handler's existing guard sequence so the
 * `reason` enum aligns one-to-one with the failure paths telemetry can
 * see today, with two additions called out by the workstream plan:
 *
 *   - `delta_no_existing_value`: checked BEFORE `applyFactorValueOperator`
 *     so a missing/NaN `factorExistingRaw` never silently defaults to 0
 *     and silently corrupts a delta computation (AC.3).
 *   - `delta_no_cap_and_no_unit`: an uncapped, unitless delta has no
 *     bounded interpretation; rejecting earlier surfaces a clear
 *     clarification path rather than letting the handler write a
 *     boundless value.
 *
 * British English. No internal terms in user-facing copy.
 */
export function evaluateFactorValueProposal(
  input: EvaluateFactorValueProposalInput,
): FactorValueProposalEvaluation {
  // Public entry point: always enforces the full guard set, including the
  // stated-value `bare_ratio_on_unit_factor` gate. The bare-ratio suppression
  // is reachable ONLY through `evaluatePostOperatorFactorValue` (which calls
  // the non-exported impl) — there is no parameter on this signature to
  // disable a safety gate, so an arbitrary caller cannot bypass it.
  return evaluateFactorValueProposalImpl(input, false);
}

function evaluateFactorValueProposalImpl(
  input: EvaluateFactorValueProposalInput,
  suppressBareRatioGate: boolean,
): FactorValueProposalEvaluation {
  const {
    rawInput,
    operator: rawOperator,
    unit: rawUnit,
    proposalCap,
    factorCap,
    factorUnit: rawFactorUnit,
    factorExistingRaw,
    factorObservedValue,
    factorObservedRawValue,
    factorRecordedScaleIsUnusable,
    inputHasUnit,
  } = input;

  const operator: FactorValueOperator = rawOperator ?? 'set';

  // An empty / whitespace-only unit is NOT a unit — see `canonicaliseUnitForDisplay`.
  // Applied to the FACTOR's unit as well as the proposal's, so a factor already
  // carrying `''` reads as unitless here: that is what retires the malformed
  // `bare_ratio_on_unit_factor` copy ("not a value in .") and restores guard
  // 2c for such a factor, rather than only preventing new `''` writes.
  const unit = canonicaliseUnitForDisplay(rawUnit);
  const factorUnit = canonicaliseUnitForDisplay(rawFactorUnit);

  // 1. Structural: rawInput must be finite. Matches the
  //    "Value must be a finite number." guard at normalise-factor-value.ts:62.
  if (!Number.isFinite(rawInput)) {
    return {
      ok: false,
      reason: 'non_finite',
      specific_issue: 'Value must be a finite number.',
    };
  }

  // The cap that will be applied — proposal-supplied takes precedence
  // over factor-stored, matching `normaliseFactorValue`'s line 69.
  const cap = proposalCap ?? factorCap;
  const effectiveUnit = unit ?? factorUnit;

  // 2. cap_non_positive. Matches the guard at normalise-factor-value.ts:99.
  //    Only meaningful when a cap was actually supplied; an undefined cap
  //    means "uncapped factor" and is allowed.
  if (cap !== undefined && cap <= 0) {
    return {
      ok: false,
      reason: 'cap_non_positive',
      specific_issue: `Cap must be positive (received ${cap}).`,
    };
  }

  // 2b. unit_mismatch. When BOTH the proposal carries a unit AND the
  //     factor has a stored unit, they must match. Otherwise the
  //     handler would persist the proposal's unit over the existing
  //     one — e.g. a `%` factor accepting a `£` value would silently
  //     become a currency factor downstream. Brief: "If the unit is
  //     incompatible, ask a concise clarification."
  //
  //     ⚠ THE OLD JUSTIFICATION HERE WAS FALSE AND IS WITHDRAWN (C4 lane). It
  //     read: "Strict string equality is sufficient: CQE's
  //     `mapCqeQuantityToProposalValue` already canonicalises units ... so
  //     equivalent forms have already been normalised by the time the proposal
  //     reaches this predicate." That premise holds only for the CQE path. On
  //     every other path a case variant reached this gate verbatim, so 'Months'
  //     against a stored 'months' was REFUSED — and the refusal copy below
  //     interpolates both, rendering "This factor uses months; the value
  //     provided is in Months." Compared on the folded key since.
  //
  //     ⚠ THE COMPARISON FOLDS; THE COPY DOES NOT. `specific_issue` keeps the
  //     DISPLAY forms so the user sees the strings they actually typed.
  const unitKey = unitComparisonKey(unit);
  const factorUnitKey = unitComparisonKey(factorUnit);
  if (unitKey !== undefined && factorUnitKey !== undefined && unitKey !== factorUnitKey) {
    return {
      ok: false,
      reason: 'unit_mismatch',
      specific_issue: `This factor uses ${factorUnit}; the value provided is in ${unit}.`,
    };
  }

  // ── ROADMAP 2.159 — SILENT SCALE REDECLARATION ────────────────────────────
  //
  // 2c / 2d judge the PROPOSAL'S DECLARATION against the FACTOR'S, which is a
  // structural comparison of two recorded facts. They make no inference about
  // what a factor "probably is" from the magnitude of its value — an earlier
  // attempt at this workstream did exactly that and was refuted: a unitless,
  // uncapped small COUNT factor sitting at 0 or 1 is indistinguishable, BY
  // VALUE, from a normalised proportion, so magnitude cannot carry the
  // classification. (`prompts/defaults-v187.ts:301` sanctions "Small count
  // (0-10) | raw integer" as its own class.) Bounding a normalised factor
  // needs a DECLARED scale on the contract — rowed separately as 2.193; it is
  // deliberately NOT attempted here, and an uncapped unitless factor is left
  // exactly as unbounded as it is today.
  //
  // What IS sound without any declaration is this: the handler persists
  // `after.unit = parsed.unit ?? before.unit` and `after.cap = parsed.cap ??
  // before.cap` (`set-factor-value.ts`), so a proposal carrying a unit or a cap
  // permanently changes WHAT A FACTOR MEASURES — not merely its value — on a
  // factor that had neither. Two measured consequences at the bytes:
  //
  //   • the two-turn launder: turn 1 `{value: 0.9, unit: '%'}` on a unitless
  //     factor is accepted and PERSISTS the unit; the factor is now a
  //     different kind of thing, in an ordinary 200, with no consent step.
  //   • the one-step cap dodge: `{value: 1.5, cap: 2}` on an UNCAPPED factor
  //     writes `cap: 2` — and `capChanged` is computed as `before.cap !==
  //     undefined && …`, so an absent→present cap is NOT treated as a cap
  //     change and option interventions are NOT renormalised. Every option's
  //     absolute configuration on that factor silently shifts meaning.
  //
  // Both are refused here rather than silently applied. Refusing is strictly
  // more conservative than today, states only observed facts, and promises no
  // capability that does not exist.
  //
  // ⚠ INERT WHEN THE FACTOR HAS NO RECORDED STATE. Both gates require the
  // factor to already carry a value — first-time declaration ("this factor is
  // in £") must keep working, and `orchestrator/tools/encode-option-
  // interventions.ts`, which calls this predicate through `normaliseFactorValue`
  // without threading the factor's observed value, is unaffected by
  // construction rather than by assumption.
  const factorHasRecordedValue =
    factorObservedValue !== undefined || factorObservedRawValue !== undefined;

  // ⭐⭐ AND THE SECOND QUESTION, ASKED SEPARATELY (2026-09-11). A recorded
  // value is not a recorded SCALE. When the caller has derived — from the
  // ANALYSIS GATE itself, never from a rule restated here — that this factor's
  // recorded scale is one the analysis refuses to compute with, a proposal's
  // unit or cap is the FIRST declaration of a scale, not a silent
  // redeclaration of one. See the field's doc for the measured loop this
  // closes and for why the gate, not this module, owns the classification.
  //
  // ⚠ ONE CONJUNCT, TWO GATES, DELIBERATELY. 2c and 2d are the same question
  // about two carriers, and splitting the exemption between them is how a
  // user ends up able to state a unit and not a range (or the reverse) on the
  // one shape where neither is recorded. Closing only the cap limb would also
  // have been enough to clear the run, which is exactly the kind of narrowness
  // that leaves the next reader a half-open door with no note on it.
  const declarationIsFirstNotRe = factorHasRecordedValue && factorRecordedScaleIsUnusable === true;

  // 2c. unit_redeclares_scale. The proposal states a unit; the factor has
  //     none. `unit_mismatch` (2b) cannot see this case — it requires BOTH
  //     sides to carry a unit.
  if (factorHasRecordedValue && !declarationIsFirstNotRe && unit !== undefined && factorUnit === undefined) {
    return {
      ok: false,
      reason: 'unit_redeclares_scale',
      // Prediction-free, and free of computed numbers: the only interpolation
      // is the unit the user themselves stated. (An earlier draft of this
      // workstream interpolated a post-operator float and rendered
      // "the value given was 1.2999999999999998" — never echo computed
      // arithmetic back to a user.)
      specific_issue:
        `This factor is recorded without a unit, so applying a value in ${unit} ` +
        `would change what it measures.`,
    };
  }

  // 2d. cap_redeclares_scale. The proposal states a cap; the factor has none.
  //     Distinct from the CONSENTED extension of an EXISTING cap (1.16 item
  //     A2), which is unaffected: that path only ever fires on a factor whose
  //     cap is already set, and it renormalises option interventions.
  if (factorHasRecordedValue && !declarationIsFirstNotRe && proposalCap !== undefined && factorCap === undefined) {
    return {
      ok: false,
      reason: 'cap_redeclares_scale',
      specific_issue:
        `This factor is recorded without an upper limit, so applying this change ` +
        `would set one and rescale the factor.`,
    };
  }

  // 3. Delta guards — run BEFORE `applyFactorValueOperator`.
  if (operator !== 'set') {
    // 3a. delta_no_existing_value. The factor must carry a finite
    //     raw_value for the operator's LHS. Anything else (undefined,
    //     NaN, ±Infinity) would silently default to 0 in the old
    //     handler path — regression of staging 2fcd2221 (AC.3).
    if (
      factorExistingRaw === undefined ||
      !Number.isFinite(factorExistingRaw)
    ) {
      return {
        ok: false,
        reason: 'delta_no_existing_value',
        specific_issue:
          "This factor has no recorded current value to adjust from.",
      };
    }

    // 3b. delta_no_cap_and_no_unit. An uncapped, unitless delta has no
    //     bounded interpretation ("increase by 10" — 10 of what?). Surface
    //     as a clarification rather than writing a boundless value. This
    //     INCLUDES `multiply`: an UNCAPPED multiply has no upper or lower
    //     bound (no cap-range guard runs below to contain it), so a bare
    //     `× -0.5` or `× 1e9` would otherwise write a nonsensical or
    //     unbounded value (e.g. `12 people × -0.5 = -6 people`). Capped
    //     multiply is unaffected (cap is defined here) and is exempted from
    //     the bare-ratio gate at 3c instead, where the cap-range guard
    //     contains it.
    if (cap === undefined && !inputHasUnit) {
      return {
        ok: false,
        reason: 'delta_no_cap_and_no_unit',
        specific_issue: "This change can't be applied without a unit.",
      };
    }
  }

  // 3c. bare_ratio_on_unit_factor. A bare (unit-less) number below 1 in
  //     magnitude, applied to a factor that HAS a unit, reads as a
  //     normalised proportion (0.3), not a value in that unit. Accepting
  //     it would persist raw_value=0.3 and narrate the misleading
  //     "£0.3" / "0.3 people" — a false user-visible claim. Gate on the
  //     user's stated number (rawInput), not effectiveRaw, so
  //     "increase budget by 0.3" is caught too. `rawInput === 0` is
  //     unambiguous ("zero it") and is allowed through; an explicit unit
  //     (`inputHasUnit`) means the user asserted the scale, so it is left
  //     to the cap-range guards below (e.g. an explicit "£0.30" is a
  //     fully-specified amount, not the bare-number ambiguity).
  //
  //     `multiply` is EXCLUDED: its right-hand side is a dimensionless
  //     scaling factor, never a value in the factor's unit. On a CAPPED
  //     factor "multiply by 0.3" unambiguously means ×0.3 ("scale to 30%",
  //     e.g. £40,000 → £12,000) — there is no proportion-vs-unit ambiguity,
  //     and the "give me a £ amount" clarification would be wrong guidance
  //     for a scaling operation. Sub-1 multipliers are the normal way to
  //     scale down, so on a capped factor they pass to the cap-range guard
  //     below (which contains overshoot/negative products). An UNCAPPED
  //     multiply is rejected earlier at gate 3b (no cap to bound it).
  //
  //     NOTE on multiply + explicit unit: a multiply RHS is treated as a
  //     pure scalar — its unit is NOT dimensionally validated. A unit that
  //     MATCHES the factor (e.g. `£40,000 × £0.3`) is harmlessly ignored
  //     (the math is ×0.3 → £12,000); a unit that DIFFERS is still caught
  //     by `unit_mismatch` (2b) above. Multiplying by a money/percent
  //     amount is incoherent input, but the numeric result is honest.
  //
  //     This gate judges the USER'S STATED `rawInput`, so it must only run
  //     where `rawInput` is that stated number — i.e. the validator
  //     precheck and the handler's `preEvaluation`. `normaliseFactorValue`
  //     re-runs this predicate against the POST-operator computed value
  //     (with `operator: 'set'`); it sets `suppressBareRatioGate` so a
  //     legitimate honest product that lands in (0,1) — e.g. `4% × 0.1 =
  //     0.4%`, or `decrease £5.30 by £5 = £0.30` — is not falsely rejected
  //     at execute (the stated-value check already happened upstream).
  //
  //     Tier A #1 (edit-reliability, 2026-07-09) — FIX 3 (1.45-F6):
  //     EXEMPT a factor whose cap is exactly 1 (`isProportionScaledFactor`).
  //     When a factor's own native range IS [0,1] (e.g. a churn-rate-style
  //     factor stored as a 0-1 proportion, whatever unit string happens to
  //     be attached), a bare "0.8" is UNAMBIGUOUSLY a value in that scale —
  //     there is no proportion-vs-unit interpretation gap to warn about,
  //     unlike a £/people/count factor where a sub-1 number is almost
  //     certainly a mis-stated ratio. This is deliberately narrow: it does
  //     NOT touch the doctrine-open case of a %-unit factor on a 0-100
  //     scale (`factorCap: 100`), where "0.8" could mean 0.8% or a typo for
  //     80% (Paul's open pp-vs-relative decision, D-D) — that case keeps
  //     the existing clarify unchanged (cap !== 1 there, so this exemption
  //     does not apply). The cap-range guard below still runs normally, so
  //     an out-of-[0,1] value on a cap-1 factor is still rejected.
  /**
   * ⭐ THE UNIT DECLARES THE SCALE EXACTLY AS A CAP DOES.
   *
   * Witnessed on deployed staging (build c12a54d, 22 Sep 2026): the live factor
   * "Product-Market Fit Investment" carries `unit: 'scale'`, `value: 0.3`, NO
   * `raw_value` and NO cap. Every way of setting it to 0.8 was refused —
   * including a bare `0.8` — as "a proportion rather than a value in scale", on
   * a factor whose OWN PERSISTED VALUE IS 0.3. It could not be set to any sub-1
   * value, and sub-1 is the only range it has.
   *
   * The escape hatch already existed and worked; it was simply keyed on
   * `factorCap === 1`, which these factors do not carry. Measured directly
   * against this gate: `unit 'scale', no cap` REFUSED, `unit 'scale',
   * factorCap 1` ACCEPTED.
   *
   * ⚠ CLOSED VOCABULARY, FROM LIVE DATA — NOT A PREDICATE. An open rule ("does
   *   it look proportional?") would silently reclassify amount units, which is
   *   the direction that loses user data. These are the proportion-class units
   *   actually present in the estate (30-day census): `scale` 1,688,
   *   `unit_interval` 15, `ratio` 6, `proportion` 3.
   *
   * ⚠ IT CANNOT WEAKEN THE AMBIGUOUS CASE. An AMOUNT unit is untouched: a bare
   *   `0.8` on a `months`/`£` factor is still refused and still asks, because
   *   0.8 months genuinely could mean 0.8 or 80%. On a proportion unit there is
   *   no second reading to be ambiguous between — pinned by controls.
   */

  /**
   * ⛔ THE UNIT TOKEN IS NOT ENOUGH ON ITS OWN, AND THE ESTATE SAYS SO.
   *
   * A first version of this exemption was `cap === 1 || isProportionUnit`.
   * Independent review REFUTED it, by execution, on a real staging capture:
   * `fac_crm_capability` carries `unit: 'scale'` with **`cap: 100`** and
   * `raw_value: 35`. Under the unit-only rule a user typing `0.8` (meaning 80)
   * was ACCEPTED and persisted as `newRaw = 0.8` — the model value going
   * 0.35 -> 0.008, a silent ~100x corruption, in exactly the case this gate was
   * built to ask about.
   *
   * The premise was wrong at the root: `unit` is not a range declaration.
   * `cee/draft/records/instruction.ts:288-291` — "Never put a scale or
   * convention word there — not 'scale', not 'unit_interval', not 'ratio' ...
   * Those belong in `value_scale`". So these tokens are documented MALFORMED
   * occupants of `unit`, and a malformed field cannot carry a safety signal.
   *
   * ⭐ SO THE TEST IS "NOTHING CONTRADICTS IT", NOT "THE UNIT SAYS SO".
   *   A proportion-unit factor is treated as proportion-scaled only when it
   *   carries NO cap other than 1 and NO recoverable frame. Both a cap and a
   *   `value`/`raw_value` pair are POSITIVE EVIDENCE of an amount scale, and
   *   either one outranks the token. That keeps `frameRecoverable` (:944)
   *   load-bearing — it was added by a previous round-2 review precisely
   *   because "a FRAME-RECOVERABLE factor declares an amount scale exactly as a
   *   unit string does", after two writers were measured guessing answers 10^5
   *   apart on a framed factor.
   *
   * What this still fixes is the witnessed live shape: `unit: 'scale'`,
   * `value: 0.3`, NO cap and NO raw_value — nothing contradicts the token, and
   * the factor could previously not be set to any sub-1 value at all.
   */
  const proportionScaled = isProportionScaledFactor({ unit: factorUnit, cap, value: factorObservedValue, raw_value: factorObservedRawValue });
  // R2-1 (PR #926 round-2 re-review): the gate above keyed ONLY on a unit
  // string, and records-drafted factors can never carry one (the records
  // grammar has no unit field on claims) — so the whole records population
  // was structurally invisible to this ask, and the two baseline writers
  // were measured GUESSING opposite answers for a bare 0.7 on a framed
  // factor (÷frame vs ×frame — 10^5 apart). A FRAME-RECOVERABLE factor
  // (capless, `raw_value/value` pair proving a frame — the records pass-3d
  // shape) declares an amount scale exactly as a unit string does, so the
  // same bare-sub-1 input is the same ambiguity and gets the same ask.
  const frameRecoverable =
    cap === undefined &&
    recoverScaleFrame({
      value: factorObservedValue,
      raw_value: factorObservedRawValue,
    }) !== undefined;
  if (
    !suppressBareRatioGate &&
    operator !== 'multiply' &&
    !proportionScaled &&
    !inputHasUnit &&
    (effectiveUnit !== undefined || frameRecoverable) &&
    rawInput !== 0 &&
    Math.abs(rawInput) < 1
  ) {
    return {
      ok: false,
      reason: 'bare_ratio_on_unit_factor',
      // The unit arm's copy is byte-identical to what it always was; only the
      // framed (unitless) arm carries new copy, naming the recorded amount so
      // the user can answer in one turn.
      specific_issue:
        effectiveUnit !== undefined
          ? `${rawInput} looks like a proportion, not a value in ${effectiveUnit}. ` +
            `Tell me the amount in ${effectiveUnit}.`
          : `${rawInput} looks like a proportion, but this factor is recorded as an amount` +
            `${typeof factorObservedRawValue === 'number' ? ` (currently ${factorObservedRawValue})` : ''}. ` +
            `Tell me the amount you want.`,
    };
  }

  // 4. Compute `effectiveRaw`. For `'set'` operator this is just
  //    `rawInput`; for delta operators we know `factorExistingRaw` is
  //    finite (gate 3a) so the computation is safe.
  const effectiveRaw =
    operator === 'set'
      ? rawInput
      : applyFactorValueOperator(
          factorExistingRaw as number,
          operator,
          rawInput,
        );

  // 5. Defensive: a finite-input operator can still produce Infinity
  //    under multiplication on the edges of the float range. Mirrors
  //    the "Normalised value is not finite." guard at
  //    normalise-factor-value.ts:141.
  if (!Number.isFinite(effectiveRaw)) {
    return {
      ok: false,
      reason: 'non_finite',
      specific_issue: 'Value must be a finite number.',
    };
  }

  // ── 6. RANGE GUARDS — TWO QUESTIONS, PREVIOUSLY ONE CONJUNCT ──────────────
  //
  // This block used to read `effectiveRaw < 0 || effectiveRaw > cap` and give
  // both arms one reason and one sentence. Those are two different harms and
  // they cannot share a threshold (CLAUDE.md trap 22b):
  //
  //   · A BOUND TOO TIGHT REJECTS TRUTH. Measured, founder session 3 Sep 2026
  //     (`olumi-programme-docs` `artefacts/manual-test-2026-09-03/`, scenario
  //     `7826c742`): a brief saying "£80-120k for the first hire" produced
  //     `raw_value: 80`, which set `cap: 100`, and the user's true £100,000 was
  //     then REFUSED — "Value £100,000 exceeds the factor's cap of £100." The
  //     same `observed_state` carried `uncertainty_drivers: ["Extracted from
  //     brief — confirm value"]`, so the product asked to have the value
  //     confirmed and enforced a bound derived from it in the same breath.
  //   · A BOUND ABSENT ADMITS NONSENSE. A bare number carries no scale of its
  //     own, and a capped factor is stored `value = raw / cap` on a scale that
  //     starts at zero.
  //
  // The floor and the ceiling are therefore separated below, and only the
  // ceiling consults {@link capBoundOrigin}. The FLOOR does not rest on the
  // ceiling's number at all — `cap > 0` is already guaranteed by gate 2 — so it
  // is untouched by where the ceiling came from, in either direction.
  if (cap !== undefined) {
    // 6a. FLOOR. A capped factor has no representation for a negative: the
    //     writer stores `raw / cap`, and every consumer of that pair
    //     (`resolveExistingRawValue`, `buildFactorScaleMap`) reads a
    //     normalised value as living in [0,1]. Refused whatever the ceiling is
    //     and whoever set it.
    if (effectiveRaw < 0) {
      if (!inputHasUnit) {
        // Unchanged: this sentence is TRUE for a bare negative (it IS outside
        // [0, cap]), and its composer branch is owned elsewhere. Only false
        // copy is rewritten here.
        return {
          ok: false,
          reason: 'bare_number_outside_cap',
          specific_issue: `Value ${effectiveRaw} is outside the factor's expected range [0, ${cap}] and no unit was given.`,
        };
      }
      // ⚠ THE SENTENCE THIS REPLACES WAS FALSE. A unit-bearing negative took
      // the `value_exceeds_cap` arm and rendered, measured at staging
      // `f4c8f501`, "Value £-4,920 exceeds the factor's cap of £100." -4,920
      // does not exceed 100. One conjunct answered two questions and the copy
      // inherited the wrong one.
      //
      // The reason code is DELIBERATELY unchanged. Minting a new member would
      // reach `compose/validation-failure-responses.ts` and the precheck
      // telemetry enum, both owned by other in-flight lanes; an unrecognised
      // reason falls through to the composer's generic copy, which is worse
      // than the imperfect branch it has now. What is fixed here is the
      // falsehood, which needs no new member.
      //
      // No computed number is echoed: for a delta the offending figure is
      // arithmetic the user never typed (an earlier lane in this file shipped
      // "the value given was 1.2999999999999998" that way).
      return {
        ok: false,
        reason: 'value_exceeds_cap',
        specific_issue:
          'That would take this factor below zero, and it is recorded on a ' +
          'scale that starts at zero.',
      };
    }

    // 6b. CEILING.
    if (effectiveRaw > cap) {
      if (!inputHasUnit) {
        // A bare number asserts no scale, so the ceiling is the ONLY scale
        // evidence in play. Widening on it would let a mistyped digit
        // redefine what the factor measures — the "a bound absent admits
        // nonsense" direction. Unchanged, and pinned as the opposite-direction
        // twin of the founder's case.
        return {
          ok: false,
          reason: 'bare_number_outside_cap',
          specific_issue: `Value ${effectiveRaw} is outside the factor's expected range [0, ${cap}] and no unit was given.`,
        };
      }
      // Format via the shared helper so currency prefixes render correctly
      // (`£500,000`, not `500000£`).
      const formattedInput = formatValueWithUnit(effectiveRaw, effectiveUnit);
      const formattedCap = formatValueWithUnit(cap, effectiveUnit);
      const boundOrigin = capBoundOrigin({
        ...(proposalCap !== undefined ? { proposalCap } : {}),
        ...(factorCap !== undefined ? { factorCap } : {}),
      });
      if (boundOrigin === 'stated_on_this_proposal') {
        // The bound came with the value. Byte-identical to the historic
        // sentence, deliberately: this arm is a coherent judgement of a
        // proposal against its own stated scale, and a live-capture corpus
        // records this wording.
        return {
          ok: false,
          reason: 'value_exceeds_cap',
          specific_issue: `Value ${formattedInput} exceeds the factor's cap of ${formattedCap}.`,
        };
      }
      // The bound is inherited and unconfirmed, and the user has stated their
      // own scale. The sentence stops asserting the bound as a property of the
      // factor and names it as a reading nothing has confirmed — because on
      // this evidence the bound is the more likely thing to be wrong.
      //
      // ⚠ IT STILL REFUSES, AND THAT IS A BOUNDARY, NOT A JUDGEMENT. Applying
      // the widened bound means writing `observed_state.cap`, which happens at
      // `set-factor-value.ts` (`after.cap = parsed.cap ?? before.cap`) — a file
      // owned by an in-review PR at the time of writing. `unconfirmed_bound`
      // carries the remedy so that change is a wiring job rather than a
      // re-derivation. Until then the refusal is at least TRUE about whose
      // number is in doubt.
      return {
        ok: false,
        reason: 'value_exceeds_cap',
        specific_issue:
          // ⚠ BUDGET: `specific_issue` is rendered through `sanitiseForUser`
          // (compose/helpers.ts), which truncates at MAX_USER_STRING = 100 with a
          // trailing "...". The previous wording had a 146-char skeleton BEFORE
          // interpolation, so it was cut mid-word for every value and every unit —
          // the remedy clause was never reachable by a user. This skeleton is 67;
          // worst realistic case (£1,000,000,000 twice) composes to 95. Pinned on
          // the COMPOSED assistant_text, not on this string, so a copy change that
          // re-crosses the budget REDs instead of truncating silently.
          `${formattedInput} is above an unconfirmed limit of ${formattedCap}. ` +
          `The limit may be what is wrong.`,
        unconfirmed_bound: { cap, rescale_cap_to: suggestExtendedCap(effectiveRaw) },
      };
    }
  }

  return { ok: true };
}

/**
 * 1.16 item A2 — suggested extended cap for the user-consented "extend the
 * scale" chip on `value_exceeds_cap` rejections. Policy: value * 1.25
 * headroom, rounded UP to a clean two-significant-figure number (250,000 →
 * 312,500 → 320,000), and never below the value itself. Pure and shared so
 * the validator (which threads it into PARAMETER_INVALID details), the
 * composer (which renders the chip), and tests all agree on one number.
 */
export function suggestExtendedCap(value: number): number {
  if (!Number.isFinite(value) || value <= 0) return value;
  const raw = value * 1.25;
  const magnitude = Math.pow(10, Math.floor(Math.log10(raw)) - 1);
  const rounded = Math.ceil(raw / magnitude) * magnitude;
  return Math.max(rounded, value);
}

/**
 * Dedicated post-operator validation API. The handler has already applied
 * the operator into `computedRaw` and enforced the STATED-value guards
 * (bare_ratio, unit_mismatch, delta guards) at `preEvaluation` against the
 * original RHS. This validates the resulting COMPUTED value against only the
 * value-level guards (finiteness, positive cap, cap range) — it never
 * re-runs the bare-ratio gate, because that gate judges the user's stated
 * input, not a computed product (re-running it would falsely reject honest
 * results in (0,1), e.g. `4% × 0.1 = 0.4%`).
 *
 * This is the ONLY place the bare-ratio gate is suppressed: it calls the
 * non-exported impl directly. The public `evaluateFactorValueProposal` exposes
 * no suppression parameter, so no other caller can disable the gate.
 */
export function evaluatePostOperatorFactorValue(input: {
  readonly computedRaw: number;
  readonly unit?: string;
  readonly proposalCap?: number;
  readonly factorCap?: number;
  readonly factorUnit?: string;
  /** ROADMAP 2.159 — the factor's stored value / raw_value, for the
   *  redeclaration gates (2c / 2d). Magnitude is never inspected. */
  readonly factorObservedValue?: number;
  readonly factorObservedRawValue?: number;
  /** 2026-09-11 — see the field's doc on `EvaluateFactorValueProposalInput`. */
  readonly factorRecordedScaleIsUnusable?: boolean;
  readonly inputHasUnit: boolean;
}): FactorValueProposalEvaluation {
  return evaluateFactorValueProposalImpl(
    {
      rawInput: input.computedRaw,
      // The operator was already applied into `computedRaw`; treat it as a
      // final `set` value so the predicate does not re-apply operator math.
      operator: 'set',
      ...(input.unit !== undefined ? { unit: input.unit } : {}),
      ...(input.proposalCap !== undefined ? { proposalCap: input.proposalCap } : {}),
      ...(input.factorCap !== undefined ? { factorCap: input.factorCap } : {}),
      ...(input.factorUnit !== undefined ? { factorUnit: input.factorUnit } : {}),
      // ROADMAP 2.159 — forwarded so the execute-time re-check applies the same
      // redeclaration gates the validator and the handler's `preEvaluation`
      // do. Without this the backstop layer would enforce a weaker rule set
      // than the gates in front of it.
      ...(input.factorObservedValue !== undefined
        ? { factorObservedValue: input.factorObservedValue }
        : {}),
      ...(input.factorObservedRawValue !== undefined
        ? { factorObservedRawValue: input.factorObservedRawValue }
        : {}),
      // 2026-09-11 — forwarded for the same AC.1 parity reason as the two
      // fields above: the execute-time backstop must enforce the SAME rule set
      // as `preEvaluation`, not a stricter one. Omitting it here would make
      // the handler refuse at execute exactly what it had just admitted at
      // pre-check — a disagreement between two runs of one predicate, which is
      // the shape this whole change exists to remove.
      ...(input.factorRecordedScaleIsUnusable !== undefined
        ? { factorRecordedScaleIsUnusable: input.factorRecordedScaleIsUnusable }
        : {}),
      inputHasUnit: input.inputHasUnit,
    },
    true,
  );
}
