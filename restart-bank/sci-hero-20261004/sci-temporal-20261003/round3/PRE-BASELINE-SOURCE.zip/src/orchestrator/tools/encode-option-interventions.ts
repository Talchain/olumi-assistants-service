/**
 * V5 edit_graph P0 (add-option encoding) — encode option interventions to the
 * canonical top-level OptionV3 contract, or report which options cannot be
 * safely encoded so the edit can DEFER (reject) rather than persist an
 * analysis-incompatible option.
 *
 * Why this exists: the edit_graph LLM emits option interventions in shapes that
 * are NOT analysis-ready after `GraphV3.safeParse` strips `node.data`:
 *   SHAPE 1: `data.interventions: { <fac>: {unit, raw_value} }` with NO numeric
 *            `value` (the prompt asks for `value`; the model omits it).
 *   SHAPE 2: option-level `unit`/`raw_value` smeared onto the option node, with
 *            NO interventions bundle at all.
 * (Both also occur at TOP-LEVEL `interventions` — a raw-only entry there is just
 * as unconfigured, since analysis reads a finite numeric `value`.)
 * Each reaches run_analysis with zero numeric interventions → options_not_configured.
 *
 * This function (run in the edit handler BEFORE commit) recovers interventions
 * from every location and DERIVES the model-unit `value` using the SAME
 * canonical encoder `set_factor_value` uses — `normaliseFactorValue`
 * (`value = raw_value / cap`). It does NOT invent value-scale semantics:
 *   - `value` already present (numeric) → used as-is (PR #276 behaviour preserved).
 *   - `value` missing but `raw_value` + a cap → encoded, BUT only when the target
 *     factor RESOLVES to a real factor node and the canonical predicate (run with
 *     the factor's `unit`) accepts the proposal (so a unit mismatch / out-of-range
 *     / ambiguous bare number is rejected → deferred).
 *   - otherwise NOT safely derivable → the option id is returned as UNRESOLVED and
 *     the caller must reject/defer the edit (no graph mutation).
 *
 * Independent of the Track S intercept repair and the PR #276 commit normaliser
 * (which still runs at commit as a safety net).
 */
import { normaliseFactorValue } from '../../orchestrator-v5/tools/handlers/d1-shared/normalise-factor-value.js';
import { isDeepStrictEqual } from 'node:util';
import { OBSERVED_ROOT_SPELLINGS } from '../canonicalise-value-ops.js';
import { log } from '../../utils/telemetry.js';
import { buildFactorScaleMap, resolveRawInterventionValue, type FactorScaleInfo } from '../../orchestrator-v5/tools/plot-intervention-scale.js';
import { unitComparisonKey } from '../../orchestrator-v5/tools/handlers/d1-shared/evaluate-factor-value-proposal.js';

type Dict = Record<string, unknown>;
/**
 * ⭐ THE RECOGNISER, DERIVED FROM THE ATOMICITY POSTCONDITION RATHER THAN GUESSED.
 *
 * This module previously used `/^data\/interventions\/(.+)$/` — ONE prefix
 * family. The postcondition that judges whether an edit landed
 * (`isInterventionSubtreeKey`, canonicalise-value-ops.ts) accepts THREE:
 * `interventions/*`, `data/interventions/*` and `observed_state/interventions/*`,
 * on either separator. Every spelling in that gap was gathered by nothing, left
 * on the node verbatim, stripped by the GraphV3 parse, and then correctly
 * refused by the atomicity guard as OPERATION_DID_NOT_LAND — behind user-facing
 * copy saying "try again in a moment". The failure is DETERMINISTIC, so that
 * retry cannot succeed: the same phrasing yields the same op spelling every
 * time. Measured live on staging, 14 Sep 2026: 6 of 12 op spellings refused.
 *
 * ⚠ FOUR VERBATIM COPIES OF THE OLD REGEX REMAIN, each with the same narrowness:
 * `cee/draft/records/option-magnitude-census.ts:72`,
 * `orchestrator-v5/context/baseline-override-reach.ts:50`,
 * `orchestrator-v5/normalise-option-interventions.ts:74` (a near-twin writer,
 * gather at :175 and sweep at :420) and
 * `orchestrator-v5/context/intervention-controlled-drivers.ts:41`.
 * They are NOT changed here: only this module's narrowness is proven to cause a
 * live refusal, and widening four unproven readers mid-incident trades a
 * measured fix for an unmeasured one. The predicates below are exported so a
 * follow-up adopts them rather than inventing a sixth spelling.
 */
function interventionKeySegments(key: string): readonly string[] {
  return key.split(/[/.]/).filter((s) => s.length > 0);
}

/**
 * Index of the `interventions` segment when `key` is a FLAT intervention-subtree
 * key, else `-1`.
 *
 * ⚠ THE `length < 2` GUARD IS LOAD-BEARING AND IS NOT A TIDY-UP. Bare
 * `interventions` IS the canonical bundle key, and the postcondition's
 * `isInterventionSubtreeKey('interventions')` returns TRUE for it. The promotion
 * sweep below runs AFTER `node.interventions = bundle`, so a predicate that
 * accepted the bare key would delete the bundle this module has just written.
 */
function interventionRootIndex(key: string): number {
  const segments = interventionKeySegments(key);
  if (segments.length < 2) return -1;
  if (segments[0] === 'interventions') return 0;
  if (OBSERVED_ROOT_SPELLINGS.has(segments[0]!) && segments[1] === 'interventions') return 1;
  return -1;
}

/**
 * A flat intervention-subtree key at ANY depth — the promotion sweep's and the
 * intent detector's predicate. The sweep must clear every verbatim spelling once
 * the canonical bundle is written, including the deeper ones
 * {@link parseFlatInterventionKey} declines to gather.
 */
export function isFlatInterventionKey(key: string): boolean {
  return interventionRootIndex(key) >= 0;
}

/**
 * The factor id a flat intervention key targets, or `undefined` when the key is
 * not one this encoder can safely encode.
 *
 * ⚠ EXACTLY ONE TRAILING SEGMENT — the second, worse defect fixed here. The old
 * capture group was `(.+)`, so `data/interventions/<fac>/value` captured the
 * factor id as `"<fac>/value"`: an intervention keyed on a factor that does not
 * exist. The canonical bundle then DIFFERED from the pre-edit one,
 * `batchFullyLanded` returned TRUE, and the turn reported the edit APPLIED while
 * the real factor's value never moved. A silent false success about saved data
 * is worse than an honest refusal.
 *
 * Deeper paths are FIELD-level writes for which this encoder has no safe
 * encoding (the served edit prompt teaches whole-object patches, not field
 * updates). Returning `undefined` leaves them to the atomicity guard, which
 * refuses them honestly. They are a KNOWN-DROPPED set, pinned by name in the
 * spec so the suite REDs if that set grows OR shrinks.
 */
export function parseFlatInterventionKey(key: string): string | undefined {
  const i = interventionRootIndex(key);
  if (i < 0) return undefined;
  const rest = interventionKeySegments(key).slice(i + 1);
  return rest.length === 1 ? rest[0] : undefined;
}

/**
 * The `InterventionV3.source` members this encoder will PRESERVE from a raw
 * record instead of defaulting.
 *
 * ⭐⭐ WHY THIS EXISTS, AND WHY IT IS SAFE IN ONLY ONE DIRECTION.
 *
 * `buildInterventionV3` stamped `source: 'user_specified'` unconditionally, so
 * a value the PRODUCT chose became permanently indistinguishable from one the
 * USER stated — measured 2026-09-04 by writing `cee_hypothesis` through the
 * full apply chain and reading `user_specified` back out. That matters the
 * moment the product proposes estimates for approval: "whose number is this?"
 * is the question the whole review rests on, and the graph could not answer it.
 *
 * ⚠⚠ THE ALLOWLIST IS EXACTLY ONE MEMBER, AND THE REASON IS A FACT ABOUT THIS
 * ESTATE RATHER THAN A STYLE CHOICE. `cee_hypothesis` is the ONLY
 * `InterventionV3.source` the estate's provenance authority classes as the
 * model speaking:
 *
 *   `obligation-provenance.ts` `INTERVENTION_SOURCE` —
 *     `cee_hypothesis: 'ai_drafted'`
 *     `user_specified: 'user_stated'`
 *     `brief_extraction: 'user_stated'`   ← the SAME class as `user_specified`
 *
 * and `obligationFor('user_stated') === 'required'`. So `brief_extraction` is a
 * USER provenance here, not a second non-user one — that file's own header
 * names it among the producer-written stamps whose gaps "must STILL block".
 *
 * ⚠ A `brief_extraction` record therefore defaults to `user_specified` exactly
 * as it did before this change — same `user_stated` class, same `required`
 * obligation, no behaviour change for any existing writer. The invariant this
 * set must keep is the narrow one: NOTHING in it may map to `user_stated`, so
 * the carry can only ever NARROW a value's claim, never widen it to
 * user-authored. That is pinned in
 * `__tests__/encode-option-interventions.provenance.test.ts` by
 * "every preserved source is a NON-user provenance, checked against the
 * authority", which reads the mapping out of the authority at test time rather
 * than restating it here.
 */
export const PRESERVED_INTERVENTION_SOURCES: ReadonlySet<string> = new Set([
  'cee_hypothesis',
]);

const INTERVENTION_CONFIDENCES: ReadonlySet<string> = new Set(['high', 'medium', 'low']);

// ⚠ A SECOND COPY OF `PRESERVED_INTERVENTION_SOURCES` AND
// `INTERVENTION_CONFIDENCES` WAS REMOVED HERE DURING A REBASE (18 Sep 2026).
//
// This branch was 231 commits behind, and `staging` had independently shipped
// both constants with byte-identical values (`new Set(['cee_hypothesis'])` and
// `new Set(['high','medium','low'])`) plus an equivalent docblock, 40 lines
// above. Git merged the two additions without a conflict because they landed at
// different offsets, so the only signal was `TS2451: Cannot redeclare
// block-scoped variable` — 4 errors, against a control showing `staging` alone
// typechecks clean.
//
// The surviving copy is STAGING'S. Nothing was reverted: the values are
// identical, and both docblocks make the same argument — that the carry may
// only ever NARROW a value's claim, never widen it to user-authored.

/** Raw intervention recovered from any location, pre-encoding. */
interface RawIntervention {
  /** Model-unit value when already present (0..1). */
  readonly value?: number;
  /** User-unit value before normalisation. */
  readonly raw_value?: number;
  readonly unit?: string;
  /** Cap carried on the intervention object itself (proposal cap). */
  readonly cap?: number;
  /** A NON-user provenance the writer stated explicitly; absent ⇒ default. */
  readonly source?: string;
  readonly value_confidence?: string;
  readonly reasoning?: string;
  /** TEMPORAL: a stated range the writer supplied with THIS figure (validated at persist, `intervention-range.ts`). */
  readonly range?: Dict;
}

export interface EncodeOptionInterventionsResult<T> {
  /** The encoded graph (a clone) when any option was rewritten; else the original reference. */
  readonly graph: T;
  /**
   * Option ids that carry intervention intent that cannot be made analysis-ready.
   * Restricted to `touchedOptionIds` when provided. Non-empty ⇒ the caller MUST
   * defer (reject) the edit without committing the graph.
   */
  readonly unresolvedOptionIds: string[];
}

function isPlainObject(v: unknown): v is Dict {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function finiteNum(v: unknown): number | undefined {
  return typeof v === 'number' && Number.isFinite(v) ? v : undefined;
}

/** Interpret a recovered source (bare scalar = model value; object = {value,raw_value,unit,cap}). */
function toRawIntervention(src: unknown): RawIntervention {
  const bare = finiteNum(src);
  if (bare !== undefined) return { value: bare };
  if (!isPlainObject(src)) return {};
  const out: {
    value?: number;
    raw_value?: number;
    unit?: string;
    cap?: number;
    source?: string;
    value_confidence?: string;
    reasoning?: string;
    range?: Dict;
  } = {};
  const v = finiteNum(src.value);
  if (v !== undefined) out.value = v;
  const rv = finiteNum(src.raw_value);
  if (rv !== undefined) out.raw_value = rv;
  if (typeof src.unit === 'string') out.unit = src.unit;
  const cap = finiteNum(src.cap);
  if (cap !== undefined) out.cap = cap;
  if (isPlainObject(src.range)) out.range = { ...src.range };
  // Carried ONLY when explicitly stated and recognised; anything else falls
  // through to the unchanged default in `buildInterventionV3`.
  if (typeof src.source === 'string' && PRESERVED_INTERVENTION_SOURCES.has(src.source)) {
    out.source = src.source;
    if (typeof src.value_confidence === 'string' && INTERVENTION_CONFIDENCES.has(src.value_confidence)) {
      out.value_confidence = src.value_confidence;
    }
    if (typeof src.reasoning === 'string' && src.reasoning.trim().length > 0) {
      out.reasoning = src.reasoning;
    }
  }
  return out;
}

/**
 * Gather an option's interventions that are NOT already canonical-numeric, from
 * (precedence high→low): data.interventions, slash-keyed, node-level (SHAPE 2,
 * single factor edge, only when no top-level bundle), and finally any top-level
 * entry lacking a finite numeric `value` (raw-only/malformed). Numeric top-level
 * entries are NOT gathered — they are preserved verbatim by the caller.
 */
function gatherRawInterventions(node: Dict, factorTargets: readonly string[]): Map<string, RawIntervention> {
  const out = new Map<string, RawIntervention>();

  // Source 1: data.interventions (SHAPE 1).
  const data = node.data;
  if (isPlainObject(data) && isPlainObject(data.interventions)) {
    for (const [fac, src] of Object.entries(data.interventions as Dict)) {
      out.set(fac, toRawIntervention(src));
    }
  }

  // Source 2: FLAT intervention-subtree entries, in EVERY spelling the
  // atomicity postcondition accepts — not only `data/interventions/<fac>`.
  for (const [k, v] of Object.entries(node)) {
    const fac = parseFlatInterventionKey(k);
    if (fac === undefined) continue;
    if (out.has(fac)) continue;
    out.set(fac, toRawIntervention(v));
  }

  // Source 3 (SHAPE 2): node-level unit/raw_value/value, no bundle, single factor edge.
  const nodeLevel = toRawIntervention({ value: node.value, raw_value: node.raw_value, unit: node.unit, cap: node.cap });
  const hasNodeLevel = nodeLevel.value !== undefined || nodeLevel.raw_value !== undefined;
  if (out.size === 0 && !isPlainObject(node.interventions) && hasNodeLevel && factorTargets.length === 1) {
    out.set(factorTargets[0]!, nodeLevel);
  }

  // Source 4 (lowest): top-level entries WITHOUT a finite numeric value (raw-only/malformed).
  const top = node.interventions;
  if (isPlainObject(top)) {
    for (const [fac, src] of Object.entries(top)) {
      if (out.has(fac)) continue;
      const rec = toRawIntervention(src);
      if (rec.value !== undefined) continue; // numeric → preserved verbatim, not gathered
      out.set(fac, rec);
    }
  }

  return out;
}

/**
 * Derive the model-unit `value`, or `undefined` when it cannot be SAFELY derived
 * (the defer signal). Safe derivation requires: a resolvable target factor, a cap
 * (from the intervention or the factor's observed_state), and acceptance by the
 * canonical predicate run WITH the factor's unit (rejecting unit mismatch /
 * out-of-range / ambiguous bare numbers). Never invents a scale.
 */
function deriveValue(rec: RawIntervention, factor: Dict | undefined): number | undefined {
  if (rec.value !== undefined) return rec.value;
  if (rec.raw_value === undefined) return undefined;
  if (factor === undefined) return undefined; // target must resolve to a real factor

  const obs = isPlainObject(factor.observed_state) ? factor.observed_state : undefined;
  const factorCap = obs ? finiteNum(obs.cap) : undefined;
  const factorUnit = obs && typeof obs.unit === 'string' ? obs.unit : undefined;
  const effectiveCap = rec.cap ?? factorCap;
  if (effectiveCap === undefined) return undefined; // no cap → not safely derivable

  try {
    const { value } = normaliseFactorValue({
      rawInput: rec.raw_value,
      ...(rec.unit !== undefined ? { unit: rec.unit } : {}),
      ...(rec.cap !== undefined ? { proposalCap: rec.cap } : {}),
      ...(factorCap !== undefined ? { factorCap } : {}),
      ...(factorUnit !== undefined ? { factorUnit } : {}),
      inputHasUnit: rec.unit !== undefined,
    });
    return Number.isFinite(value) ? value : undefined;
  } catch {
    return undefined; // canonical guards rejected (unit mismatch / range / ambiguous) → defer
  }
}

/**
 * ⭐⭐ FIELDS THIS RECONSTRUCTION OWNS OR THE NEW VALUE INVALIDATES.
 *
 * Everything else on an existing entry is carried through. The split is the
 * whole point: `reasoning`, evidence references and other additive provenance
 * describe the ASSUMPTION and survive a change of number, while anything
 * DERIVED FROM the old number would contradict the new one and must not be
 * inherited.
 *
 *   value, source, target_match  — set explicitly below; the writer owns them.
 *   display_value                — presentation synthesised from the value.
 *                                  "Very high (1)" sitting on 0.75 is the exact
 *                                  stale-display harm this list exists to stop.
 *   raw_value, value_type,
 *   encoding_map                 — the value's own encoding. Re-supplied from
 *                                  the NEW proposal below when it carries them.
 *   value_confidence             — confidence in the OLD value. A user-specified
 *                                  number does not inherit a prior estimate's
 *                                  confidence.
 *   source_quote                 — words supporting the OLD figure. Re-supplied
 *                                  below only when the encoded figure is the
 *                                  same; £59 cannot warrant a later £60.
 */
/**
 * ⚠ `reasoning` IS ON THIS LIST DELIBERATELY, AND I HAD IT WRONG FIRST.
 *
 * It reads like unrelated prose, so my first version carried it through. It is
 * not, and **PR #276's CASE 4 is the load-bearing evidence** — that reviewed case
 * already pinned `reasoning` as stale value-descriptive metadata a value override
 * must drop. A justification for 0.9 sitting beside a committed 0.55 is the same
 * defect as a stale `display_value`, one sentence further down the card.
 *
 * ⚠ The producer's docstring is NOT strong enough to carry this on its own, and
 * I originally leaned on it. `cee-v3.ts:457` says only "Explanation for
 * transparency" — unqualified — while its neighbours `value_confidence`
 * ("Confidence in the value itself") and `display_value` DO bind themselves to
 * the value explicitly. **This producer says so when it means it**, so the
 * silence is evidence against my reading, not for it. The precedent decides;
 * the docstring merely fails to contradict it.
 *
 * The line this list draws is not "derived vs prose". It is: does the field
 * make a claim ABOUT THE VALUE? `reasoning`, `display_value` and
 * `value_confidence` do, so they go. `evidence_refs` and the person's own
 * annotations do not, so they survive.
 */
const VALUE_DERIVED_OR_OWNED_KEYS: ReadonlySet<string> = new Set([
  'value', 'source', 'target_match',
  'display_value', 'raw_value', 'value_type', 'encoding_map', 'value_confidence', 'source_quote',
  'reasoning',
  // The range the OLD figure was read against: it travels with `raw_value`, so a new number never inherits it.
  'cap',
]);

const QUOTED_FIGURE_KEYS = ['value', 'raw_value', 'unit', 'cap', 'value_type', 'encoding_map'] as const;

/**
 * Construct a canonical InterventionV3, preserving an existing top-level entry's
 * `target_match` AND its unrelated legitimate metadata.
 *
 * ⚠⚠ THE PRESERVATION HALF IS NEW, AND IT EXISTS BECAUSE ADMITTING A POPULATION
 * MADE IT REACHABLE. Entries persisted without `target_match` used to be refused
 * outright, so nothing of theirs could be lost. Now that they are editable, this
 * reconstruction was silently dropping their additive evidence and provenance
 * every time a value changed — the intervention contract is `.passthrough()`, so
 * those fields are legal and were simply not rebuilt.
 *
 * ⚠ `reasoning` IS NOT IN THAT SET, AND THE DISTINCTION IS THE WHOLE POINT.
 * An earlier version of this comment named it alongside the evidence, twenty
 * lines above the list that now deliberately drops it — the code and its
 * justification disagreeing in the same file. `reasoning` is value-descriptive
 * (PR #276's CASE 4 pinned it as stale metadata a value override must drop), so
 * dropping it is the fix, not the defect.
 *
 * ⚠ AND THE CONSEQUENCE, STATED RATHER THAN LEFT TO BE DISCOVERED: this function
 * supplies no replacement, so a value edit DELETES the explanation rather than
 * refreshing it. That is deliberate — a justification written for the old value
 * is false beside the new one, and there is nothing here that could author a
 * true one. If the product should instead PROMPT for a fresh explanation, that
 * is a capability decision, not a change to make quietly inside this writer.
 *
 * ⚠ AND THE SCOPE GUARD CANNOT SEE IT. `optionInterventionPostimageIsScoped`
 * restores the WHOLE selected cell before comparing, so it proves only that no
 * OTHER cell moved — never that this cell kept its own fields. Passing it is not
 * evidence of preservation, which is why the controls assert the committed
 * object directly.
 */
function sameNativeQuantity(before: Dict, after: Dict, oldFrame?: FactorScaleInfo, newFrame?: FactorScaleInfo): boolean {
  if (!isDeepStrictEqual(before.value_type, after.value_type) || !isDeepStrictEqual(before.encoding_map, after.encoding_map)) return false;
  const oldPoint = resolveRawInterventionValue(before, oldFrame);
  const newPoint = resolveRawInterventionValue(after, newFrame);
  const unit = (cell: Dict, frame?: FactorScaleInfo) => unitComparisonKey(typeof cell.unit === 'string' && cell.unit.trim() !== '' ? cell.unit : frame?.unit);
  if (unit(before, oldFrame) !== unit(after, newFrame)) return false;
  if (oldPoint.rule === 'ambiguous_no_evidence' || newPoint.rule === 'ambiguous_no_evidence') {
    return QUOTED_FIGURE_KEYS.every(key => isDeepStrictEqual(before[key], after[key]))
      && isDeepStrictEqual(oldFrame, newFrame);
  }
  return oldPoint.value !== null && oldPoint.value === newPoint.value;
}

function buildInterventionV3(fac: string, value: number, rec: RawIntervention, existing: unknown, frame?: FactorScaleInfo): Dict {
  const carried: Dict = {};
  if (isPlainObject(existing)) {
    for (const [key, entryValue] of Object.entries(existing)) {
      if (!VALUE_DERIVED_OR_OWNED_KEYS.has(key)) carried[key] = entryValue;
    }
  }
  const iv: Dict = {
    ...carried,
    value,
    // Default UNCHANGED. `rec.source` is only ever a non-user provenance the
    // writer stated explicitly (see `PRESERVED_INTERVENTION_SOURCES`), so this
    // can narrow the claim but never widen it to user-authored.
    source: rec.source ?? 'user_specified',
    target_match:
      isPlainObject(existing) && isPlainObject(existing.target_match)
        ? existing.target_match
        : { node_id: fac, match_type: 'exact_id', confidence: 'high' },
  };
  if (rec.unit !== undefined) iv.unit = rec.unit;
  if (rec.raw_value !== undefined) iv.raw_value = rec.raw_value;
  /**
   * ⭐ THE RANGE THE FIGURE WAS READ AGAINST, KEPT BESIDE IT (DL #70 5848777655; the lost £10). A user's "£10 per month" on
   * a NEW factor is stored as 0.1 of a range of 100 that lives nowhere else — the factor declares none — and without it
   * `value == raw_value / cap` cannot be re-checked on readback, nor a £0 level's range recovered at all (0 ÷ 0).
   * Stored ONLY when it reproduces the stored level exactly, so a cell that holds `cap` always satisfies that identity.
   * Hash-neutral: the analysis hash reads an intervention's `value`, `value_type` and `encoding_map` only.
   */
  if (rec.raw_value !== undefined && rec.cap !== undefined && rec.cap > 0 && Math.abs(rec.raw_value / rec.cap - value) <= 1e-9) {
    iv.cap = rec.cap;
  }
  // Carried only alongside a preserved non-user provenance: an estimate that
  // cannot say how confident it is, or why, is not reviewable after the turn
  // that produced it. `VALUE_DERIVED_OR_OWNED_KEYS` above drops the OLD entry's
  // copies of both, so these are re-supplied from the NEW record or not at all.
  if (rec.value_confidence !== undefined) iv.value_confidence = rec.value_confidence;
  if (rec.reasoning !== undefined) iv.reasoning = rec.reasoning;
  // TEMPORAL: a range supplied with this figure replaces the one carried from the old entry. With none supplied, the old
  // range is kept ONLY while the quantity is unchanged (Codex CR 5963331228 P1): a new figure, or the same digits in
  // another unit (10 days → 10 weeks), is a different quantity, and containment cannot tell, so its range is dropped.
  if (rec.range !== undefined) iv.range = rec.range;
  else if ('range' in iv && !(isPlainObject(existing) && sameNativeQuantity(existing, iv, frame, frame))) {
    delete iv.range;
  }
  if (isPlainObject(existing) && typeof existing.source_quote === 'string'
    && QUOTED_FIGURE_KEYS.every((key) => isDeepStrictEqual(existing[key], iv[key]))) {
    iv.source_quote = existing.source_quote;
  }
  return iv;
}

/**
 * A whole-map `update_node` can replace an already numeric intervention without
 * entering `buildInterventionV3`. Clear a quote or range copied from the persisted
 * OLD cell when the quantity changed; a fresh replacement remains, and an unchanged
 * quantity keeps its original metadata.
 */
export function clearInheritedInterventionSourceQuotes<T>(before: unknown, after: T): T {
  if (!isPlainObject(before) || !Array.isArray(before.nodes)
    || !isPlainObject(after) || !Array.isArray(after.nodes)) return after;
  const priorOptions = new Map<string, Dict>();
  const oldFrames = buildFactorScaleMap(before.nodes);
  const newFrames = buildFactorScaleMap(after.nodes);
  for (const node of before.nodes) {
    if (isPlainObject(node) && node.kind === 'option' && typeof node.id === 'string') priorOptions.set(node.id, node);
  }
  let updatedNodes: Dict[] | undefined;
  const afterNodes = after.nodes as Dict[];
  for (let index = 0; index < afterNodes.length; index += 1) {
    const node = afterNodes[index];
    if (!isPlainObject(node) || node.kind !== 'option' || typeof node.id !== 'string'
      || !isPlainObject(node.interventions)) continue;
    const prior = priorOptions.get(node.id);
    if (!prior || !isPlainObject(prior.interventions)) continue;
    let updatedInterventions: Dict | undefined;
    for (const [factorId, cell] of Object.entries(node.interventions)) {
      const oldCell = prior.interventions[factorId];
      if (!isPlainObject(cell) || !isPlainObject(oldCell)) continue;
      const figureChanged = !sameNativeQuantity(oldCell, cell, oldFrames.get(factorId), newFrames.get(factorId));
      if (!figureChanged) continue;
      const staleQuote = typeof cell.source_quote === 'string' && cell.source_quote === oldCell.source_quote;
      const staleRange = cell.range !== undefined && oldCell.range !== undefined && isDeepStrictEqual(cell.range, oldCell.range);
      if (!staleQuote && !staleRange) continue;
      const withoutStaleMetadata = { ...cell };
      if (staleQuote) delete withoutStaleMetadata.source_quote;
      if (staleRange) delete withoutStaleMetadata.range;
      updatedInterventions ??= { ...node.interventions };
      updatedInterventions[factorId] = withoutStaleMetadata;
    }
    if (updatedInterventions !== undefined) {
      updatedNodes ??= [...afterNodes];
      updatedNodes[index] = { ...node, interventions: updatedInterventions };
    }
  }
  return updatedNodes === undefined ? after : { ...after, nodes: updatedNodes } as T;
}

/** Generic edit ports cannot grant range consent, even when their whole operation is approved. */
export function hasNewInterventionRanges(before: unknown, after: unknown): boolean {
  if (!isPlainObject(after) || !Array.isArray(after.nodes)) return false;
  const prior = new Map<string, Dict>();
  if (isPlainObject(before) && Array.isArray(before.nodes)) {
    for (const node of before.nodes) if (isPlainObject(node) && typeof node.id === 'string' && isPlainObject(node.interventions)) prior.set(node.id, node.interventions);
  }
  for (const node of after.nodes) {
    if (!isPlainObject(node) || !isPlainObject(node.interventions)) continue;
    for (const [factorId, cell] of Object.entries(node.interventions)) {
      if (!isPlainObject(cell) || cell.range === undefined) continue;
      const old = prior.get(String(node.id))?.[factorId];
      if (!isPlainObject(old) || !isDeepStrictEqual(old.range, cell.range)) return true;
    }
  }
  return false;
}

/**
 * Encode option interventions to the canonical top-level contract, or report
 * which (touched) options cannot be safely encoded.
 *
 * @param graph  the post-edit graph (any shape; treated defensively).
 * @param touchedOptionIds  option ids the edit referenced; only these can flag an
 *   unresolved/defer (a pre-existing malformed option cannot block an unrelated
 *   edit). When undefined, every option may flag.
 * @param mustConfigureOptionIds  option ids this edit ADDED while REQUESTING an
 *   intervention configuration (the `add_node` payload carried intervention
 *   intent). Configure-or-don't-persist (P0-A): if such an option ends up with
 *   zero canonical top-level interventions — because cap/unit/evidence/encoding
 *   was missing so the requested value could not be derived — it would persist
 *   as `interventions:null` and make run_analysis fail `options_not_configured`,
 *   so it is DEFERRED (the edit rejects, graph unchanged). This is INTENT-scoped,
 *   NOT "any added option": an option added with NO intervention request (an
 *   intentional `needs_encoding` option, configured in a later turn) is a valid
 *   intermediate state and must NOT block — only a FAILED configuration attempt
 *   does. The caller derives this set from the add operations' payloads.
 */
export function encodeOptionInterventionsForEdit<T>(
  graph: T,
  touchedOptionIds?: ReadonlySet<string>,
  mustConfigureOptionIds?: ReadonlySet<string>,
): EncodeOptionInterventionsResult<T> {
  if (!isPlainObject(graph) || !Array.isArray((graph as Dict).nodes)) {
    return { graph, unresolvedOptionIds: [] };
  }

  try {
    const nodes = (graph as Dict).nodes as unknown[];
    const frames = buildFactorScaleMap(nodes);
    const edges = Array.isArray((graph as Dict).edges) ? ((graph as Dict).edges as unknown[]) : [];

    const factorById = new Map<string, Dict>();
    for (const n of nodes) {
      if (isPlainObject(n) && n.kind === 'factor' && typeof n.id === 'string') factorById.set(n.id, n);
    }
    const optionTargets = new Map<string, string[]>();
    for (const e of edges) {
      if (!isPlainObject(e)) continue;
      const from = e.from;
      const to = e.to;
      if (typeof from === 'string' && typeof to === 'string' && factorById.has(to)) {
        (optionTargets.get(from) ?? optionTargets.set(from, []).get(from)!).push(to);
      }
    }

    // NOTE on scope: ENCODE is applied to every encodable option (touched or
    // not) — a benign normalisation that mirrors the PR #276 commit normaliser
    // and is robust to a touched-detector false-negative. It can therefore repair
    // a pre-existing malformed option during an unrelated edit (and change the
    // graph hash); `node_ids` below makes that measurable. DEFER, by contrast, is
    // strictly touched-scoped — a pre-existing un-encodable option never blocks an
    // unrelated edit.
    const plan: Array<{ index: number; id: string; bundle: Dict }> = [];
    const unresolved: string[] = [];

    for (let i = 0; i < nodes.length; i++) {
      const node = nodes[i];
      if (!isPlainObject(node) || node.kind !== 'option') continue;
      const id = typeof node.id === 'string' ? node.id : '<unknown>';
      const isTouched = !touchedOptionIds || touchedOptionIds.has(id);
      const mustConfigure = mustConfigureOptionIds !== undefined && mustConfigureOptionIds.has(id);
      const targets = optionTargets.get(id) ?? [];
      const recovered = gatherRawInterventions(node, targets);

      // Preserve numeric top-level entries verbatim (PR #276 configured entries).
      const base: Dict = {};
      const top = node.interventions;
      if (isPlainObject(top)) {
        for (const [fac, iv] of Object.entries(top)) {
          if (toRawIntervention(iv).value !== undefined) base[fac] = isPlainObject(iv) ? { ...iv } : iv;
        }
      }

      if (recovered.size === 0) {
        // Nothing to encode here. A touched option carrying node-level intervention
        // intent that gatherRawInterventions could not attribute (SHAPE 2 with an
        // ambiguous target — zero or multiple factor edges) is malformed → defer.
        // NOTE: an option merely WIRED to factors with no interventions is a valid
        // intermediate ("needs encoding") state — NOT a malformed intervention — so
        // it is left alone for EDITS. Deferring it would wrongly reject an unrelated
        // edit (e.g. a label rename) on such a pre-existing under-configured option.
        if (Object.keys(base).length === 0) {
          if (mustConfigure) {
            // P0-A configure-or-don't-persist: this option was ADDED while
            // REQUESTING an intervention configuration, but it ends up with zero
            // canonical top-level interventions — the requested value could not
            // be encoded (cap/unit/evidence/encoding missing) and collapsed away.
            // Persisting it as interventions:null would make run_analysis fail
            // options_not_configured. Defer so the graph is unchanged. (An option
            // added with NO request — an intentional needs_encoding option — is
            // NOT in this set, so it still passes through.)
            unresolved.push(id);
          } else {
            const nodeLevelIntent = finiteNum(node.raw_value) !== undefined || finiteNum(node.value) !== undefined;
            if (nodeLevelIntent && isTouched) unresolved.push(id);
          }
        }
        continue;
      }

      const bundle: Dict = { ...base };
      let optionUnresolved = false;
      for (const [fac, rec] of recovered) {
        const value = deriveValue(rec, factorById.get(fac));
        if (value === undefined) {
          optionUnresolved = true;
          break;
        }
        bundle[fac] = buildInterventionV3(fac, value, rec, base[fac], frames.get(fac));
      }

      if (optionUnresolved) {
        // Touched (edit referenced it) OR a must-configure add (new option that
        // requested an intervention that cannot be encoded, e.g. an uncappable
        // factor) → defer. A must-configure add must not persist unconfigured
        // (P0-A), the same as a touched option.
        if (isTouched || mustConfigure) unresolved.push(id);
        continue; // leave malformed; discarded if the edit defers, else untouched
      }
      plan.push({ index: i, id, bundle });
    }

    if (unresolved.length > 0) {
      return { graph, unresolvedOptionIds: unresolved }; // caller defers; no clone/mutate
    }
    if (plan.length === 0) {
      return { graph, unresolvedOptionIds: [] };
    }

    const clone = JSON.parse(JSON.stringify(graph)) as T;
    const cloneNodes = (clone as Dict).nodes as Dict[];
    for (const { index, bundle } of plan) {
      const node = cloneNodes[index]!;
      node.interventions = bundle;
      if (isPlainObject(node.data)) {
        delete (node.data as Dict).interventions;
        if (Object.keys(node.data as Dict).length === 0) delete node.data;
      }
      for (const k of Object.keys(node)) {
        // NEVER matches bare `interventions` — see `interventionRootIndex`.
        if (isFlatInterventionKey(k)) delete node[k];
      }
      delete node.unit;
      delete node.raw_value;
      delete node.value;
      delete node.cap;
    }

    log.info(
      { event: 'v5.edit_graph.option_interventions_encoded', encoded_count: plan.length, node_ids: plan.map((p) => p.id) },
      '[edit_graph] encoded option interventions to the canonical top-level contract',
    );

    return { graph: clone, unresolvedOptionIds: [] };
  } catch (err) {
    // Fail-CLOSED for the edit path: on an unexpected error we cannot certify the
    // touched options are analysis-ready, so we DEFER them (the caller rejects the
    // edit, leaving the graph unchanged) rather than risk persisting a malformed
    // option. Non-edit callers (no touched set) get the graph unchanged, no defer.
    try {
      log.warn(
        { event: 'v5.edit_graph.option_interventions_encode_failed', error_name: err instanceof Error ? err.name : 'non_error' },
        '[edit_graph] option-intervention encode threw; deferring touched options',
      );
    } catch { /* observability best-effort */ }
    // Defer the touched set AND any must-configure adds (a failed encode must
    // never leave an added-with-intent option persisted unconfigured).
    const deferOnError = new Set<string>([
      ...(touchedOptionIds ? touchedOptionIds : []),
      ...(mustConfigureOptionIds ? mustConfigureOptionIds : []),
    ]);
    return { graph, unresolvedOptionIds: Array.from(deferOnError) };
  }
}

/**
 * Option ids referenced by a set of patch operations (so a pre-existing,
 * untouched malformed option cannot block an unrelated edit). Loose
 * string-contains over each op's path + serialised value, intersected with the
 * actual option node ids — an over-approximation that is safe (only widens
 * "touched", never persists malformed shapes).
 */
export function optionIdsTouchedByOperations(
  operations: ReadonlyArray<{ path?: unknown; value?: unknown }>,
  graph: unknown,
): Set<string> {
  const touched = new Set<string>();
  if (!isPlainObject(graph) || !Array.isArray((graph as Dict).nodes)) return touched;
  const optionIds = ((graph as Dict).nodes as unknown[])
    .filter((n): n is Dict => isPlainObject(n) && n.kind === 'option' && typeof n.id === 'string')
    .map((n) => n.id as string);
  if (optionIds.length === 0) return touched;
  for (const op of operations) {
    let blob = typeof op.path === 'string' ? op.path : '';
    try { blob += ' ' + JSON.stringify(op.value ?? ''); } catch { /* ignore unserialisable */ }
    for (const id of optionIds) {
      if (blob.includes(id)) touched.add(id);
    }
  }
  return touched;
}

/** True when an add_node option payload REQUESTED an intervention (any shape). */
function addPayloadRequestsIntervention(value: Dict): boolean {
  // Top-level interventions bundle with at least one entry.
  if (isPlainObject(value.interventions) && Object.keys(value.interventions as Dict).length > 0) return true;
  // EXPLICIT null interventions = a configuration that was attempted and
  // collapsed to nothing (distinct from the key being absent = an intentional
  // bare needs_encoding add). An explicit empty {} stays a no-request bare add.
  if ('interventions' in value && value.interventions === null) return true;
  // data.interventions bundle (SHAPE 1) with at least one entry, or explicit null.
  const data = value.data;
  if (isPlainObject(data)) {
    const di = (data as Dict).interventions;
    if (isPlainObject(di) && Object.keys(di as Dict).length > 0) return true;
    if ('interventions' in (data as Dict) && di === null) return true;
  }
  // Flat intervention-subtree entries, every accepted spelling.
  for (const k of Object.keys(value)) {
    if (isFlatInterventionKey(k)) return true;
  }
  // Node-level scalar intent (SHAPE 2): a unit/raw_value/value smeared on the option.
  if (finiteNum(value.raw_value) !== undefined || finiteNum(value.value) !== undefined || typeof value.unit === 'string') {
    return true;
  }
  return false;
}

/**
 * Option ids ADDED by this edit (`add_node`, kind `option`) whose payload
 * REQUESTED an intervention configuration. These are the configure-or-don't-
 * persist set (P0-A): if the requested value cannot be encoded into canonical
 * top-level interventions (cap/unit/evidence missing), the add must DEFER
 * rather than persist an `interventions:null` option that later fails
 * run_analysis with `options_not_configured`.
 *
 * Deliberately INTENT-scoped: an option added with NO intervention request (an
 * intentional `needs_encoding` option to configure in a later turn) is NOT in
 * this set, so the established two-phase add flow is preserved.
 */
export function optionIdsAddedWithInterventionIntent(
  operations: ReadonlyArray<{ op?: unknown; value?: unknown }>,
): Set<string> {
  const ids = new Set<string>();
  for (const op of operations) {
    if (op.op !== 'add_node') continue;
    const value = op.value;
    if (!isPlainObject(value) || value.kind !== 'option') continue;
    const id = typeof value.id === 'string' ? value.id : undefined;
    if (id === undefined) continue;
    if (addPayloadRequestsIntervention(value)) ids.add(id);
  }
  return ids;
}
