/**
 * ROADMAP 2.972 — IS THIS MAGNITUDE PRESENT IN THE TEXT THE USER SUBMITTED?
 *
 * WHAT THIS ANSWERS, exactly, and nothing wider. Given a number the SYSTEM
 * committed to (an option intervention level) and the text the USER supplied
 * (`brief_text`, as persisted), it answers one question:
 *
 *     "Is this magnitude PRESENT IN THE TEXT THE USER SUBMITTED, at this
 *      scale, in this currency?"
 *
 * ⚠ THAT IS NOT THE SAME CLAIM AS "the user said this" (naming corrected after
 * the adversarial review of #873, which was right that the earlier wording
 * overclaimed). A number inside a quoted third party's sentence — B1's "legal
 * quoted us €250k", "Priya's cohort model … says £15.8m" — is present in the
 * submitted text without being the user's own assertion. This module cannot
 * tell those apart and does not try: separating them needs intent parsing that
 * fails toward silently disbelieving users, which is a worse failure than the
 * one it would fix. Admitting a quoted number therefore means "we have no
 * grounds to WITHDRAW the claim", never "the claim is attested".
 *
 * It is the evidence gate for the provenance claim `source: "brief_extraction"`
 * / `value_confidence: "high"`. It NEVER reads a number OUT of the brief to
 * USE, and it stamps nothing as the user's own — this module is not a writer of
 * any user-owned provenance literal, which is why it is absent from the
 * reviewed manifest in `transforms/__tests__/no-brief-derived-user-override.writers.test.ts`.
 * That distinction is the whole safety argument, and it is the opposite
 * direction from the reverted 2.714 / #853 seam (`graph-data-integrity.ts`,
 * "⚠ NONE OF THESE READS THE BRIEF, and none may") which took a stated number
 * out of prose and presented it back as the user's own statement: that MINTS a
 * value and can be 10^6x wrong; this one only ever WEAKENS a label the model
 * already wrote, and its worst failure is an honest `cee_hypothesis` on a value
 * that was in fact brief-derived.
 *
 * ⚠ IT IS A NECESSARY CONDITION, NOT A SUFFICIENT ONE, and that is stated here
 * so no later reader mistakes it for attestation. "45" appearing in "45 roles"
 * makes a plain-unit 45 locatable even if the model meant something else
 * entirely. The predicate therefore governs only the DOWNGRADE direction: not
 * locatable ⇒ the strong claim is withdrawn; locatable ⇒ we have no grounds to
 * withdraw it and it stands. Fail toward under-claiming, never toward the
 * stronger claim.
 *
 * ⚠⚠ THE FALSE-NEGATIVE SET IS BROADER THAN THE LIST BELOW, AND THE LIST IS
 * NOT COMPLETE. Named so no later reader mistakes it for an inventory: the
 * adversarial review of #873 enumerated further classes this scan does not
 * read — ranges where a currency does not distribute (`£2–3m`; the real corpus
 * contains `10-15%`), a bare magnitude unit measured against a currency
 * statement, word-form currency units ("pounds") and word-form percentages
 * ("60 per cent"), signed values, locale decimal separators, ISO codes written
 * inside the BRIEF (only the UNIT form is read), and postfix currency
 * (`900kr`). All are rowed separately. Every one of them fails toward
 * under-claiming — a genuinely brief-backed value is labelled
 * `cee_hypothesis` — which is the safe direction, but it is a real coverage
 * loss and it is not a closed set.
 *
 * DELIBERATE REFUSALS (a subset of the above, chosen rather than merely
 * unimplemented — each costs coverage and buys truth):
 *   - WORD-FORM numerals ("two existing customers", "one compulsory round")
 *     are not read. A lever set to 1 must not become "brief-extracted" because
 *     the brief says "one".
 *   - PERCENT↔FRACTION equivalence is NOT applied. Measured on the trace
 *     corpus: B3 says "if attach were 100%", and admitting 1 ↔ 100% would have
 *     kept the false `brief_extraction` on `opt_copilot.fac_copilot_build = 1`,
 *     a binary lever that has nothing to do with attach rate.
 *   - CURRENCY IDENTITY IS REQUIRED. B1 states "€900k" and "€250k"; the draft
 *     stamped `£m` intervention values. A £-denominated value is not made
 *     brief-backed by a €-denominated statement — that currency swap is itself
 *     one of the measured losses (loss-map B1-A13).
 *   - A numeral glued to letters ("FY28") is not an amount.
 *
 * THE ALPHABET IS NOT RE-DERIVED HERE (CLAUDE.md trap 12). Digits, thousands
 * separators, magnitude suffixes and the ambiguous-trailer guard all come from
 * `utils/magnitude-alphabet.ts`; the currency vocabulary comes from
 * `cee/extraction/numeric-parser.ts`'s `CURRENCY_SYMBOL_TO_CODE`. A key added
 * to either list is live here the instant it lands, with nothing to sync.
 */

import {
  AMOUNT_DIGITS,
  MAGNITUDE_AMBIGUOUS_TRAILER_GUARD,
  magnitudeSuffixPattern,
  parseAmountDigits,
  resolveMagnitude,
} from "../../utils/magnitude-alphabet.js";
import { CURRENCY_SYMBOL_TO_CODE } from "../extraction/numeric-parser.js";
import { resolveExistingRawValue } from "../../orchestrator-v5/tools/handlers/d1-shared/evaluate-factor-value-proposal.js";
import { recoverScaleFrame } from "../../orchestrator-v5/tools/handlers/d1-shared/scale-frame.js";

/** What KIND of quantity a written amount (or a unit string) denotes. */
export type AmountKind = "currency" | "percent" | "plain";

/** One amount found in the text the user submitted. */
export interface StatedAmount {
  /** Absolute magnitude as written: 250000 for "€250k", 60 for "60%", 45 for "45 roles". */
  readonly magnitude: number;
  readonly kind: AmountKind;
  /** ISO-ish currency code (GBP/USD/EUR/…) when `kind === "currency"`. */
  readonly currencyCode?: string;
  readonly matchedText: string;
  readonly index: number;
}

/** Escape a literal for use inside a regex alternation built from data. */
function escapeForAlternation(literal: string): string {
  return literal.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/**
 * Build a longest-first alternation from a set of literals. Alternation is
 * first-match-wins, so a bare `$` placed before `A$` would swallow it; sorting
 * by raw length before escaping cannot get that wrong for any literal, present
 * or future.
 */
function alternationOf(literals: Iterable<string>): string {
  return [...new Set(literals)]
    .sort((a, b) => b.length - a.length || (a < b ? -1 : a > b ? 1 : 0))
    .map(escapeForAlternation)
    .join("|");
}

/** The currency SYMBOL alternation, derived from the shared map's keys. */
const CURRENCY_ALTERNATION: string = alternationOf(Object.keys(CURRENCY_SYMBOL_TO_CODE));

/**
 * The currency ISO-CODE alternation, derived from the SAME map's values.
 *
 * ⚠ WHY THIS EXISTS (adversarial review of #873). The currency-identity
 * refusal was spelled against the symbol form only, so it held for
 * `unit: "£"` and COLLAPSED for `unit: "GBP"`: the code read as an
 * unrecognised unit, degraded to `plain`, and `plain` accepted any kind — so a
 * £-nothing value was certified brief-extracted against a `€900k` statement.
 * That is the fabrication direction, and `GBP` is the producer's own
 * vocabulary, not a synthetic edge (`schemas/cee-v3.ts:57` documents the unit
 * field as "e.g. 'GBP', 'USD'", and `parseNumericValue("£59")` returns
 * `unit: "GBP"` in the module this one imports the map from).
 *
 * Derived from `Object.values(...)` rather than listed, so the symbol form and
 * the code form of a currency can never disagree about which currencies exist.
 */
const ISO_CURRENCY_ALTERNATION: string = alternationOf(Object.values(CURRENCY_SYMBOL_TO_CODE));

/**
 * The scan pattern.
 *
 * `(?<![\w.])` is load-bearing twice over: it stops the "28" of "FY28" being
 * read as an amount, and it stops the trailing "2" of "11.2" being re-read as
 * its own amount on the next scan position.
 */
const STATED_AMOUNT_PATTERN = new RegExp(
  `(?<![\\w.])(?<currency>${CURRENCY_ALTERNATION})?\\s*` +
    `(?<digits>${AMOUNT_DIGITS})` +
    magnitudeSuffixPattern("mag") +
    MAGNITUDE_AMBIGUOUS_TRAILER_GUARD +
    `(?<pct>\\s*%)?`,
  "gi",
);

/**
 * Every amount stated in `text`, in source order.
 *
 * Pure. Never throws. An empty / non-string input yields an empty array, which
 * makes every value un-locatable — the fail-closed direction.
 */
export function findStatedAmounts(text: string | null | undefined): readonly StatedAmount[] {
  if (typeof text !== "string" || text.length === 0) return [];
  const out: StatedAmount[] = [];
  // A fresh RegExp per call: `lastIndex` on a shared /g instance is
  // cross-call state, and a shared one would make this function's answer
  // depend on who called it last.
  const pattern = new RegExp(STATED_AMOUNT_PATTERN.source, STATED_AMOUNT_PATTERN.flags);
  // The digits and the written magnitude suffix of each amount, for the range reading below.
  const parts: { digits: number; mag: string }[] = [];
  for (let m = pattern.exec(text); m !== null; m = pattern.exec(text)) {
    const groups = m.groups ?? {};
    const digits = parseAmountDigits(groups.digits);
    if (digits === null) continue;
    const magnitude = digits * resolveMagnitude(groups.mag);
    if (!Number.isFinite(magnitude)) continue;

    const symbol = groups.currency;
    const isPercent = typeof groups.pct === "string";
    // A currency symbol wins over a trailing '%': "£40%" is not a shape any
    // brief writes, and reading it as currency keeps the two kinds disjoint.
    const kind: AmountKind = symbol ? "currency" : isPercent ? "percent" : "plain";
    const currencyCode = symbol
      ? CURRENCY_SYMBOL_TO_CODE[symbol] ?? CURRENCY_SYMBOL_TO_CODE[symbol.toUpperCase()] ?? symbol
      : undefined;

    out.push({
      magnitude,
      kind,
      ...(currencyCode !== undefined && { currencyCode }),
      matchedText: m[0],
      index: m.index,
    });
    parts.push({ digits, mag: typeof groups.mag === "string" ? groups.mag.trim() : "" });
  }
  return distributeCurrencyRanges(text, out, parts);
}

/**
 * ⭐ A CURRENCY RANGE SHARES ITS CURRENCY AND ITS MAGNITUDE WITH BOTH ENDS (R3 #75 5918453000 A4; MG 5918487838).
 * Paul's funding brief: "investment firms that do deals between £1-2m" was read as `£1` (currency, 1) and
 * `2` with its magnitude word (plain), so the deal size could not be the user's at either end: £1m was nowhere, and £2m was not money.
 * Only the narrow written shape is read: a CURRENCY amount with NO magnitude of its own, joined by a dash ("-", "–",
 * "—"), "to", or (after "between") "and" to the very next amount, which carries a magnitude and is plain or in the SAME currency
 * ("£1-2m", "£1–2m", "£1 to 2m", "between £1 and £2m", and each with its magnitude written as a word). Both ends then read as that currency at
 * that magnitude. Anything else is left exactly as read (`£2–3m` whose first end has its own suffix already reads both).
 */
function distributeCurrencyRanges(
  text: string,
  amounts: StatedAmount[],
  parts: readonly { digits: number; mag: string }[],
): readonly StatedAmount[] {
  for (let i = 0; i + 1 < amounts.length; i += 1) {
    const low = amounts[i]!;
    const high = amounts[i + 1]!;
    if (low.kind !== "currency" || parts[i]!.mag !== "" || parts[i + 1]!.mag === "") continue;
    if (!(high.kind === "plain" || (high.kind === "currency" && high.currencyCode === low.currencyCode))) continue;
    if (!joinedAsRange(text, low, high)) continue;
    const scale = resolveMagnitude(parts[i + 1]!.mag);
    const lowAtScale = parts[i]!.digits * scale;
    if (!Number.isFinite(lowAtScale)) continue;
    amounts[i] = { ...low, magnitude: lowAtScale };
    amounts[i + 1] = { ...high, kind: "currency", ...(low.currencyCode !== undefined && { currencyCode: low.currencyCode }) };
  }
  return amounts;
}

/**
 * Two amounts written as ONE range: joined by a dash ("-", "–", "—"), "to", or (after "between") "and". "£1 and 2m
 * customers" is two amounts, not a range (R3 5918513716).
 */
function joinedAsRange(text: string, low: StatedAmount, high: StatedAmount): boolean {
  const between = text.slice(low.index + low.matchedText.length, high.index);
  return /^\s*(?:[-–—]|to)\s*$/i.test(between)
    || (/^\s*and\s*$/i.test(between) && /\bbetween\s*$/i.test(text.slice(0, low.index)));
}

/** A money range the text writes, both ends read in one currency ("£1-2m" → £1,000,000 to £2,000,000). */
export interface StatedRange {
  readonly low: StatedAmount;
  readonly high: StatedAmount;
  /** The range exactly as written, from the low end's first character to the high end's last: "£1-2m". */
  readonly text: string;
}

/**
 * ⭐ THE MONEY RANGES A TEXT WRITES (A4, R3 C1 5918513716): a size read from one end of a range is said WITH the range,
 * never as the user's single figure. Two consecutive currency amounts in the same currency, joined as a range
 * (`joinedAsRange`), the low end below the high. Every other pair is not a range.
 */
export function findStatedRanges(text: string | null | undefined): readonly StatedRange[] {
  if (typeof text !== "string") return [];
  const amounts = findStatedAmounts(text);
  const ranges: StatedRange[] = [];
  for (let i = 0; i + 1 < amounts.length; i += 1) {
    const low = amounts[i]!;
    const high = amounts[i + 1]!;
    if (low.kind !== "currency" || high.kind !== "currency" || low.currencyCode !== high.currencyCode) continue;
    if (!(low.magnitude < high.magnitude) || !joinedAsRange(text, low, high)) continue;
    ranges.push({ low, high, text: text.slice(low.index, high.index + high.matchedText.length).trim() });
  }
  return ranges;
}

/** What a graph unit string denotes, and the multiplier it implies. */
export interface UnitReading {
  readonly kind: AmountKind;
  readonly currencyCode?: string;
  /**
   * The unit's currency token WITH ITS MAGNITUDE SUFFIX REMOVED, exactly as the
   * unit string spelled it: `"£m" ⇒ "£"`, `"GBPm" ⇒ "GBP"`, `"£" ⇒ "£"`.
   * Present iff `kind === "currency"`.
   *
   * ⚠ WHY IT IS HERE RATHER THAN LEFT TO EACH CALLER (WS-A round 2, B3). A
   * consumer that has applied {@link multiplier} to a level has ALREADY spent
   * the unit's magnitude letter; prefixing the raw unit string afterwards
   * spends it twice, and the copy misstates the user's own money by 10^6 —
   * `£1m` rendered as `£m1,000,000`, and the brief's own `£0.9m` as
   * `£m900,000` (measured on `money-invariant.ts` at `3038820c`). The two
   * pieces of information — HOW MUCH to scale by, and WHAT TO CALL IT — are
   * different questions with one source, so `readUnit` answers both rather
   * than leaving the second to be re-derived from a string it has already
   * parsed (CLAUDE.md trap 21).
   *
   * DERIVED, NEVER MIRRORED: it is the very capture group this function
   * already matched, so a new currency added to `CURRENCY_SYMBOL_TO_CODE`
   * cannot make the display form and the code form disagree.
   */
  readonly currencyDisplay?: string;
  /** Multiplier from the unit's own magnitude letter: "£m" ⇒ 1e6. */
  readonly multiplier: number;
}

/**
 * The unit-string grammar: an optional currency symbol, an optional magnitude
 * key, an optional '%'. Anything else ("scale", "hires", "Trustpilot score")
 * reads as `plain` with multiplier 1 — a unit this module does not understand
 * must never inflate a magnitude.
 */
const UNIT_PATTERN = new RegExp(
  `^\\s*(?<currency>${CURRENCY_ALTERNATION})?\\s*` + magnitudeSuffixPattern("mag") + `\\s*(?<pct>%)?\\s*$`,
  "i",
);

/** The same grammar in the ISO-code form ("GBP", "USD", "GBPm"). */
const ISO_UNIT_PATTERN = new RegExp(
  `^\\s*(?<code>${ISO_CURRENCY_ALTERNATION})` + magnitudeSuffixPattern("mag") + `\\s*$`,
  "i",
);

/** Read a graph `unit` string. Unknown units degrade to plain × 1. */
export function readUnit(unit: string | null | undefined): UnitReading {
  if (typeof unit !== "string" || unit.trim().length === 0) {
    return { kind: "plain", multiplier: 1 };
  }
  const trimmed = unit.trim();
  if (/^percent(age)?$/i.test(trimmed)) return { kind: "percent", multiplier: 1 };
  const iso = ISO_UNIT_PATTERN.exec(trimmed);
  if (iso) {
    const code = (iso.groups?.code ?? trimmed).toUpperCase();
    return {
      kind: "currency",
      currencyCode: code,
      currencyDisplay: code,
      multiplier: resolveMagnitude(iso.groups?.mag),
    };
  }
  const m = UNIT_PATTERN.exec(trimmed);
  if (!m) return { kind: "plain", multiplier: 1 };
  const groups = m.groups ?? {};
  const symbol = groups.currency;
  const multiplier = resolveMagnitude(groups.mag);
  if (symbol) {
    const code =
      CURRENCY_SYMBOL_TO_CODE[symbol] ?? CURRENCY_SYMBOL_TO_CODE[symbol.toUpperCase()] ?? symbol;
    // The SYMBOL as written, not the code: "£", never "GBP". The magnitude
    // letter is deliberately excluded — it lives in `multiplier` and spending
    // it twice is B3.
    return { kind: "currency", currencyCode: code, currencyDisplay: symbol, multiplier };
  }
  if (typeof groups.pct === "string") return { kind: "percent", multiplier };
  return { kind: "plain", multiplier };
}

/**
 * C47 — A CURRENCY INSIDE A COMPOSITE UNIT. Producers store money targets and
 * prices with qualifiers: `GBP MRR`, `MRR (GBP)`, `£/month`, `GBP per month`.
 * `readUnit` reads those as `plain`, so a money figure could never match its own
 * carrier (Paul's £20k goal read as "not modelled" beside "Target 20,000 GBP MRR").
 *
 * STRICT, ONE-WAY: exactly one token must read as a currency through
 * `readUnit` (magnitude letters included, so `£k per month` is ×1000), and EVERY
 * other token must be a recognised rate/metric qualifier. Any other word leaves
 * the unit `plain` — `GBP widgets` is not money. `readUnit` itself is unchanged,
 * so its commit-time callers (the money invariant) are unaffected.
 */
const CURRENCY_UNIT_QUALIFIERS: ReadonlySet<string> = new Set([
  'mrr', 'arr', 'revenue', 'recurring', 'per', 'a', 'month', 'months', 'mo',
  'monthly', 'year', 'years', 'yr', 'annum', 'annual', 'annually', 'pa', 'pcm', '/',
]);

export function readCurrencyUnitWithQualifiers(unit: string | null | undefined): UnitReading {
  const direct = readUnit(unit);
  if (direct.kind !== "plain" || typeof unit !== "string") return direct;
  const tokens = unit
    .replace(/[()]/g, " ")
    .replace(/\//g, " / ")
    .split(/\s+/)
    .filter((t) => t.length > 0);
  if (tokens.length < 2) return direct;
  // ⭐ A PRICE PER SEAT IS MONEY (MG construction sweep, 27 Sep; served CEE e7d28fd): ONE word directly after "per" or
  // "/" is the rate's DENOMINATOR ("GBP per seat per month", "GBP per subscriber per month"), not a second thing. It
  // made the whole unit `plain`, so "What I was given" said the brief's stated £40 per-seat price was absent. Any other
  // word still leaves the unit plain ("GBP widgets"), and a second currency is still ambiguous (the loop below).
  const isDenominator = (j: number): boolean =>
    j > 0 && (tokens[j - 1] === "/" || tokens[j - 1].toLowerCase() === "per") && readUnit(tokens[j]).kind !== "currency";
  let found: UnitReading | null = null;
  for (let i = 0; i < tokens.length; i += 1) {
    const reading = readUnit(tokens[i]);
    if (reading.kind !== "currency") continue;
    const restOk = tokens.every((t, j) => j === i || CURRENCY_UNIT_QUALIFIERS.has(t.toLowerCase()) || isDenominator(j));
    if (!restOk) continue;
    if (found !== null) return direct; // two currencies: ambiguous, stay plain
    found = reading;
  }
  return found ?? direct;
}

/**
 * THE UNIT OF A TOTAL OF A PER-UNIT PRICE (price × count): the price's unit without its per-unit denominator —
 * "GBP/subscriber/month" → "GBP/month", "GBP per seat per month" → "GBP per month". The denominator is exactly the one
 * `readCurrencyUnitWithQualifiers` reads (a word after "/" or "per" that is neither a currency nor a rate qualifier);
 * a unit that is not money, or has no such word, is returned as it is. Served CEE `263dbd5` (#70 5853114059): the
 * Agent's arithmetic wrote MRR as "£9,800/subscriber/month".
 */
export function totalUnitOfPerUnitPrice(unit: string): string {
  if (readCurrencyUnitWithQualifiers(unit).kind !== "currency") return unit;
  return unit
    .replace(/\s*(?:\/|\bper\s)\s*([^\s/()]+)/gi, (whole: string, word: string) =>
      // Only a plain NOUN goes ("seat", "subscriber"). A numbered period ("per 12 months", MG B1 #2083) or a compound
      // that carries the period ("per subscriber-month") is kept as written, as are qualifiers and currencies.
      /^[a-z]+$/i.test(word) && !CURRENCY_UNIT_QUALIFIERS.has(word.toLowerCase()) && readUnit(word).kind !== "currency" ? "" : whole)
    .replace(/\(\s*\)/g, "")
    .replace(/\s{2,}/g, " ")
    .trim();
}

/**
 * Relative tolerance for the magnitude comparison. Values arrive normalised
 * and re-scaled (`0.8 × 1e6`), so binary floating point makes exact equality
 * the wrong test; 1e-9 is far tighter than any real amount collision.
 */
const RELATIVE_EPSILON = 1e-9;

function magnitudesMatch(a: number, b: number): boolean {
  if (a === b) return true;
  const scale = Math.max(Math.abs(a), Math.abs(b), 1);
  return Math.abs(a - b) <= RELATIVE_EPSILON * scale;
}

/**
 * WS-A ITEM 1 — THE MAGNITUDE A NORMALISED LEVEL DENOTES, given the producer's
 * own declared denominator.
 *
 * WHY THIS EXISTS. The pipeline reasons in NORMALISED lever space
 * (`observed_state.value ∈ [0,1]`) and records the denominator beside it
 * (`observed_state.cap`). Everything that compares a lever against the user's
 * words — this module's predicate, and the commit-time money invariant in
 * `money-invariant.ts` — needs the same inverse, so it is resolved ONCE here
 * rather than multiplied out at each call site (CLAUDE.md trap 21: two
 * derivations of one meaning end up disagreeing inside a single response).
 *
 * THE INVERSE IS NOT RE-DERIVED. `resolveExistingRawValue` is the shared
 * de-normalisation the validator, the executor precheck and the
 * `set_factor_value` handler already agree on (the AC.1 parity invariant), and
 * it is the exact inverse of `normaliseFactorValue`, which stores
 * `value = raw / cap` for every capped factor and `value = raw` when uncapped.
 * `raw_value` is deliberately NOT passed: the question is what THIS level
 * denotes, not what some earlier level denoted (the stale-sibling defect
 * `reconcileObservedValuePair` exists to repair).
 *
 * FAILS TOWARD THE WEAKER CLAIM, like everything else in this module:
 *   - no usable cap (absent, non-finite, ≤ 0 — all off-contract, since
 *     `evaluateFactorValueProposal` guarantees a positive cap on the write
 *     path) ⇒ `null`, and the caller keeps today's raw comparison;
 *   - `ambiguous` (a raw-value-less `%` whose divisor cannot be recovered)
 *     ⇒ `null`, so the strong claim is withheld rather than guessed.
 */
export function denormalisedMagnitude(
  value: number,
  unit: string | null | undefined,
  cap: number | null | undefined,
): number | null {
  if (typeof cap !== "number" || !Number.isFinite(cap) || cap <= 0) return null;
  if (typeof value !== "number" || !Number.isFinite(value)) return null;
  const resolved = resolveExistingRawValue({
    value,
    cap,
    ...(typeof unit === "string" ? { unit } : {}),
  });
  return resolved.kind === "resolved" && Number.isFinite(resolved.raw) ? resolved.raw : null;
}

/**
 * Is `value` (in `unit`) an amount the user actually stated in `briefText`?
 *
 * KIND COMPATIBILITY IS PART OF THE ANSWER, not a refinement of it:
 *   - a currency-denominated value needs a stated amount in the SAME currency;
 *   - a percent-denominated value needs a stated percentage;
 *   - a plain / unrecognised-unit value accepts plain and percent statements,
 *     because the writer's "34%" and "34 roles" are both plausibly the source
 *     of a plain 34 — but NEVER a currency statement (see below).
 *
 * ⚠ A CURRENCY-DENOMINATED STATEMENT NEVER MATCHES A UNIT WE COULD NOT READ
 * (adversarial review of #873). The symbol-form refusal was correct and the
 * ISO-code form fell through to `plain`, where "accepts any kind" silently
 * re-opened the cross-currency hole it exists to close. Recognising `GBP` (see
 * `ISO_CURRENCY_ALTERNATION`) fixes the named spelling; this rule closes the
 * CLASS, because a `€`/`£`/`$` in the brief is an explicit statement of
 * denomination and a unit we cannot read tells us nothing about whether the
 * two are the same quantity. It covers word forms ("pounds"), bare magnitudes
 * ("m"), unitless values, and every spelling nobody has thought of — one
 * derived rule instead of an enumeration that would drift.
 *
 * Returns false for a missing brief, a non-finite value, or an empty scan —
 * every "we cannot tell" answer is a refusal.
 *
 * ⚠ WS-A ITEM 1(a) — `cap` IS THE FOURTH ARGUMENT, AND ITS ABSENCE IS THE
 * DEFECT THAT SHIPPED. The one production call site passed a NORMALISED lever
 * level (0.72) while the brief states raw magnitudes (18000), so the predicate
 * was structurally incapable of firing: 117 of 117 interventions disowned,
 * measured at CEE `8e3ad916` (L2B-VARIANCE.md §2.4). Nothing about the
 * question this function answers was wrong — it was fed the wrong number.
 * Supplying the producer's own declared denominator answers the same question
 * about the magnitude the encoding actually denotes. OPTIONAL, so every
 * existing three-argument caller is byte-identical to before.
 */
export function isAmountStatedInBrief(
  value: number,
  unit: string | null | undefined,
  briefText: string | null | undefined,
  cap?: number | null,
): boolean {
  if (typeof value !== "number" || !Number.isFinite(value)) return false;
  const magnitude = denormalisedMagnitude(value, unit, cap) ?? value;
  return magnitudeAppearsInBrief(magnitude, unit, briefText);
}

/**
 * Does `magnitude` (already de-normalised, in `unit`) appear in `briefText`?
 *
 * Extracted from {@link isAmountStatedInBrief} so the kind-compatibility rules
 * documented on that function are stated ONCE and cannot drift between the
 * boolean predicate and the three-state {@link classifyAmountAgainstBrief}
 * (CLAUDE.md trap 21 / the two-`generateGraphHash` scar). Behaviour of the
 * boolean caller is unchanged: it still supplies `denormalisedMagnitude(...) ??
 * value` and still refuses a missing brief or an empty scan.
 */
function magnitudeAppearsInBrief(
  magnitude: number,
  unit: string | null | undefined,
  briefText: string | null | undefined,
): boolean {
  const amounts = findStatedAmounts(briefText);
  if (amounts.length === 0) return false;

  const reading = readUnit(unit);
  const target = magnitude * reading.multiplier;
  if (!Number.isFinite(target)) return false;

  for (const amount of amounts) {
    if (reading.kind === "currency") {
      if (amount.kind !== "currency") continue;
      if (amount.currencyCode !== reading.currencyCode) continue;
    } else if (reading.kind === "percent") {
      if (amount.kind !== "percent") continue;
    } else if (amount.kind === "currency") {
      // Unread unit vs an explicitly denominated amount — see the note above.
      continue;
    }
    if (magnitudesMatch(amount.magnitude, target)) return true;
  }
  return false;
}

/**
 * THE DENOMINATOR THAT TURNS A STORED LEVER LEVEL INTO THE MAGNITUDE IT DENOTES.
 *
 * The pipeline reasons in lever space and records the denominator beside the
 * level in one of THREE mutually-exclusive conventions — and the honest answer
 * to "what magnitude is this?" depends on which one the factor is in:
 *
 *   · `cap`      — the denominator is persisted (`observed_state.cap`).
 *                  magnitude = `resolveExistingRawValue` (the shared inverse).
 *   · `frame`    — a capless FRAMED pair, written by the records projector as
 *                  `{value: raw/frame, raw_value: raw}` with the frame
 *                  deliberately NOT persisted (projector.ts:1667). The frame is
 *                  recovered from the pair by the estate's single authority,
 *                  {@link recoverScaleFrame} — consumed, never re-derived.
 *   · `identity` — an UNFRAMED pair `{x, x}` (projector.ts:986: counts, ratios,
 *                  unbounded scales). Lever space IS magnitude space, so the
 *                  level is already the magnitude and today's raw comparison is
 *                  correct. THIS IS NOT AN UNKNOWN: the pair positively proves
 *                  the factor is unframed.
 *   · `unknown`  — no cap, and the pair settles nothing: a ZERO baseline
 *                  (`{0, 0}` — `recoverScaleFrame` refuses zero pairs BY
 *                  DESIGN, scale-frame.ts:47, and that refusal is correct;
 *                  frame persistence is a separately-owned question), a missing
 *                  `raw_value`, or no `observed_state` at all. A level of 0.8
 *                  here may denote 0.8 or 80 and NOTHING IN THE RECORD SAYS
 *                  WHICH.
 *
 * ⚠ THE `identity` CASE IS WHY THIS IS A FOUR-WAY ANSWER AND NOT
 * "frame recovered / not recovered". `recoverScaleFrame` returns undefined for
 * BOTH `{40, 40}` and `{0, 0}`, but only the second is undecidable. Collapsing
 * them would withdraw the honest "not stated in the brief" disowning from every
 * plain count in the estate — the opposite-direction harm, and the larger class.
 */
export type MagnitudeScale =
  | { readonly kind: "cap"; readonly cap: number }
  | { readonly kind: "frame"; readonly frame: number }
  | { readonly kind: "identity" }
  | { readonly kind: "unknown" };

/**
 * Which of the four conventions is this factor's `observed_state` in?
 *
 * Precedence is the WRITE path's own precedence (`normaliseFactorValue`): a
 * usable cap wins, else the framed pair, else a positive identity pair. Total
 * and pure; every "we cannot tell" answer is `unknown`, never a guess.
 */
export function resolveMagnitudeScale(
  observed:
    | {
        readonly value?: unknown;
        readonly raw_value?: unknown;
        readonly cap?: unknown;
      }
    | null
    | undefined,
): MagnitudeScale {
  const cap = observed?.cap;
  if (typeof cap === "number" && Number.isFinite(cap) && cap > 0) {
    return { kind: "cap", cap };
  }

  const frame = recoverScaleFrame({
    value: observed?.value,
    raw_value: observed?.raw_value,
  });
  if (frame !== undefined) return { kind: "frame", frame };

  const value = observed?.value;
  const raw = observed?.raw_value;
  if (
    typeof value === "number" &&
    Number.isFinite(value) &&
    value > 0 &&
    typeof raw === "number" &&
    raw === value
  ) {
    return { kind: "identity" };
  }

  return { kind: "unknown" };
}

/**
 * The magnitude `level` denotes under `scale`, or `null` when undecidable.
 *
 * `null` means exactly one thing: THE RECORD DOES NOT DETERMINE THE ANSWER.
 * It is never a computation failure dressed as an unknown.
 */
export function magnitudeUnderScale(
  level: number,
  unit: string | null | undefined,
  scale: MagnitudeScale,
): number | null {
  if (typeof level !== "number" || !Number.isFinite(level)) return null;
  switch (scale.kind) {
    case "cap":
      return denormalisedMagnitude(level, unit, scale.cap);
    case "frame": {
      const magnitude = level * scale.frame;
      return Number.isFinite(magnitude) ? magnitude : null;
    }
    case "identity":
      return level;
    case "unknown":
      return null;
  }
}

/**
 * Three-state provenance verdict: did the user state THIS amount in the brief?
 *
 * ⚠ THE SPEC THIS IS WRITTEN AGAINST (not the failure mode that motivated it):
 * **a provenance claim in the reasoning string must be TRUE of the brief text.**
 * There are two ways to break that, and they are not symmetric:
 *   - claiming "stated" for a value the user never wrote — a fabrication;
 *   - claiming "this amount is not stated in the brief" about a number the user
 *     typed themselves — a FALSE CLAIM ABOUT THE USER'S OWN WORDS, which is the
 *     one the product shipped (PR #873: stated 80 compared as the level 0.8).
 * A two-state boolean cannot express the third, honest answer, so it was forced
 * to pick one of the two lies. Hence `undecidable`.
 *
 * ASYMMETRY OF EVIDENCE, and it is the load-bearing rule here:
 *   · a MATCH is decisive whatever the denominator — if the number appears in
 *     the text, the user wrote it;
 *   · a NON-MATCH is decisive ONLY when the denominator was known. Under
 *     `unknown` we compared a level against magnitudes and learned nothing.
 * So a non-match under an unknown scale returns `undecidable`, NOT `not_stated`.
 */
export type BriefAmountVerdict = "stated" | "not_stated" | "undecidable";

export function classifyAmountAgainstBrief(
  level: number,
  unit: string | null | undefined,
  briefText: string | null | undefined,
  scale: MagnitudeScale,
): BriefAmountVerdict {
  if (typeof level !== "number" || !Number.isFinite(level)) return "undecidable";

  const magnitude = magnitudeUnderScale(level, unit, scale);
  if (magnitudeAppearsInBrief(magnitude ?? level, unit, briefText)) return "stated";

  return magnitude === null ? "undecidable" : "not_stated";
}
