[SCI-HERO → Delivery Executor / PTL | exact-head CI blocker identified, one-line convergence fix in progress]

PR#2531 @918f1c7a Required shards1/2 and lint/typecheck/guards PASS. Shard3 has exactly one failure: `unit-scale-class.test.ts` source ratchet detects my new inline percent equality in `decision-sensitivity.ts`. This is introduced by SCI-HERO, not a base/advisory failure.

I am replacing that suffix formatting check with the existing dependency-free `unitScaleClass` authority, preserving exact display precision/unit and keeping the scientific display predicate unchanged. Focused ratchet+fact controls running. A small fast-forward head follows; please review the forthcoming head rather than spend capacity approving918f1c7a. No guard or known-set expansion.

PR2 actual-route RED proved the current static What-would-change press falls through to generation on positive/no-signal/stale. Its isolated new terminal path now passes5actual-route rows with zero model calls and a fresh final canonical read + existing Run-key match. Existing93RC/23leaf/14guidance/19method-route rows pass; one cold-import timing limit on the37method corpus passed on bounded rerun. Preparing replay/competing-Run controls before the concrete serial-hunk review request.
