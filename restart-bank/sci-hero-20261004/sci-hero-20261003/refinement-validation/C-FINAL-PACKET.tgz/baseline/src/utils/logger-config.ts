/**
 * Centralized Logger Configuration
 *
 * Single source of truth for Pino logger redaction paths.
 * Used by both server.ts (Fastify) and telemetry.ts (standalone Pino).
 *
 * SECURITY: All sensitive fields must be listed here to prevent
 * accidental exposure in logs. Update this file when adding new
 * secret headers, PII fields, or decision-content field names.
 *
 * TWO REDACTION CLASSES, one boundary (14-Jul PII ruling, CEE half —
 * mirrors the mechanism Paul ratified in PLoT #224 `e0293fe5`):
 *
 *  1. CREDENTIALS / GENERIC PII (`BASE_REDACT_PATHS`): blanked to
 *     "[REDACTED]". Unchanged behaviour — these predate this file's
 *     decision-content layer.
 *  2. DECISION CONTENT (`DECISION_CONTENT_FIELDS`): node labels, goal
 *     text, user messages, assistant prose. Replaced with a SALTED
 *     per-process digest ("sha8:xxxxxxxx") rather than blanked, so
 *     "are these two log lines about the same node?" stays answerable
 *     while the raw value never reaches the log (PLoT #224
 *     pii-redact.ts rationale, mirrored).
 *
 * WHY THE LOGGER BOUNDARY: point defenses at individual call sites
 * (routing-log sink, validator-details stripping, share-redaction)
 * each protect one seam and stay in place. This layer makes a log
 * site safe WITHOUT its author doing anything — the lesson PLoT
 * learned across three rounds of per-call-site edits that each found
 * more leaking sites.
 *
 * MECHANISM: pino `redact` paths (fast-redact), deliberately
 * path-based rather than deep-scanning — redaction runs on every log
 * line, and a content-scrubbing walk would tax every emission. The
 * trade: a protected FIELD NAME is covered at nesting depths 0–2
 * (`f`, `*.f`, `*.*.f` — each fast-redact `*` matches exactly one
 * level, verified against pino 9); a decision value interpolated into
 * message TEXT or nested ≥3 deep is NOT covered by this layer. That
 * residual is accepted and documented — the deep-scan alternative was
 * ruled out on per-line cost.
 */

import { createHmac, randomBytes } from "node:crypto";

/**
 * Credential / generic-PII field names — the pre-existing redaction
 * class, blanked to REDACT_CENSOR. Do not fold decision-content names
 * in here; they belong in DECISION_CONTENT_FIELDS so they get digests
 * (correlation-preserving) instead of blanks.
 *
 * ⚠ The old hand-listed paths claimed "at any depth" — FALSE under
 * pino path semantics (verified by executed probe, 19-Jul review):
 * each fast-redact `*` matches exactly ONE level, so `*.email`
 * redacted `{ctx: {email}}` while logging a TOP-LEVEL `email`
 * VERBATIM. Paths are now GENERATED at depths 0–2 from these name
 * lists, closing the top-level gap.
 */
export const CREDENTIAL_FIELDS = [
  // Auth secrets
  "password",
  "secret",
  "token",
  "apiKey",
  "api_key",
  "apikey",
  "authorization",
  "credentials",
  "accessToken",
  "access_token",
  "refreshToken",
  "refresh_token",
  "privateKey",
  "private_key",
  // Generic PII
  "email",
  "phone",
  "ssn",
  "creditCard",
  "credit_card",
] as const;

/**
 * Authentication header names redacted under any `headers` object
 * (the Fastify req serializer shape). Includes the HMAC auth headers
 * (timing attack vectors if exposed).
 */
export const CREDENTIAL_HEADER_NAMES = [
  "authorization",
  "x-api-key",
  "x-olumi-assist-key",
  "x-admin-key",
  "x-hmac-signature",
  "x-share-token",
  "cookie",
  "x-olumi-signature",
  "x-olumi-nonce",
  "x-olumi-timestamp",
] as const;

/**
 * Credential-class redact paths — DERIVED at depths 0–2 (`headers.*`
 * entries: the headers object itself at depths 0–2).
 */
export const BASE_REDACT_PATHS: readonly string[] = [
  ...CREDENTIAL_FIELDS.flatMap((f) => [f, `*.${f}`, `*.*.${f}`]),
  ...CREDENTIAL_HEADER_NAMES.flatMap((h) => [
    `headers.${h}`,
    `*.headers.${h}`,
    `*.*.headers.${h}`,
  ]),
];

/**
 * DECISION-CONTENT FIELD POLICY — the single list every consumer
 * derives from. pino redact paths are GENERATED from it
 * (decisionContentRedactPaths); the routing-log field policy
 * cross-checks against it in tests; the sentinel suite iterates it so
 * a listed field that stops redacting turns a test red.
 *
 * Membership rule: a field name goes here when its VALUE is, by
 * construction, user decision content — labels, goal text, user
 * messages, assistant/model prose, brief text. Service vocabulary
 * (event names, enum codes, error codes) stays out. Ambiguity
 * resolves toward scrubbing (PLoT #224 fail-safe direction): `label`
 * is included even though a minority of sites log service-authored
 * labels — the digest still correlates, and under-scrubbing costs
 * privacy while over-scrubbing costs only debuggability.
 *
 * KNOWN RESIDUAL (same class PLoT documents on DECISION_DOMAIN_KEYS):
 * this is a name list, so a decision value logged under a NAME nobody
 * listed passes through. The guarantee for listed names is mechanical
 * (boundary + derived paths + sentinel tests); the list itself still
 * needs an author to extend it when a new content-bearing field name
 * enters the codebase.
 */
export const DECISION_CONTENT_FIELDS = [
  // The four proven pass-through fields (14-Jul ruling, verified with a
  // positive control 18-Jul):
  "raw_user_message",
  "assistant_text",
  "node_label",
  "goal_text",
  // User-message twins in live vocabulary
  "user_message",
  "userMessage",
  "user_text",
  "message_text",
  // Assistant / model prose twins
  "assistantText",
  "answer_text",
  "answerText",
  "sonnet_text",
  "orientation_text",
  "orientationText",
  // Label family — node/option/factor/goal/target/entity labels and
  // plurals. `option_label` is a verified live leak site
  // (context-pack-assembler isProbabilityValid warn); entity_label /
  // proposed_label / resolved_label are the validator-details names
  // the e4529faf point defense strips before logging (belt-and-braces
  // here for any NEW site that logs them raw).
  "label",
  "labels",
  "node_labels",
  "option_label",
  "option_labels",
  "factor_label",
  "factor_labels",
  "goal_label",
  "target_label",
  "entity_label",
  "proposed_label",
  "resolved_label",
  // Brief / free-text decision framing
  "brief",
  "brief_text",
  "briefText",
  "decision_text",
  "summary_text",
  "coaching_text",
  "headline",
  // Assembled AI prompt text (turn-debug prompt capture, #1435). The
  // captured SYSTEM half is Olumi-authored only because ONE call site
  // resolves it with no variables — that is a property of the call
  // site, not of the field NAME. A second capture seam resolving WITH
  // variables would put interpolated user text under this same name,
  // so it joins the list now (fail-safe direction). Only the bytes
  // field is listed: `system_prompt_sha256` and `system_prompt_chars`
  // are shape-only, non-reversible, and are what lets a leak be
  // correlated and DETECTED — redacting them would remove the
  // detection surface and add no privacy.
  "system_prompt",
  // camelCase twin, on the same convention as `userMessage`,
  // `assistantText`, `answerText` and `orientationText` above. This is
  // not merely a parameter name: `turn-debug-store.ts` declares
  // `readonly systemPrompt: string` (PromptCaptureInput) and the
  // draft_graph seam builds an object literal with that key carrying
  // the served bytes (`cee/unified-pipeline/stages/parse.ts:268`), so a
  // spread of that object into `log.*` would put the prompt on the wire
  // under this name. PROSPECTIVE, not a live leak — swept at f9ee43a9
  // with a contrast control and no site logs it today; turn-debug-store
  // states the rule only as a COMMENT (:491), i.e. a hand-maintained
  // mirror, and listing it here makes it mechanical. Same shape-twin
  // ruling as above: `systemPromptSha256` / `systemPromptChars` stay OFF.
  "systemPrompt",
  // A user's STATED REASON for disagreeing with a finding (#1445's
  // `finding_dissent` system event). Paul's ruling of 2026-09-11
  // deliberately widened standing privacy rule R-004 so this free text
  // is PERSISTED verbatim — `dispatch.ts` passes it through untouched,
  // "the words are the record". The half of R-004 that STANDS is that
  // the text may contain PII and must never be re-emitted into telemetry
  // or logs, which is exactly this boundary's job.
  //
  // PROSPECTIVE, not a live leak — same footing as `systemPrompt` above.
  // Swept at 46a27ae6 with a contrast control: no log call site in `src/`
  // names `statement` today (contrast: 27 log sites name `label`), and
  // #1445's reviewer measured the one real re-emission surface
  // (`log.error({ parse_error: check.error.message })`, dispatch.ts
  // ~:757-765) across seven failure modes with a firing positive control
  // and saw no leak. ⚠ Note the honest limit: that field is named
  // `parse_error`, so listing `statement` does NOT close that surface —
  // this boundary keys on the field NAME. What it closes is the innocent
  // future `log.*({ ...fact.result })` or `log.debug({ statement })`.
  //
  // NO SHAPE TWINS TO EXCLUDE, unlike `system_prompt`: 0.55.0's
  // FindingDissentResultSchema is {finding_id, analysis_id, statement,
  // provenance} and there is no `statement_sha256`/`statement_chars`
  // anywhere in the tree (measured zero, contrast control firing). The
  // address pair (analysis_id, finding_id) stays OFF this list on the
  // same reasoning the shape twins do — it carries no user bytes and is
  // what lets a dissent be traced and a leak correlated.
  //
  // SECOND POPULATION, and it is content too, so this is reinforcing
  // rather than over-scrubbing: decision-records' `prediction.statement`
  // (`store-adapter.ts:120`) is set either from `fact.result.summary`
  // (`capture.ts:246` — analysis prose naming the leading option, which
  // `turn-executor.ts:2863` already gates as withheld content) or from
  // "the user's own stated expectation" (`user-commit.ts:28`). Neither
  // half is service vocabulary, an enum or a diagnostic code, so the
  // digest blinds no diagnostic.
  "statement",
] as const;

export type DecisionContentField = (typeof DECISION_CONTENT_FIELDS)[number];

const DECISION_CONTENT_FIELD_SET: ReadonlySet<string> = new Set(
  DECISION_CONTENT_FIELDS,
);

/** Is this key name in the decision-content redaction class? */
export function isDecisionContentField(field: string): boolean {
  return DECISION_CONTENT_FIELD_SET.has(field);
}

/**
 * Generate the pino redact paths for a set of protected field names.
 * Depths 0–2: `f` (top level — the shape `emit()` produces when it
 * spreads eventData), `*.f` (one level down), `*.*.f` (two levels
 * down). Each fast-redact `*` matches exactly ONE level; there is no
 * deep-glob, which is the accepted residual documented above.
 */
export function decisionContentRedactPaths(
  fields: readonly string[],
): string[] {
  return fields.flatMap((f) => [f, `*.${f}`, `*.*.${f}`]);
}

/**
 * MEASUREMENT CONTAINERS — object keys whose CHILD VALUES are, by
 * construction, measurements OF content rather than content.
 *
 * WHY THIS EXISTS. The censor keys on the terminal field NAME, and
 * `v5.context_budget` keys its decomposition BY SECTION NAME. A section
 * is named `brief`, so `section_chars.brief` — a character COUNT —
 * was digested exactly like `brief`, the brief TEXT. The one section
 * the draft call records reached staging as
 * `section_chars: {"brief": "sha8:d8531659"}`: a redaction of a LENGTH,
 * on the single event that says what we send our own models.
 *
 * This is the ruling this file ALREADY makes one paragraph up, for
 * `system_prompt_chars` / `system_prompt_sha256`: shape-only,
 * non-reversible, and the very thing that lets a leak be correlated and
 * DETECTED, so "redacting them would remove the detection surface and add
 * no privacy". `section_chars` cannot express that rule by NAMING its keys
 * differently — its keys ARE the CONTEXT_POLICY section names, and a
 * conformance gate asserts they match.
 *
 * ⚠ MECHANISM, and it is NOT obvious — settled by an executed probe, not
 * by reading: fast-redact hands the censor a `null` for every WILDCARD
 * segment, so under `*.brief` the path is `[null, "brief"]` and the
 * container name is NOT knowable. The exemption therefore needs EXPLICIT
 * (wildcard-free) paths, which report `["section_chars", "brief"]` with
 * the real name. The generated explicit path and the pre-existing
 * wildcard BOTH fire on the same location — verified — and both carry the
 * real container name, so the pass-through is stable under either.
 *
 * FAIL-SAFE, never a name bypass: membership exempts a value ONLY when the
 * value IS a measurement — a finite number, or a flat object of finite
 * numbers (the per-section content manifest, e.g. `{nodes, edges}`). A
 * STRING under `section_chars.brief` is not a measurement and is digested
 * exactly as before, so a call site that starts passing text under a
 * measurement key leaks nothing. Proven by a positive control in the
 * sentinel suite.
 */
export const MEASUREMENT_CONTAINER_FIELDS = [
  /** `v5.context_budget` per-section CHARACTER COUNTS. */
  "section_chars",
  /**
   * `v5.context_budget` per-section CONTENT MANIFEST — structural counts
   * (`{nodes, edges, constraints}`). A char count cannot distinguish
   * `<GRAPH>{}</GRAPH>` from a real graph of the same size; a field count
   * can, which is the whole reason this event is read.
   */
  "section_shape",
] as const;

const MEASUREMENT_CONTAINER_SET: ReadonlySet<string> = new Set(
  MEASUREMENT_CONTAINER_FIELDS,
);

/**
 * Is this value a MEASUREMENT (safe to pass through under a measurement
 * container)? A finite number, or a flat object whose every value is a
 * finite number. Everything else — strings, arrays, nested objects,
 * NaN/Infinity — is NOT, and falls through to the digest.
 */
export function isMeasurementValue(value: unknown): boolean {
  if (typeof value === "number") return Number.isFinite(value);
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    return false;
  }
  return Object.values(value as Record<string, unknown>).every(
    (v) => typeof v === "number" && Number.isFinite(v),
  );
}

/**
 * EXPLICIT (wildcard-free) redact paths for every
 * `<measurement container>.<decision-content field>` collision, at depths
 * 0-1 for the container. DERIVED from both lists — a new measurement
 * container, or a new decision-content field name, is covered without
 * anyone remembering to extend a third list.
 *
 * These paths do not change WHAT is redacted (the wildcard `*.f` already
 * matched every one of these locations). They exist solely so the censor
 * can SEE the container name and apply {@link isMeasurementValue}.
 */
export function measurementContainerRedactPaths(
  containers: readonly string[],
  fields: readonly string[],
): string[] {
  return containers.flatMap((c) => fields.flatMap((f) => [`${c}.${f}`, `*.${c}.${f}`]));
}

/**
 * Paths to redact from all log output — DERIVED, not hand-listed:
 * credential paths + generated decision-content paths.
 */
export const REDACT_PATHS = [
  ...BASE_REDACT_PATHS,
  ...decisionContentRedactPaths(DECISION_CONTENT_FIELDS),
  // Additive: same locations the wildcards already cover, named explicitly so
  // the censor can identify the measurement container (see
  // MEASUREMENT_CONTAINER_FIELDS — fast-redact nulls wildcard segments).
  ...measurementContainerRedactPaths(
    MEASUREMENT_CONTAINER_FIELDS,
    DECISION_CONTENT_FIELDS,
  ),
] as const;

/**
 * Redaction censor string (credential / generic-PII class).
 */
export const REDACT_CENSOR = "[REDACTED]";

/**
 * Per-process random salt for decision-content digests — minted once
 * at module load, DELIBERATELY not configurable (PLoT #224
 * DIGEST_SALT rationale, mirrored): an unsalted truncated hash over a
 * decision value is reversible offline (tiny input space), and a
 * configured salt would be a long-lived shared secret that leaks.
 * The trade-off: equal inputs digest equally WITHIN one process
 * (correlation survives), but NOT across restarts or replicas — do
 * not join digests across processes or treat them as stable ids.
 */
const DIGEST_SALT = randomBytes(32);

/**
 * Salted digest of a scalar → "sha8:xxxxxxxx". THE digest primitive
 * for decision content bound for logs. Mirrors PLoT #224's sha8.
 */
export function sha8(value: string | number): string {
  return (
    "sha8:" +
    createHmac("sha256", DIGEST_SALT)
      .update(String(value), "utf8")
      .digest("hex")
      .slice(0, 8)
  );
}

/** Digest one leaf under a decision-content key, preserving structure. */
function digestLeaf(value: unknown): unknown {
  // null / undefined / booleans are structural, never identifying —
  // preserve them so "label was null" stays diagnosable.
  if (value === null || value === undefined || typeof value === "boolean") {
    return value;
  }
  if (typeof value === "string" || typeof value === "number") {
    return sha8(value);
  }
  // Objects under a content key: blank rather than walk (path-based
  // discipline — no deep scanning at the boundary).
  return REDACT_CENSOR;
}

/**
 * pino redact censor. Branches on the redacted path's terminal
 * segment: decision-content fields get correlation-preserving digests
 * (arrays element-wise, length preserved); every other redacted path
 * (the credential class) keeps its historical "[REDACTED]" blank —
 * byte-identical to the pre-decision-content behaviour.
 */
export function redactCensor(
  value: unknown,
  path: ReadonlyArray<string | number>,
): unknown {
  const terminal = String(path[path.length - 1] ?? "");
  // A value sitting DIRECTLY under a measurement container is a measurement
  // of content, never content — but only if it actually IS one (see
  // MEASUREMENT_CONTAINER_FIELDS: the guard is on the VALUE, so this can
  // never become a name-based content bypass).
  const container = String(path[path.length - 2] ?? "");
  if (MEASUREMENT_CONTAINER_SET.has(container) && isMeasurementValue(value)) {
    return value;
  }
  if (DECISION_CONTENT_FIELD_SET.has(terminal)) {
    if (Array.isArray(value)) {
      return value.map(digestLeaf);
    }
    return digestLeaf(value);
  }
  return REDACT_CENSOR;
}

/**
 * Create a Pino-compatible redact configuration
 */
export function createRedactConfig() {
  return {
    paths: [...REDACT_PATHS],
    censor: redactCensor,
  };
}

/**
 * Write the level as its LABEL ("error"), not pino's number (50). Render's log explorer reads a JSON line's `level`
 * as a label only, so a numeric 50 was shown as `info` and an error search missed every leak event
 * (`agent_lane.leader_claim_residual_removed`, DL 380e54 programme-docs#85 5932495794 item 3). No CEE code or
 * script reads the numeric level back.
 */
export const LEVEL_AS_LABEL = {
  level: (label: string) => ({ level: label }),
};

/**
 * Create full Pino logger options
 */
export function createLoggerConfig(level: string) {
  return {
    level,
    redact: createRedactConfig(),
    formatters: LEVEL_AS_LABEL,
  };
}
