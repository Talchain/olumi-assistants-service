# Runtime/Context — residual census at served CEE 3ddcea18

READ_ONLY complete. All four named merged PRs are verified ancestors of this immutable head; 24 fetched Git blobs were verified against Git object SHA and SHA256. No source edits, execution, tests, gates, installs, provider/browser journeys, PR closures or new watcher. This is source evidence, not served user acceptance. The old ef65-based census is superseded for the current base.

## Finding and smallest valuable slice

One surviving gap is proven by the source mapping: **the canonical selected Run's licensed `current_read.run_delta` is omitted from ordinary/follow-up Agent model context**. Explain already consumes it. This prevents the ordinary Agent from grounding a question about the consequence of a prior approved change in the same recorded comparison, particularly when chat/Run tool history is absent or reduced to markers. It does not prove the model necessarily gives a wrong answer.

The first wrong boundary is **authoritative read → Agent `GraphRead` contract/projection**, not storage, Run computation, or currentness. The chain is:

1. [Canonical reader](https://github.com/Talchain/olumi-assistants-service/blob/3ddcea18fe54ec14fa9085171f1e4b3c08d53baa/src/routes/scenario-graph-analysis-read.ts#L491): selects the recorded pair, builds the existing delta, applies existing final-egress permission to result and delta, and hands it to `projectCurrentRead` (491–544).
2. [Current-read contract](https://github.com/Talchain/olumi-assistants-service/blob/3ddcea18fe54ec14fa9085171f1e4b3c08d53baa/src/routes/current-read-projection.ts#L30): emits `run_delta` only for selected `complete_current` with a result; absent means no recorded delta, never “nothing changed” (30–61). [Graph route](https://github.com/Talchain/olumi-assistants-service/blob/3ddcea18fe54ec14fa9085171f1e4b3c08d53baa/src/routes/assist.v1.scenario-graph.ts#L774) exposes that carrier.
3. [First omission](https://github.com/Talchain/olumi-assistants-service/blob/3ddcea18fe54ec14fa9085171f1e4b3c08d53baa/src/orchestrator-v5/agent-lane/runtime/agent-capabilities.ts#L1861): `readGraph` reads only `current_read.analysis_ready`, with no delta carrier in `GraphRead` or its returned object (887–973,1861–1906). `withSavedRunCertainty` (1457–1520) and `savedRunContextFacts` (19–46) cannot restore a field they never received. `analysis_state` itself has no `run_delta` member.
4. [Actual consumer](https://github.com/Talchain/olumi-assistants-service/blob/3ddcea18fe54ec14fa9085171f1e4b3c08d53baa/src/routes/agent-v1-turn.ts#L2616): issues the canonical packet from `getCanonicalState`; [Agent loop](https://github.com/Talchain/olumi-assistants-service/blob/3ddcea18fe54ec14fa9085171f1e4b3c08d53baa/src/orchestrator-v5/agent-lane/runtime/agent-loop.ts#L317) serialises exactly that state into the model input (317–327). Fallback `get_canonical_state` returns the same lossy projection (2861–2898).
5. [Existing working sibling](https://github.com/Talchain/olumi-assistants-service/blob/3ddcea18fe54ec14fa9085171f1e4b3c08d53baa/src/routes/agent-v1-turn.ts#L2286): Explain reads the same cached `current_read.run_delta`, passes it in `canonical_state`, and feeds the existing rerun explanation plan (2286–2337). [History](https://github.com/Talchain/olumi-assistants-service/blob/3ddcea18fe54ec14fa9085171f1e4b3c08d53baa/src/orchestrator-v5/agent-lane/history-store.ts#L169) deliberately retains old Run output only as a neutral marker (169–191); it is not an alternative facts authority.

**Owner/files:** DL retains the B3 writer slot in `runtime/agent-capabilities.ts` until that closure is complete. Existing Runtime/Context is the context owner; after a DL-approved bounded lease, the minimal slice is the `GraphRead`/`readGraph` carrier plus the existing saved-context projection in `runtime/agent-capabilities.ts` and, if sharing the projection with Explain is useful, `agent-lane/saved-run-context-facts.ts`. The canonical producer/permission machinery remains unchanged. No implementation lease is claimed by this receipt.

**Implementation direction:** pass the canonical reader's already-licensed typed delta from the same selected read into ordinary context. Preserve absence, currentness, selected Run identity and permission semantics. Do not recompute a delta, infer changes from chat, manufacture “no change”, import a historical pair or create another permission/freshness authority. Do not mix CAS and analysis hash domains.

**Required discriminators for the eventual owner, not executed here:** actual ordinary model-input/`get_canonical_state` equality with the selected licensed reader delta; transcript-free input; first Run/no pair omits the field; stale/degraded/newer Run cannot borrow a prior delta; withheld permission cannot regain leader identities; same graph/new Run preserves its selected comparison identity. Preserve descriptions, provenance, authorship/review, edge uncertainty, constraints and goal-free context byte-for-byte alongside the new carrier. Reuse the existing Explain, saved-context and packet-binding route specs rather than add a second harness.

## Superseded hunks and covered areas

All six original #2529 hunks are **SUPERSEDED semantically** by merged #2538/#2533; no wholesale merge is justified. This does not claim literal patch equality.

| Old #2529 hunk/area | Current evidence at 3ddcea18 | Disposition |
|---|---|---|
| Route import for `withNonlinearIdentity` | `agent-v1-turn.ts:64`, use2307–2308 | SUPERSEDED |
| Route direct limit/goal helper imports | Shared `saved-run-context-facts.ts:2–6`, route66 and2309–2319 | SUPERSEDED by shared projection |
| Explain selected Run guard payload | route2305–2319: same requested permission, nonlinear cause, saved facts, goal chance/certainty | SUPERSEDED |
| Capabilities hoist existing permission computation | capabilities1473–1475 | SUPERSEDED |
| Ordinary `analysis.claim_permissions` member | capabilities1513–1519 | SUPERSEDED |
| New Explain/one-spelling route spec | Same file exists, assertions138–260 include old D3/D6 controls and new ordinary/cold constraint rows216–247 | SUPERSEDED/expanded; not run by census |

Selected Run reference/tipping facts, per-limit verdicts, constraint state, risk polarity, missing/null/[] distinctions and option participation are now carried by the existing selected facts/option projection (`saved-run-context-facts.ts:19–46`; capabilities1499–1519,1898–1905). #2527 participation, #2528 delivered history, #2533 permission authority and #2538 guards are not rebuild targets. Route3453–3460 writes final SENT text to history; durable seed uses existing `store.readRecent`/`historyFromDurableTurns` at2157–2164. Defined cold JSON/context fixtures are source evidence only, not persistent-reader or browser proof.

Qualitative fidelity is not reduced to extraction: the existing entity projection retains description as `full_label`, entity provenance, distinct value provenance and user review (capabilities1186–1237); edges retain provenance/direction/strength/spread/existence uncertainty (1321–1350); goals are omitted when none exist, rather than invented (1353–1359); every persisted entity kind is mapped, and unmodelled context stays explicit (2875–2892). No global completeness claim is made for every possible evidence/dissent carrier without its producer contract and journey proof. The proposed slice must preserve these carriers and the user's qualitative reasoning, not replace them with numerical summaries.

## Disposition

Bank #2529 for DL-managed superseded closure; no old branch merge or PR mutation performed. Queue only this small ordinary selected-Run delta carrier after DL's B3 slot, subject to accepted lease and current gates/review. SharedData/permission producer stays the authority. L1 remains served/frozen; L2 still waits for the same actual Harness turn. Stop this census here.
