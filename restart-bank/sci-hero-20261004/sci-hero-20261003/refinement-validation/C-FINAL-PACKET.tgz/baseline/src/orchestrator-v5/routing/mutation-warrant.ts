/**
 * ⭐⭐ MUTATION WARRANT — the predicate behind INV-1, the action-layer
 * guarantee "nothing is written to the user's model unless the user asked
 * for a change".
 *
 * WITNESSED (staging CEE `8687a31`, 6 Aug 2026, walk 2.634 §J7 —
 * `PHASE0-EVIDENCE-2026-07-28/walk-2634-findings-2026-08-07.md`): the user
 * typed a pure READ request,
 *
 *   "Open the analysis panel and show me the option comparison"
 *
 * and the assistant EDITED the model — "Added constraint: churn could rise
 * ceiling must be at most 3%.", marked "Applied", with NO confirm chip.
 *
 * ── WHY THE EXISTING CONSENT MACHINERY DID NOT CATCH IT ───────────────────
 * `mutation-consent.ts` detects WITHHELD consent — the user saying *do not
 * apply this yet*. On a read request the user says no such thing, so it
 * correctly stands down. Traced at `8687a311`, constraint writes were inside
 * NO consent regime at all:
 *   · Sonnet tool-use routing (`tool_choice:"auto"`) may emit an execute-class
 *     `add_constraint` on any utterance;
 *   · the D1 lifecycle validates then executes immediately — there is no hold;
 *   · the Graph-Management referee's op vocabulary structurally cannot hold
 *     `add_constraint`.
 * No guard anywhere asked the AFFIRMATIVE question: *did the user request a
 * change at all?* This module is that question.
 *
 * ── WHAT THIS MODULE IS AND IS NOT ────────────────────────────────────────
 * A PURE PREDICATE over the turn's own INGRESS — the user's message, the
 * chip they clicked, and whether the turn is resuming a proposal they already
 * confirmed. It has no opinion about routing, handlers or graphs. Its output
 * is consumed by the turn-executor at the ACTION layer, which is where the
 * guarantee lives: a warrantless mutating proposal is DEMOTED to the
 * propose-confirm channel (chip + pending) rather than executed, and the
 * graph commit chokepoint strips a handler mutation from such a turn as a
 * second, list-free backstop. **Response wording enforces nothing.**
 *
 * Deliberately evaluable BEFORE any model call, for the same reason
 * `detectWithheldConsent` is: the guarantee cannot depend on what the model
 * decides, because on the witnessed turn the model decided to mutate.
 *
 * ── FAIL-SAFE DIRECTION (⚠ INVERTED RELATIVE TO WITHHELD CONSENT) ─────────
 * Read this before adding a pattern. For `detectWithheldConsent` a false
 * POSITIVE is cheap, so its judgement calls resolve toward withholding. Here
 * the polarity flips:
 *
 *   false NEGATIVE (no warrant found, user did want the change)
 *       → the change is OFFERED as a chip. Costs one click.
 *   false POSITIVE (warrant found, user did not ask for a change)
 *       → the model is silently rewritten. This is the witnessed defect.
 *
 * So every judgement call below resolves toward NOT granting, and every
 * pattern demands BOTH a deontic frame ("keep", "must", "limit", "can't
 * exceed") AND a number. A merely DESCRIPTIVE sentence about a bound —
 * "there's about a 70% chance churn stays below 3%" — is a forecast, not an
 * instruction, and must not grant. That exact utterance is in the negative
 * corpus.
 *
 * ── WHY THERE IS A HAND-WRITTEN CORPUS (CLAUDE.md trap 12d) ───────────────
 * `MUTATION_SIGNAL_PATTERNS` in `analytical-intent.ts` is the canonical
 * mutation-shape list, and it was SHORT: it recognises "set X to N" and "add
 * a Y" but no constraint phrasing at all, so "Keep churn below 3%." carried
 * no signal. A guard derived from that list would have agreed with it
 * perfectly and still missed every constraint the product can write. The
 * corpus in `__tests__/mutation-warrant.test.ts` is hand-written, carries
 * both directions, and is what notices the list is short. The UNION
 * assertion there is the derived half: everything the canonical list
 * recognises must also grant a warrant, so the two can never fork.
 */

import { hasMutationSignal } from './analytical-intent.js';
import { hasConstraintMutationSignal } from './constraint-mutation-signal.js';
import {
  resolveOrdinaryTextAuthority,
  type OrdinaryTextAuthority,
} from './ordinary-text-authority.js';
import { isAnalyticalQuestion } from './analytical-question-guard.js';
import { isStateQueryQuestionShape } from './state-query-guard.js';
import {
  EDIT_GRAPH_POSITIVE_REGEX,
  EDIT_GRAPH_NEGATIVE_REGEX,
} from '../../orchestrator/routing/edit-graph-intent-regex.js';

/**
 * ⭐ THE CONSTRAINT-SHAPED SIGNAL NOW LIVES IN A LEAF, AND IS RE-EXPORTED HERE.
 *
 * `CONSTRAINT_MUTATION_SIGNAL_PATTERNS` and `hasConstraintMutationSignal` moved
 * VERBATIM to `./constraint-mutation-signal.js` so that
 * `./ordinary-text-authority.js` can subordinate its veto to an unambiguous
 * instruction without this module and that one importing each other. Re-exported
 * rather than relocated-and-rewired: every existing importer, including this
 * module's own specs, keeps its import path, and there is still exactly ONE
 * definition of the predicate.
 */
export {
  CONSTRAINT_MUTATION_SIGNAL_PATTERNS,
  hasConstraintMutationSignal,
} from './constraint-mutation-signal.js';

/**
 * Edit verbs the V5 mutating handlers serve that `EDIT_GRAPH_POSITIVE_REGEX`
 * does not carry — because that regex gates the STRUCTURAL edit_graph lane,
 * whose vocabulary is add/remove/rename, while these three handlers also serve
 * strength and intervention edits.
 *
 * ⚠ MEASURED, not guessed. Each entry is here because a real request in the
 * repo's own behavioural suite carries it and would otherwise cost the user a
 * chip click on a change they plainly asked for:
 *   strengthen/weaken  ← "strengthen the link from marketing budget to revenue"
 *   make X strong(er)  ← "Make the marketing budget effect on revenue strong"
 *   revise / configure ← "revise the Launch now option so its churn ... is lower",
 *                         "Help me configure Launch now."
 *   reduces / raises … ← "Launching reduces Customer churn to 2%" (the third-person
 *                         inflections `\breduce\b` misses)
 *   "X is now N"       ← "Customer churn is now 2%" — the DECLARATIVE value answer,
 *                         which is the affordance this product explicitly asks for
 *                         ("where does churn currently sit?"). Kept narrow: it
 *                         requires a copula, a nowness marker AND a number, so a
 *                         forecast ("a 70% chance churn stays below 3%") does not
 *                         match — that sentence is in the negative corpus.
 */
const WARRANT_EXTRA_EDIT_VERB_PATTERNS: readonly RegExp[] = [
  /\b(?:strengthen|strengthens|weaken|weakens|rename|renames|relabel|revise|revises|configure|configures)\b/i,
  /\bmake\b[^.?!\n]{0,80}\b(?:strong|stronger|strongest|weak|weaker|higher|lower|bigger|smaller|negative|positive)\b/i,
  /\b(?:reduces|increases|decreases|raises|lowers|changes|updates|adjusts|sets|removes|deletes|adds)\b/i,
  /\b(?:is|are|sits|sat|stands|runs)\s+(?:now|currently|at|about|around|roughly|approximately)\s+[-+]?[£$€]?\s?\d/i,
];

/**
 * The message half of the warrant: does the user's own text ask for a change?
 *
 * ⭐ THE UNION IS THE POINT, AND THE THIRD TERM IS WHERE THE PARITY LIVES.
 *
 *  1. `hasMutationSignal` — the canonical concrete-edit list ("set X to N",
 *     "add a Y"). Included wholesale so the two predicates cannot fork.
 *  2. `hasConstraintMutationSignal` — the constraint phrasings above, which
 *     term 1 carries none of.
 *  3. THE PRODUCT'S OWN EDIT-INTENT DOOR: the exact predicate
 *     `orchestrator/route-v2.ts` uses to decide whether a message is an edit
 *     request at all (`EDIT_GRAPH_POSITIVE_REGEX && !EDIT_GRAPH_NEGATIVE_REGEX`,
 *     minus the analytical-question and state-query suppressors it also
 *     applies), plus the verb extension above.
 *
 * ⚠ WHY TERM 3 RATHER THAN A LONGER BESPOKE LIST — this IS the consent parity
 * the fix is named for. The Graph-Management channel has always asked this
 * question at its door; the executor asked nothing, which is why the walk's
 * read request could reach a write there and not there. Reusing the same
 * predicate makes the two doors ask the same question by construction instead
 * of by a second list somebody has to remember to sync (CLAUDE.md trap 12), and
 * it inherits that regex's hardening against read markers — `EDIT_GRAPH_NEGATIVE_REGEX`
 * already excludes "show me", "explain", "compare", "tell me", "describe",
 * "why", "how does", "what would", which is the entire read vocabulary the walk
 * exercised.
 *
 * ⚠ WHAT TERM 3 DELIBERATELY DOES NOT SUBTRACT: route-v2 also suppresses on
 * `shouldSuppressEditDispatchForValueUpdate`. That is a ROUTING suppressor — it
 * sends "set X to N" down the deterministic D1 path INSTEAD of edit_graph — not
 * a judgement that the message is not an edit. Subtracting it here would strip
 * the warrant from the most unambiguous edit requests the product accepts.
 *
 * The result is a strict superset of `hasMutationSignal`; the union assertion
 * in the spec pins that, so the canonical list can never recognise an edit this
 * predicate refuses.
 *
 * ⭐⭐ THAT SENTENCE IS UNCONDITIONAL AGAIN, AND DELIBERATELY SO. An earlier
 * revision of this comment weakened it to "a superset EVERYWHERE EXCEPT an
 * explicit veto", to admit a fork introduced by Term 0 below. Term 0 as it now
 * stands cannot fork the relation: it requires `!hasMutationSignal(message)` to
 * refuse, and the statement immediately after it returns TRUE on that same
 * predicate, so a canonical hit can never reach the refusal. That is a proof,
 * not a sample — and it was checked by measurement too: over 1,093,500 generated
 * canonical-hit messages the fork count is 0 here and was 850,500 with the
 * unguarded Term 0. Do not re-weaken this sentence without re-running that probe.
 *
 * ⭐⭐ TERM 0 — AN EXPLICIT VETO IS CONSULTED BEFORE THE LEXICAL TERMS, AND THIS
 * IS NOT THE HOIST THAT FAILED.
 *
 * `hasExplicitNoModelChangeIntent` has lived in this module since #836 and
 * already answers exactly this question. This function never asked it. Measured
 * on a 48-case corpus: two messages in which the user explicitly withheld
 * authority were granted a mutation warrant —
 *   "Do not change the current causal model."          (this repo's own fixture)
 *   "…Do not change the graph until I confirm."        (captured, deployed)
 * The user said the exact words and was overruled. That is the worst member of
 * the false-positive class this predicate exists to prevent.
 *
 * ⚠ WHICH TERM ACTUALLY GRANTED THOSE TWO — CORRECTED, because the first version
 * of this comment named the wrong one and the wrong name is what hid the dead
 * spec branch. It said the words "change" and "the model" satisfied THE CANONICAL
 * LIST. They do not. Measured at the bytes on both strings:
 *   hasMutationSignal          = FALSE
 *   hasConstraintMutationSignal = FALSE
 *   isEditRequestShape          = TRUE
 * The granting term was TERM 3, `isEditRequestShape`. This matters beyond
 * pedantry: neither fixed row is a canonical hit, so neither ever exhibited the
 * `warrant ⊇ hasMutationSignal` fork that was offered as the reason to weaken the
 * superset invariant above.
 *
 * ⚠ A DIFFERENT HOIST WAS TRIED HERE AND REVERTED, so the distinction matters.
 * Hoisting `isStateQueryQuestionShape` above these terms made a QUESTION SHAPE
 * authoritative over the lexical signals, and it stripped the warrant from
 * genuine edits riding a question ("Where did that come from? Increase hiring
 * cost to 0.9." went TRUE -> FALSE). That predicate answers "is this a
 * question?", which is a different question from "did the user authorise a
 * write?", so above these terms it over-reaches.
 *
 * THIS predicate answers the authorisation question directly. ⚠⚠ BUT IT IS **NOT**
 * SAFE TO CONSULT ALONE, AND AN EARLIER REVISION OF THIS COMMENT CLAIMED IT WAS.
 * The withdrawn claim was: "it is CONSTRUCTED so it cannot strip a real edit —
 * it fires only when NO AFFIRMATIVE EDIT REMAINS once the protective clause is
 * removed", supported by "0 false positives across the 23 genuine-edit cases in
 * the corpus". Both halves were false in the way that matters:
 *
 *   · The affirmative-edit check it named is NEVER REACHED for an UNBOUNDED
 *     prohibition. `hasExplicitNoModelChangeIntent` returns its veto at the
 *     `!candidate.scopedTail && !candidate.entityScoped` early return, before
 *     `hasAffirmativeMutationOutsideCandidates` is ever consulted. The escape
 *     hatch beside it, `entityScoped`, is dead from HERE because Term 0 passes
 *     no `modelEntityLabels`.
 *   · The "0 across 23 edit cases" number held only because ALL 23 OF THOSE
 *     CASES WERE FREE OF PROHIBITION WORDING. The corpus was structurally
 *     incapable of observing the class. (CLAUDE.md trap 22 — a corpus that
 *     shares the code's blind spot cannot see the code's defect.)
 *
 * Measured on a 9-edit-core x 9-fence-phrasing matrix, unguarded Term 0 stripped
 * the warrant from 81 of 81 ordinary scoped edits ("Set Churn to 0.5 and do not
 * change the model."), while the same 9 cores WITHOUT a fence lost 0 of 9. On a
 * wider 9x20 corpus: 151 of 177. The product's own reply on such a turn WAS, as
 * measured, "Nothing has been changed. You did not ask me to edit the model, so
 * I have not." — refusing an explicit instruction AND misdescribing what the
 * user said. ⚠ THE SECOND HALF OF THAT HARM IS NOW CLOSED AT THE COPY (INV-3,
 * `buildMutationWarrantDemotionText` below, 1 Sep 2026): the reply no longer
 * asserts anything about what the user asked. The quoted sentence is retained
 * here as the DATED MEASUREMENT it was, not as current output. The FIRST half —
 * the warrant being stripped from a genuine fenced edit — is untouched by that
 * change and is still exactly why Term 0 carries its two negated conjuncts.
 *
 * THAT is why Term 0 carries the two negated conjuncts. They are load-bearing,
 * not defensive: with them the same matrix loses 9 of 81 and the wide corpus 17
 * of 180. The contrast the veto predicate's own docstring names — "Set X to 0.7
 * and do not change anything else" stays an authorised edit — is pinned in the
 * spec alongside the vetoes, and the regressed fenced-edit class is now pinned
 * there too, as EDIT rows, so this cell can never again go unobserved.
 *
 * ⛔ WHAT REMAINS OPEN, PINNED IN THE SPEC RATHER THAN PAPERED OVER:
 *   · 13 false positives turning on grammatical MOOD ("Change of plan." /
 *     "Should we change pricing?" / "What did the update to hiring cost do?").
 *   · A GAP — an edit that rides `isEditRequestShape` ALONE (no canonical and no
 *     constraint signal, e.g. "Edit hiring cost to 0.9") still loses its warrant
 *     when fenced, because the conjuncts above cannot see it. Two such rows are
 *     pinned as KNOWN_OPEN_GAPS.
 *   · A LIE — a RETRACTION ("Set Churn to 0.5 - actually no, do not change the
 *     model.") KEEPS its warrant here, where unguarded Term 0 correctly refused
 *     it. Pinned as KNOWN_OPEN_LIES.
 *
 * ⛔⛔ DO NOT WRITE A PREDICATE TO TELL A RETRACTION FROM A SCOPE FENCE. "…and do
 * not change anything else" (a fence, must warrant) versus "…actually no, do not
 * change the model" (a retraction, must veto) is a natural-language
 * discrimination over trailing clauses. This estate burned FOUR consecutive
 * rounds on exactly that shape on exactly this module, each closing one
 * direction and reopening the other under a fully green suite, and closed
 * PR #1107 after five variants across two independent corpora. The standing
 * ruling is that no further punctuation-only or lexical rule will settle it.
 * If you find yourself writing that predicate, STOP and report.
 *
 * ⭐⭐ TERM D — ORDINARY-TEXT AUTHORITY. THE SECOND PARAMETER IS A VERDICT THIS
 * FUNCTION DOES NOT COMPUTE, AND THAT IS THE POINT.
 *
 * The product performed the SAME model mutation whether the user gave an
 * explicit edit instruction or merely asked for advice, because every term above
 * answers *"do these words describe a change?"* and none answers *"did the user
 * ASK me to make it?"*. Measured at this tip, Term 3 alone grants a full mutation
 * warrant to **"Do you think the churn rate should be lower?"** — an advice
 * question, granted authority to write.
 *
 * `routing/ordinary-text-authority.ts` answers that second question ONCE, from
 * the estate's already-ratified deliberation classifier
 * (`classifyUnappliedEditFrame`) over a message quote-masked by the GRAPH'S OWN
 * node labels, and subordinates itself to the canonical and constraint lists so
 * a MIXED edit (advice + an explicit edit in one message) keeps its authority.
 * It is passed IN rather than called here for two reasons, both structural:
 *
 *   · the mask needs the model's node labels, which this module has no business
 *     loading; and
 *   · `detectMutationWarrant` resolves it ONLY AFTER `confirm_resume` and
 *     `typed_mutation_chip` have returned, so the veto is subordinate to the two
 *     stronger sources BY CONSTRUCTION rather than by an ordering somebody has
 *     to remember (see `hasStrongerThanTextWarrant`).
 *
 * ⚠ THE DEFAULT IS `'granted'`, DELIBERATELY. A caller that does not resolve the
 * question gets exactly the behaviour it had before this term existed — including
 * `hasAffirmativeMutationOutsideCandidates` below, which passes a REMAINDER
 * string with the prohibitive clause already removed and must keep answering the
 * old question about it.
 */
export function hasMutationWarrantSignal(
  message: string,
  ordinaryTextAuthority: OrdinaryTextAuthority = 'granted',
): boolean {
  if (typeof message !== 'string' || message.trim().length === 0) return false;
  // Term 0 — the user explicitly withheld authority AND no canonical mutation
  // signal survives the prohibition. The two negated conjuncts are not decoration:
  // `hasExplicitNoModelChangeIntent` returns its veto IMMEDIATELY for an UNBOUNDED
  // prohibition (see the early return at the `!scopedTail && !entityScoped` line
  // below) WITHOUT ever consulting its own affirmative-edit check, so on its own it
  // strips the warrant from "Set Churn to 0.5 and do not change the model." —
  // measured over a 9-core x 9-fence matrix, 81/81. Requiring the canonical lists
  // to be silent too restores those edits using only authorities this module
  // already had. What this does NOT fix is pinned as KNOWN_OPEN_GAPS /
  // KNOWN_OPEN_LIES in `__tests__/mutation-warrant-explicit-veto.test.ts`.
  if (
    hasExplicitNoModelChangeIntent(message) &&
    !hasMutationSignal(message) &&
    !hasConstraintMutationSignal(message)
  ) {
    return false;
  }
  // Term D — the user asked what we THINK and no unambiguous instruction
  // survives that frame. Read AFTER Term 0 and BEFORE the lexical terms: an
  // explicit "do not change the model" outranks everything including this, and
  // this outranks vocabulary, because it is the only term that asks whether the
  // user AUTHORISED a write rather than whether their words DESCRIBE one.
  // Both are vetoes, so the relative order of Term 0 and Term D cannot change
  // any outcome — it is written this way to be READ in that order.
  if (ordinaryTextAuthority === 'withheld_deliberation') return false;
  if (hasMutationSignal(message)) return true;
  if (hasConstraintMutationSignal(message)) return true;
  return isEditRequestShape(message);
}

/**
 * ⭐ THE TWO WARRANT SOURCES THAT OUTRANK ORDINARY TEXT, IN ONE PLACE.
 *
 * `detectMutationWarrant` below answers this first and returns before any text
 * is read; `handlers/edit-graph-dispatch.ts` asks the same question so its own
 * ordinary-text conjunct cannot second-guess a chip click or a confirmed hold.
 *
 * ⚠ ONE LIST, TWO CONSUMERS — not two orderings that have to be kept in sync.
 * Two lists standing for one concept is this estate's dominant defect, and the
 * whole reason this seam needed fixing is that a deliberation classifier and a
 * write decision lived in different places without knowing about each other.
 */
export function hasStrongerThanTextWarrant(
  input: Pick<MutationWarrantInput, 'turnSource' | 'chipActionType' | 'isConfirmResume'>,
  mutationActionTypes: ReadonlySet<string>,
): boolean {
  if (input.isConfirmResume) return true;
  const isChipTurn = input.turnSource === 'chip_click' || input.turnSource === 'chip';
  return isChipTurn && isMutationChipActionType(input.chipActionType, mutationActionTypes);
}

/**
 * The small, answer-seeking class that must never be converted into an edit.
 *
 * These are analytical questions whose wording is not covered by the older
 * what-would-flip taxonomy: safety under missing information, a request for
 * the next fact to gather, or a direct challenge to an existing result.  The
 * browser-witnessed prompts often finish with "do not change the model";
 * `hasMutationSignal` sees the bare word "change" and therefore cannot be the
 * discriminator by itself.
 *
 * We first require an answer-seeking shape, then remove only the explicit
 * negative-scope clause and ask the existing mutation authorities whether an
 * affirmative edit remains.  That last step is the contrast guard for
 * "Set X to 0.7 and do not change anything else": it remains an edit.
 */
const BOUNDED_NON_MUTATION_ANALYTICAL_PATTERNS: readonly RegExp[] = [
  /\b(?:is\s+it\s+safe|safest\s+way|safe\s+to\s+run|safe\s+way)\b/i,
  /\b(?:challenge|critique)\b[^.?!\n]{0,120}\b(?:result|analysis|outcome)\b/i,
  /\b(?:strongest\s+reason|strongest\s+challenge)\b[^.?!\n]{0,120}\b(?:misleading|result|analysis|outcome)\b/i,
  /\b(?:which|what)\s+(?:single\s+)?(?:missing\s+)?(?:fact|piece\s+of\s+evidence)\b/i,
  /\bdoes\b[^.?!\n]{0,80}\bresult\b[^.?!\n]{0,80}\bjustify\b/i,
];

/**
 * A bounded token recognizer for explicit model-change vetoes.
 *
 * This deliberately does not grow another edit-intent regex. Text is first
 * normalized and split into clauses; exact lexemes then establish three facts
 * inside one clause: a prohibitive cue, a mutation word, and an exact
 * model/graph object. Exact tokens keep `model`/`graph` prefix collisions out,
 * while the small bridge vocabulary admits ordinary grammatical permutations
 * such as "without edits being made to my current causal graph".
 */
/**
 * ⭐⭐ THE VERBS THAT AUTHORISE A WRITE ARE THE VERBS THAT CAN FORBID ONE.
 *
 * This is the canonical base vocabulary, and `deterministic-value-update.ts`
 * builds its `EDIT_VERB_PATTERN` from it rather than keeping a second copy.
 *
 * ⚠ WHY IT IS DERIVED AND NOT MIRRORED (SENDABLE P0, 24 Aug 2026). The grant
 * side dispatched on ten verbs; this veto knew nine, and they OVERLAPPED ON
 * THREE — change, update, adjust. So `increase`, `decrease`, `reduce`, `raise`,
 * `lower`, `set` and `make` could each authorise a canonical write while no
 * prohibition using them could stop one.
 *
 * `set` is the worst of the seven, because it is not an edge case: the product
 * dispatches `set_factor_value`, and its own coaching copy tells the user to
 * type "Set the … option's effect on Rep Adoption Quality to 0.6". So the
 * product taught a verb its own prohibition vocabulary could not hear. Measured
 * on staging: "Whatever you do, don't set Rep Adoption Quality to 0.2" wrote the
 * value and replied "Updated Rep Adoption Quality from 0.7 to 0.2."
 *
 * Two lists standing for one concept is this estate's dominant defect. One list,
 * two consumers.
 */
export const EDIT_VERB_BASES = [
  'increase', 'decrease', 'reduce', 'raise', 'lower',
  'set', 'change', 'update', 'make', 'adjust',
] as const;

/**
 * Inflections stay local to the token matcher: English morphology is irregular
 * (`set`→`set`, `make`→`made`) and generating it would be a worse mirror than
 * writing it. What must AGREE across the two sides is the base vocabulary
 * above, and that is imported, not copied.
 */
const MUTATION_VERB_LEXEMES = new Set([
  ...EDIT_VERB_BASES,
  'increases', 'increased', 'increasing',
  'decreases', 'decreased', 'decreasing',
  'reduces', 'reduced', 'reducing',
  'raises', 'raised', 'raising',
  'lowers', 'lowered', 'lowering',
  'sets', 'setting',
  'changes', 'changed', 'changing',
  'updates', 'updated', 'updating',
  'makes', 'made', 'making',
  'adjusts', 'adjusted', 'adjusting',
  // Retained beyond the grant vocabulary: these forbid writes the LLM route can
  // still perform even where the deterministic path never dispatches on them.
  'edit', 'edits', 'edited', 'editing',
  'modify', 'modifies', 'modified', 'modifying',
  'mutate', 'mutates', 'mutated', 'mutating',
  'touch', 'touches', 'touched', 'touching',
  'alter', 'alters', 'altered', 'altering',
  'rewrite', 'rewrites', 'rewrote', 'rewritten', 'rewriting',
]);

const MUTATION_NOUN_LEXEMES = new Set([
  'change', 'changes',
  'edit', 'edits',
  'update', 'updates',
  'modification', 'modifications',
  'mutation', 'mutations',
  'adjustment', 'adjustments',
  'alteration', 'alterations',
  'rewrite', 'rewrites',
]);

const MUTATION_LEXEMES = new Set([
  ...MUTATION_VERB_LEXEMES,
  ...MUTATION_NOUN_LEXEMES,
]);

const MODEL_OBJECT_LEXEMES = new Set(['model', 'models', 'graph', 'graphs']);
const MODEL_QUALIFIER_LEXEMES = new Set([
  'a', 'an', 'the', 'this', 'that',
  'my', 'our', 'your', 'their', 'its',
  'current', 'existing', 'working', 'underlying',
  'causal', 'shared', 'strategic', 'decision',
]);
const CUE_FILLER_LEXEMES = new Set([
  'please', 'just', 'ever', 'directly', 'deliberately', 'accidentally',
  'now', 'immediately', 'under', 'a', 'an', 'any', 'circumstances', 'in', 'way',
  'additional', 'further', 'other',
]);
const MUTATION_OBJECT_BRIDGE_LEXEMES = new Set([
  ...MODEL_QUALIFIER_LEXEMES,
  'any', 'no', 'to', 'of', 'in', 'on', 'for', 'about', 'within', 'from',
  'be', 'being', 'been', 'is', 'are', 'was', 'were',
  'get', 'gets', 'getting', 'got',
  'make', 'making', 'made', 'apply', 'applying', 'applied',
  'at', 'all', 'it', 'itself', 'them', 'themselves',
  'additional', 'further', 'other',
]);
const MUTATION_OPERATORS = new Set(['make', 'making', 'apply', 'applying']);
const MUTATION_CONTROLS = new Set(['let', 'allow', 'have']);
const SCOPED_TAIL_LEXEMES = new Set(['additional', 'further', 'other']);
const MODEL_CONNECTOR_LEXEMES = new Set(['to', 'of', 'in', 'on', 'within']);
const MAX_CUE_WINDOW_TOKENS = 14;
const MAX_MODEL_QUALIFIERS = 5;

interface NoChangeCandidate {
  readonly start: number;
  readonly end: number;
  readonly scopedTail: boolean;
  readonly cue: 'do_not' | 'never' | 'without' | 'no';
  /**
   * The prohibition's object was a NAMED ENTITY in the user's graph, not the
   * model as a whole. See `hasExplicitNoModelChangeIntent` — this is the
   * difference between "do not change the model" (unbounded, and genuinely
   * ambiguous beside an affirmative edit) and "don't touch Churn" (inherently
   * scoped to Churn, and silent about Growth).
   */
  readonly entityScoped?: boolean;
}

interface NoChangeClause {
  readonly tokens: readonly string[];
  readonly question: boolean;
}

function isWordCharacter(character: string | undefined): boolean {
  if (!character) return false;
  const code = character.toLowerCase().charCodeAt(0);
  return (code >= 97 && code <= 122) || (code >= 48 && code <= 57);
}

function isCompleteQuotedNoChangePhrase(quoted: string): boolean {
  const normalized = quoted
    .normalize('NFKC')
    .replace(/[‘’]/g, "'")
    .replace(/\bdon\s*'\s*t\b/gi, 'do not')
    .toLowerCase();
  const tokens = tokenizeNoChangeClause(normalized);
  const hasCue = tokens.some((token, index) =>
    token === 'without' || token === 'never' || token === 'no' ||
    (token === 'do' && tokens[index + 1] === 'not'));
  return hasCue && tokens.some((token) => MUTATION_LEXEMES.has(token)) &&
    tokens.some((token) => MODEL_OBJECT_LEXEMES.has(token));
}

/** Remove complete quoted mentions; an unmatched quote is left untouched. */
function maskQuotedMentions(message: string): string {
  const characters = [...message];
  for (let start = 0; start < characters.length; start += 1) {
    const opening = characters[start];
    const doubleQuote = opening === '"' || opening === '“';
    const singleQuote = (opening === "'" || opening === '‘') &&
      !isWordCharacter(characters[start - 1]) && isWordCharacter(characters[start + 1]);
    if (!doubleQuote && !singleQuote) continue;
    const closing = opening === '“' ? '”' : opening === '‘' ? '’' : opening;
    let end = start + 1;
    while (end < characters.length) {
      const matchesDelimiter = characters[end] === closing;
      const contractionApostrophe = singleQuote &&
        isWordCharacter(characters[end - 1]) && isWordCharacter(characters[end + 1]);
      if (matchesDelimiter && !contractionApostrophe) break;
      end += 1;
    }
    if (end >= characters.length) continue;
    const quoted = characters.slice(start + 1, end).join('');
    const hasOutsideContext = characters.slice(0, start).some(isWordCharacter) ||
      characters.slice(end + 1).some(isWordCharacter);
    if (hasOutsideContext && isCompleteQuotedNoChangePhrase(quoted)) {
      for (let cursor = start; cursor <= end; cursor += 1) characters[cursor] = ' ';
    }
    start = end;
  }
  return characters.join('');
}

function tokenizeNoChangeClause(clause: string): readonly string[] {
  return clause.match(/[a-z0-9]+(?:-[a-z0-9]+)*/g) ?? [];
}

function splitNoChangeClauses(message: string): NoChangeClause[] {
  const normalized = maskQuotedMentions(message)
    .normalize('NFKC')
    .replace(/[‘’]/g, "'")
    .replace(/\bdon\s*'\s*t\b/gi, 'do not')
    .toLowerCase();
  const clauses: NoChangeClause[] = [];
  let buffer = '';
  const pushClause = (question: boolean): void => {
    const tokens = tokenizeNoChangeClause(buffer);
    if (tokens.length > 0) clauses.push({ tokens, question });
    buffer = '';
  };
  for (const character of normalized) {
    if (character === '?') {
      pushClause(true);
    } else if (character === '.' || character === '!' || character === ';' ||
      character === '\n' || character === '\r') {
      pushClause(false);
    } else {
      buffer += character === ':' || character === '—' || character === '–' ? ' ' : character;
    }
  }
  pushClause(false);
  return clauses;
}

function skipCueFillers(tokens: readonly string[], from: number, limit: number): number {
  let cursor = from;
  while (cursor < limit && CUE_FILLER_LEXEMES.has(tokens[cursor]!)) cursor += 1;
  return cursor;
}

/**
 * The model's OWN ENTITY LABELS, tokenised, so a prohibition naming a factor is
 * recognised as a prohibition about the model.
 *
 * ⭐ WHY THIS EXISTS. `MODEL_OBJECT_LEXEMES` is four tokens standing in for an
 * unbounded class: every entity label in the user's graph. The GRANT side
 * already resolves those labels against the live graph
 * (`deterministic-value-update.ts` — `normMessage.indexOf(normLabel)`); the
 * VETO side did not. That asymmetry was the whole of SENDABLE P0 (24 Aug 2026):
 * "Whatever you do, don't set Rep Adoption Quality to 0.2" produced NO veto
 * candidate at all, because the walk in `findModelObjectAfter` hit "rep" —
 * neither a model object nor a bridge lexeme — and aborted. The product then
 * performed the edit and reported "Updated Rep Adoption Quality from 0.7 to 0.2".
 *
 * The same sentence was specific enough to AUTHORISE a write and not specific
 * enough to FORBID one. This closes that, using the caller's own graph rather
 * than a fifth hand-maintained lexeme — the tail vocabulary is an open class and
 * a longer list is the next round of the same mistake.
 */
type LabelRun = readonly string[];

function tokeniseEntityLabels(labels: readonly string[] | undefined): readonly LabelRun[] {
  if (!labels || labels.length === 0) return EMPTY_LABEL_RUNS;
  const runs: LabelRun[] = [];
  for (const raw of labels) {
    if (typeof raw !== 'string') continue;
    const run = tokenizeNoChangeClause(raw.toLowerCase());
    if (!isUsableLabelRun(run)) continue;
    runs.push(run);
  }
  return runs;
}

const EMPTY_LABEL_RUNS: readonly LabelRun[] = [];

/**
 * Minimum label length, and a stopword floor.
 *
 * ⚠ Without these a graph node called "It", "A" or "Me" turns ordinary English
 * into a prohibition — "Never reduce it below 0.3.", "do not change a thing",
 * "Do not update me on this." This repo's OWN fixtures carry labels `A`, `X`,
 * `y` and `a`, so this is not hypothetical. A label short enough to collide
 * with grammar cannot carry a prohibition.
 */
const MIN_LABEL_TOKEN_LENGTH = 3;
const LABEL_STOPWORD_LEXEMES = new Set([
  'it', 'me', 'us', 'them', 'him', 'her', 'you', 'we', 'they',
  'a', 'an', 'the', 'this', 'that', 'these', 'those',
  'thing', 'things', 'any', 'all', 'one', 'some',
  ...MODEL_QUALIFIER_LEXEMES,
]);

/** A label is usable as a prohibition object only if it can't be grammar. */
function isUsableLabelRun(run: LabelRun): boolean {
  if (run.length === 0) return false;
  // Every token a stopword → the label is indistinguishable from grammar.
  if (run.every((token) => LABEL_STOPWORD_LEXEMES.has(token))) return false;
  // A single short token collides with ordinary words.
  if (run.length === 1 && run[0]!.length < MIN_LABEL_TOKEN_LENGTH) return false;
  return true;
}

/** Does one of the model's entity labels start exactly at `cursor`? */
function labelRunEndAt(
  tokens: readonly string[],
  cursor: number,
  labelRuns: readonly LabelRun[],
): number | null {
  for (const run of labelRuns) {
    if (cursor + run.length > tokens.length) continue;
    let hit = true;
    for (let offset = 0; offset < run.length; offset += 1) {
      if (tokens[cursor + offset] !== run[offset]) { hit = false; break; }
    }
    // ⚠ A LABEL THAT SPANS THE MODEL OBJECT IS NOT AN ENTITY-SCOPED OBJECT.
    // `MODEL_OBJECT_LEXEMES` only wins at the SAME cursor, so a factor literally
    // named "The Model" starts one token earlier and swallows `model` — which
    // would classify a genuine whole-model prohibition as entity-scoped, skip
    // the conservative short-circuit, and let the affirmative edit through.
    // Measured: with a factor named "The Model", "Do not change the model. Set
    // Growth to 0.9." flipped from vetoed to WRITE. That is this PR's own
    // flagship control, broken by a label.
    if (hit && run.some((token) => MODEL_OBJECT_LEXEMES.has(token))) return null;
    // Return the LAST token of the label, so any scoped-tail scan that follows
    // starts after the whole object rather than inside it.
    if (hit) return cursor + run.length - 1;
  }
  return null;
}

interface ObjectMatch {
  readonly end: number;
  /** The object was a NAMED ENTITY, not the model as a whole. */
  readonly viaLabel: boolean;
}

function findModelObjectAfter(
  tokens: readonly string[],
  from: number,
  limit: number,
  labelRuns: readonly LabelRun[] = EMPTY_LABEL_RUNS,
): ObjectMatch | null {
  for (let cursor = from; cursor < limit; cursor += 1) {
    if (MODEL_OBJECT_LEXEMES.has(tokens[cursor]!)) return { end: cursor, viaLabel: false };
    const labelEnd = labelRunEndAt(tokens, cursor, labelRuns);
    if (labelEnd !== null) return { end: labelEnd, viaLabel: true };
    if (!MUTATION_OBJECT_BRIDGE_LEXEMES.has(tokens[cursor]!)) return null;
  }
  return null;
}

function parseModelObjectAt(
  tokens: readonly string[],
  from: number,
  limit: number,
  labelRuns: readonly LabelRun[] = EMPTY_LABEL_RUNS,
): ObjectMatch | null {
  const objectLimit = Math.min(limit, from + MAX_MODEL_QUALIFIERS + 1);
  for (let cursor = from; cursor < objectLimit; cursor += 1) {
    const token = tokens[cursor]!;
    if (MODEL_OBJECT_LEXEMES.has(token)) return { end: cursor, viaLabel: false };
    const labelEnd = labelRunEndAt(tokens, cursor, labelRuns);
    if (labelEnd !== null) return { end: labelEnd, viaLabel: true };
    if (!MODEL_QUALIFIER_LEXEMES.has(token)) return null;
  }
  return null;
}

function findMutationAfter(
  tokens: readonly string[],
  from: number,
  limit: number,
  nounsOnly = false,
): number | null {
  const lexemes = nounsOnly ? MUTATION_NOUN_LEXEMES : MUTATION_LEXEMES;
  for (let cursor = from; cursor < limit; cursor += 1) {
    if (lexemes.has(tokens[cursor]!)) return cursor;
    if (!MUTATION_OBJECT_BRIDGE_LEXEMES.has(tokens[cursor]!)) return null;
  }
  return null;
}

function hasScopedTailMarker(
  tokens: readonly string[],
  start: number,
  end: number,
): boolean {
  for (let cursor = start; cursor <= end; cursor += 1) {
    if (SCOPED_TAIL_LEXEMES.has(tokens[cursor]!)) return true;
    if (tokens[cursor] === 'anything' && tokens[cursor + 1] === 'else') return true;
  }
  return false;
}

function makeCandidate(
  tokens: readonly string[],
  start: number,
  end: number,
  cue: NoChangeCandidate['cue'],
  entityScoped = false,
): NoChangeCandidate {
  return {
    start,
    end,
    cue,
    entityScoped,
    scopedTail: hasScopedTailMarker(tokens, start, tokens.length - 1),
  };
}

function findDirectNoChangeCandidate(
  tokens: readonly string[],
  cueStart: number,
  cueEnd: number,
  cue: 'do_not' | 'never' | 'without',
  labelRuns: readonly LabelRun[] = EMPTY_LABEL_RUNS,
): NoChangeCandidate | null {
  const limit = Math.min(tokens.length, cueEnd + MAX_CUE_WINDOW_TOKENS);
  const first = skipCueFillers(tokens, cueEnd, limit);
  if (first >= limit) return null;
  const firstToken = tokens[first]!;

  if (MUTATION_LEXEMES.has(firstToken)) {
    const object = findModelObjectAfter(tokens, first + 1, limit, labelRuns);
    if (object !== null) return makeCandidate(tokens, cueStart, object.end, cue, object.viaLabel);
    // ⚠ FALL THROUGH, do not return null. A verb can be BOTH a mutation lexeme
    // and an operator over a mutation noun: "make any changes to the model"
    // reads `make` as the verb here, finds no model object directly after it,
    // and must still be parsed by the operator/noun route below. Returning null
    // at this point silently un-vetoed all three of
    // "Never make any changes to our causal graph.",
    // "Do not make further changes to the current causal model." and
    // "Without making any changes to the current model." the moment `make`
    // joined the shared edit vocabulary — caught by the existing suite.
  }

  if (MUTATION_OPERATORS.has(firstToken)) {
    const afterOperator = skipCueFillers(tokens, first + 1, limit);
    const mutation = findMutationAfter(tokens, afterOperator, limit, true);
    if (mutation !== null) {
      const object = findModelObjectAfter(tokens, mutation + 1, limit, labelRuns);
      if (object !== null) return makeCandidate(tokens, cueStart, object.end, cue, object.viaLabel);
    }
    const object = parseModelObjectAt(tokens, afterOperator, limit, labelRuns);
    if (object !== null) {
      const noun = findMutationAfter(tokens, object.end + 1, limit, true);
      if (noun !== null) return makeCandidate(tokens, cueStart, noun, cue, object.viaLabel);
    }
    return null;
  }

  if (MUTATION_CONTROLS.has(firstToken)) {
    const objectStart = skipCueFillers(tokens, first + 1, limit);
    const mutationFirst = findMutationAfter(tokens, objectStart, limit);
    if (mutationFirst !== null) {
      const objectAfter = findModelObjectAfter(tokens, mutationFirst + 1, limit, labelRuns);
      if (objectAfter !== null) return makeCandidate(tokens, cueStart, objectAfter.end, cue, objectAfter.viaLabel);
    }
    const object = parseModelObjectAt(tokens, objectStart, limit, labelRuns);
    if (object === null) return null;
    const mutation = findMutationAfter(tokens, object.end + 1, limit);
    return mutation === null ? null : makeCandidate(tokens, cueStart, mutation, cue, object.viaLabel);
  }

  const object = parseModelObjectAt(tokens, first, limit, labelRuns);
  if (object === null) return null;
  const mutation = findMutationAfter(tokens, object.end + 1, limit);
  return mutation === null ? null : makeCandidate(tokens, cueStart, mutation, cue, object.viaLabel);
}

/**
 * The bare `no` form is intentionally narrower than `do not` / `without`.
 * It must be the compact noun construction "no changes to/of/in/on/within
 * [model]", or the symmetric object-first fragment "no model changes".
 * Directive-vs-description classification happens after the bounded phrase is
 * found, so merely mentioning that such changes were recorded is not a veto.
 */
function findNarrowNoCandidate(
  tokens: readonly string[],
  noIndex: number,
  labelRuns: readonly LabelRun[] = EMPTY_LABEL_RUNS,
): NoChangeCandidate | null {
  const limit = Math.min(tokens.length, noIndex + MAX_CUE_WINDOW_TOKENS);
  let cursor = noIndex + 1;
  while (cursor < limit && (tokens[cursor] === 'any' || SCOPED_TAIL_LEXEMES.has(tokens[cursor]!))) {
    cursor += 1;
  }

  if (MUTATION_NOUN_LEXEMES.has(tokens[cursor]!)) {
    const connector = tokens[cursor + 1];
    if (!MODEL_CONNECTOR_LEXEMES.has(connector!)) return null;
    const object = parseModelObjectAt(tokens, cursor + 2, limit, labelRuns);
    if (object === null) return null;
    const start = MUTATION_OPERATORS.has(tokens[noIndex - 1]!) ? noIndex - 1 : noIndex;
    return makeCandidate(tokens, start, object.end, 'no', object.viaLabel);
  }

  const object = parseModelObjectAt(tokens, cursor, limit, labelRuns);
  if (object === null) return null;
  const noun = findMutationAfter(tokens, object.end + 1, limit, true);
  if (noun === null) return null;
  const start = MUTATION_OPERATORS.has(tokens[noIndex - 1]!) ? noIndex - 1 : noIndex;
  return makeCandidate(tokens, start, noun, 'no', object.viaLabel);
}

function findNoChangeCandidates(
  tokens: readonly string[],
  labelRuns: readonly LabelRun[] = EMPTY_LABEL_RUNS,
): NoChangeCandidate[] {
  const candidates: NoChangeCandidate[] = [];
  for (let cursor = 0; cursor < tokens.length; cursor += 1) {
    let candidate: NoChangeCandidate | null = null;
    if (tokens[cursor] === 'do' && tokens[cursor + 1] === 'not') {
      candidate = findDirectNoChangeCandidate(tokens, cursor, cursor + 2, 'do_not', labelRuns);
    } else if (tokens[cursor] === 'never') {
      candidate = findDirectNoChangeCandidate(tokens, cursor, cursor + 1, 'never', labelRuns);
    } else if (tokens[cursor] === 'without') {
      candidate = findDirectNoChangeCandidate(tokens, cursor, cursor + 1, 'without', labelRuns);
    } else if (tokens[cursor] === 'no') {
      candidate = findNarrowNoCandidate(tokens, cursor, labelRuns);
    }
    if (candidate) candidates.push(candidate);
  }
  return candidates;
}

const IMPERATIVE_MAIN_LEXEMES = new Set([
  'answer', 'analyse', 'analyze', 'assess', 'calculate', 'challenge', 'check',
  'clarify', 'compare', 'continue', 'critique', 'ensure', 'evaluate', 'explain',
  'find', 'give', 'help', 'identify', 'keep', 'make', 'proceed', 'run', 'set',
  'show', 'tell', 'use', 'verify',
]);
const QUESTION_MAIN_LEXEMES = new Set([
  'can', 'could', 'do', 'does', 'how', 'is', 'may', 'should', 'what', 'which',
  'will', 'would', 'why',
]);
const MAIN_CLAUSE_FILLERS = new Set(['and', 'then', 'please']);
const NO_FRAGMENT_FILLERS = new Set(['and', 'only', 'please', 'with']);
const DEONTIC_DIRECTIVE_LEXEMES = new Set(['must', 'need', 'needs', 'shall', 'should']);

function noChangeRemainderTokens(
  tokens: readonly string[],
  candidate: NoChangeCandidate,
): readonly string[] {
  return tokens.filter(
    (_, tokenIndex) => tokenIndex < candidate.start || tokenIndex > candidate.end,
  );
}

function hasDirectiveMainClause(tokens: readonly string[]): boolean {
  let first = 0;
  while (first < tokens.length && MAIN_CLAUSE_FILLERS.has(tokens[first]!)) first += 1;
  if (first >= tokens.length) return true;
  const firstToken = tokens[first]!;
  return IMPERATIVE_MAIN_LEXEMES.has(firstToken) || QUESTION_MAIN_LEXEMES.has(firstToken);
}

/**
 * `without` also introduces historical adjuncts ("the team ran it without
 * changing the model"). It is a veto only when its containing clause is
 * itself directive/question-shaped, or when the no-change phrase stands alone.
 */
function isDirectiveNoChangeCandidate(
  clause: NoChangeClause,
  candidate: NoChangeCandidate,
): boolean {
  if (candidate.cue === 'without') {
    if (clause.question) return true;
    return hasDirectiveMainClause(noChangeRemainderTokens(clause.tokens, candidate));
  }
  if (candidate.cue !== 'no') return true;

  const remainder = noChangeRemainderTokens(clause.tokens, candidate)
    .filter((token) => !NO_FRAGMENT_FILLERS.has(token));
  if (remainder.length === 0) return true;
  return hasDirectiveMainClause(remainder) ||
    remainder.some((token) => DEONTIC_DIRECTIVE_LEXEMES.has(token));
}

const EPISTEMIC_BRIDGE_LEXEMES = new Set([
  'understand', 'know', 'explain', 'clarify', 'confirm', 'check', 'verify',
  'tell', 'show', 'why', 'whether', 'how', 'what',
]);

function hasInstructionalPassiveBridge(tokens: readonly string[], setIndex: number): boolean {
  const from = Math.max(0, setIndex - 14);
  const beforeSet = tokens.slice(from, setIndex);
  const ensureIndex = beforeSet.lastIndexOf('ensure');
  let makeSureIndex = -1;
  for (let index = 0; index < beforeSet.length - 1; index += 1) {
    if (beforeSet[index] === 'make' && beforeSet[index + 1] === 'sure') {
      makeSureIndex = index;
    }
  }
  const seeIndex = beforeSet.lastIndexOf('see');
  const bridgeIndex = Math.max(ensureIndex, makeSureIndex, seeIndex);
  if (bridgeIndex < 0) return false;
  return !beforeSet.slice(bridgeIndex + 1).some((token) => EPISTEMIC_BRIDGE_LEXEMES.has(token));
}

/** Mask a descriptive "is/was/has been set to" in the scoped-tail remainder. */
function maskDescriptivePassiveSet(tokens: readonly string[]): string[] {
  return tokens.map((token, index) => {
    if (token !== 'set') return token;
    const directPassive = ['is', 'are', 'was', 'were'].includes(tokens[index - 1]!);
    const perfectPassive = tokens[index - 1] === 'been' &&
      ['has', 'have', 'had'].includes(tokens[index - 2]!);
    if ((!directPassive && !perfectPassive) || hasInstructionalPassiveBridge(tokens, index)) {
      return token;
    }
    return 'equals';
  });
}

interface LocatedNoChangeCandidate {
  readonly clauseIndex: number;
  readonly candidate: NoChangeCandidate;
}

function hasAffirmativeMutationOutsideCandidates(
  clauses: readonly NoChangeClause[],
  candidates: readonly LocatedNoChangeCandidate[],
): boolean {
  const omittedByClause = new Map<number, Set<number>>();
  for (const { clauseIndex, candidate } of candidates) {
    const omitted = omittedByClause.get(clauseIndex) ?? new Set<number>();
    for (let index = candidate.start; index <= candidate.end; index += 1) {
      omitted.add(index);
    }
    omittedByClause.set(clauseIndex, omitted);
  }
  const remainderClauses = clauses
    .map(({ tokens }, index) => {
      const omitted = omittedByClause.get(index);
      return omitted ? tokens.filter((_, tokenIndex) => !omitted.has(tokenIndex)) : [...tokens];
    })
    .map(maskDescriptivePassiveSet);
  const remainder = remainderClauses
    .map((tokens) => tokens.join(' '))
    .join('. ');
  return hasMutationWarrantSignal(remainder) || remainderClauses.some(hasImperativeMakeValueEdit);
}

function hasImperativeMakeValueEdit(tokens: readonly string[]): boolean {
  let first = 0;
  while (first < tokens.length && MAIN_CLAUSE_FILLERS.has(tokens[first]!)) first += 1;
  if (tokens[first] !== 'make' || tokens[first + 1] === 'sure') return false;
  for (let cursor = first + 2; cursor < tokens.length; cursor += 1) {
    if (Number.isFinite(Number(tokens[cursor]))) return true;
  }
  return false;
}

/**
 * Did the user explicitly withhold model-change authority, with no affirmative
 * edit left after that protective clause is removed?
 *
 * The contrast is load-bearing: "do not change the model" is a veto, while
 * "Set X to 0.7 and do not change anything else" remains an authorised edit.
 * Deterministic mutation pre-routes reuse this predicate so the action-layer
 * warrant and the fast path cannot disagree about the same sentence.
 */
export function hasExplicitNoModelChangeIntent(
  message: string,
  modelEntityLabels?: readonly string[],
): boolean {
  if (typeof message !== 'string') return false;
  const trimmed = message.trim();
  if (trimmed.length === 0) return false;
  const clauses = splitNoChangeClauses(trimmed);
  const labelRuns = tokeniseEntityLabels(modelEntityLabels);
  const scopedCandidates: LocatedNoChangeCandidate[] = [];
  for (let clauseIndex = 0; clauseIndex < clauses.length; clauseIndex += 1) {
    const clause = clauses[clauseIndex]!;
    for (const candidate of findNoChangeCandidates(clause.tokens, labelRuns)) {
      if (!isDirectiveNoChangeCandidate(clause, candidate)) continue;
      // ⭐⭐ AN ENTITY-SCOPED PROHIBITION IS ALREADY SCOPED, so it must never
      // short-circuit the whole turn. "Don't increase Churn — set Growth to 0.9."
      // forbids ONE thing and authorises another; vetoing the turn drops an edit
      // the user plainly asked for. This is the distinction the old single
      // window could not express: an UNBOUNDED prohibition ("do not change the
      // model") beside an affirmative edit is genuinely self-contradictory and
      // stays conservatively vetoed here, unchanged; a prohibition naming an
      // entity is not ambiguous at all and defers to the affirmative-edit check
      // below. Two questions, two paths — not one wider window.
      if (!candidate.scopedTail && !candidate.entityScoped) return true;
      scopedCandidates.push({ clauseIndex, candidate });
    }
  }
  if (scopedCandidates.length === 0) return false;
  return !hasAffirmativeMutationOutsideCandidates(clauses, scopedCandidates);
}

export function isBoundedNonMutationAnalyticalRequest(message: string): boolean {
  if (typeof message !== 'string') return false;
  const trimmed = message.trim();
  if (trimmed.length === 0) return false;
  if (!BOUNDED_NON_MUTATION_ANALYTICAL_PATTERNS.some((pattern) => pattern.test(trimmed))) {
    return false;
  }

  if (hasExplicitNoModelChangeIntent(trimmed)) return true;
  return !(
    hasMutationSignal(trimmed) ||
    hasConstraintMutationSignal(trimmed) ||
    isEditRequestShape(trimmed)
  );
}

export type BoundedNonMutationHandler = 'explain_from_structure' | 'explain_results';

/** One state-dependent, non-mutating destination for the bounded re-election. */
export function selectBoundedNonMutationHandler(
  message: string,
  analysisPresent: boolean,
): BoundedNonMutationHandler | null {
  if (!isBoundedNonMutationAnalyticalRequest(message)) return null;
  return analysisPresent ? 'explain_results' : 'explain_from_structure';
}

/**
 * Term 3 of the warrant union — the product's own edit-intent door.
 * Exported so the spec can assert it against the SAME regexes route-v2 uses
 * rather than against a copy of them.
 */
export function isEditRequestShape(message: string): boolean {
  if (typeof message !== 'string' || message.trim().length === 0) return false;
  const carriesEditVerb =
    EDIT_GRAPH_POSITIVE_REGEX.test(message) ||
    WARRANT_EXTRA_EDIT_VERB_PATTERNS.some((re) => re.test(message));
  if (!carriesEditVerb) return false;
  // The read-marker guard and the two question-shape suppressors, in the same
  // combination route-v2 applies at the edit_graph door.
  if (EDIT_GRAPH_NEGATIVE_REGEX.test(message)) return false;
  if (isAnalyticalQuestion(message)) return false;
  if (isStateQueryQuestionShape(message)) return false;
  return true;
}

/**
 * Which of the three ratified sources authorised this turn to mutate.
 *
 *  - `message_signal`      — the user's own words carry a mutation instruction.
 *  - `typed_mutation_chip` — the user clicked a chip whose WIRE TYPE is a
 *                            mutation (`chip.action_type` ∈ the mutation
 *                            action types). A click on a typed mutation chip
 *                            IS the request; there is no text to read.
 *  - `confirm_resume`      — the turn is resuming a proposal or held op the
 *                            user already confirmed. The warrant was given on
 *                            the turn that emitted it.
 *
 * A plain-message chip (no `action_type`) is NOT a source in its own right:
 * it replays a MESSAGE through the ordinary pipeline, so it is judged by
 * `message_signal` like anything else. That is deliberate and load-bearing —
 * the calibration confirm chip ("Use 70%") replays "Set <factor> to 70%.",
 * which carries a mutation signal, so the calibration flow keeps working
 * through the message half rather than through a blanket chip exemption.
 */
export type MutationWarrantSource =
  | 'message_signal'
  | 'typed_mutation_chip'
  | 'confirm_resume';

export type MutationWarrant =
  | { readonly granted: false }
  | { readonly granted: true; readonly source: MutationWarrantSource };

/**
 * The turn ingress the warrant is derived from. Everything here is known
 * before the model is consulted.
 */
export interface MutationWarrantInput {
  /** The user's message text. */
  readonly message: string;
  /** `payload.source` — 'composer' | 'chip' | 'chip_click' | 'retry'. */
  readonly turnSource: string | undefined;
  /** `payload.chip?.action_type` — the chip's WIRE TYPE, not its copy. */
  readonly chipActionType: string | undefined;
  /**
   * True when this turn resumed a pending action / held proposal the user
   * confirmed. Derived by the caller from the executor's own
   * `consumedPendingAction`, never guessed from text.
   */
  readonly isConfirmResume: boolean;
  /**
   * ⭐ The resolved node labels of the model this turn is about, used to
   * QUOTE-MASK the message before the deliberative frame is read.
   *
   * ⚠ LOAD-BEARING, AND MEASURED. Of 1,564 mutating turns, THREE carry a
   * deliberative frame and TWO of those are FALSE POSITIVES — a user's graph
   * contains a node labelled `"What should we do?"` and the frame pattern
   * matches inside the QUOTED LABEL. Quote-masked, the true number is 1 of
   * 1,564, and that one IS the harm. Without these labels this term would tax
   * two legitimate mutations to catch one.
   *
   * Optional because most callers hold no graph at the point they ask. Omitting
   * it masks nothing, which withholds MORE rather than less — the fail-safe
   * direction this module declares in its header.
   */
  readonly modelNodeLabels?: readonly string[];
}

/**
 * The V5 chip `action_type` values that are themselves mutations. Imported
 * shape rather than re-listed: `typed-chip-mutation-proposal.ts` is the
 * CEE-side authority for which typed chips carry an edit spec, and the
 * manifest spec asserts this set and `GRAPH_MUTATING_HANDLER_IDS` agree.
 */
export function isMutationChipActionType(
  actionType: string | undefined,
  mutationActionTypes: ReadonlySet<string>,
): boolean {
  return actionType !== undefined && mutationActionTypes.has(actionType);
}

/**
 * Did this turn carry an affirmative warrant to mutate the graph?
 *
 * Order is evidential, not preferential: a confirm-resume is the strongest
 * claim (the user clicked confirm on a change we showed them), then a typed
 * mutation chip (the click IS the instruction), then the message text.
 */
export function detectMutationWarrant(
  input: MutationWarrantInput,
  mutationActionTypes: ReadonlySet<string>,
): MutationWarrant {
  if (input.isConfirmResume) {
    return { granted: true, source: 'confirm_resume' };
  }
  const isChipTurn = input.turnSource === 'chip_click' || input.turnSource === 'chip';
  if (isChipTurn && isMutationChipActionType(input.chipActionType, mutationActionTypes)) {
    return { granted: true, source: 'typed_mutation_chip' };
  }
  // ⭐ ORDINARY TEXT ONLY FROM HERE — and the subordination is STRUCTURAL.
  // Both stronger sources have already returned above, so Term D cannot veto a
  // typed mutation chip or a confirmed hold. `hasStrongerThanTextWarrant`
  // states that same precedence as a value, for the edit-lane consumer that
  // cannot rely on this function's control flow.
  const ordinaryTextAuthority = resolveOrdinaryTextAuthority({
    message: input.message,
    modelNodeLabels: input.modelNodeLabels ?? [],
  });
  if (hasMutationWarrantSignal(input.message, ordinaryTextAuthority)) {
    return { granted: true, source: 'message_signal' };
  }
  return { granted: false };
}

/**
 * The demotion reply: a mutating proposal arrived on a turn the user never
 * asked to change anything, so it is OFFERED rather than applied.
 *
 * Composed HERE rather than by the model, for the same reason the
 * withheld-consent copy is: on the witnessed turn the model narrated an
 * "Applied" receipt for a change the user had not requested. A string built
 * from a template cannot narrate.
 *
 * It states the outcome in the FIRST clause. "Nothing has been changed" is
 * true by construction at this point — control has not reached a handler.
 *
 * ── INV-3: IT DESCRIBES WHAT THE PRODUCT DID, NEVER WHAT THE USER ASKED ────
 * ⚠⚠ THE SECOND CLAUSE USED TO READ "You did not ask me to edit the model, so
 * I have not." IT WAS WITHDRAWN 1 Sep 2026, AFTER THREE SIGHTINGS OF THE SAME
 * HARM ON THREE BUILDS:
 *   1. 20 Aug, fresh-guest walk — the product had ASKED for a missing effect
 *      value, the user answered, and this clause told them they had not
 *      (`outstanding-effect-ask-misroute.ts:15`);
 *   2. the consent-loop dead end — offer → the user says "yes" → "you did not
 *      ask me" (`__tests__/mutation-warrant-consent-parity.test.ts:727`);
 *   3. 1 Sep, deployed build — the user asked three times, was told they had
 *      not asked, in the same message that then offered them exactly what they
 *      had asked for. The clause CONTRADICTED THE REST OF ITS OWN MESSAGE.
 *
 * ⭐ THE FIX IS HERE, IN THE COPY, AND DELIBERATELY NOT IN THE PREDICATE.
 * `hasMutationWarrantSignal` above closes with a standing ruling: four rounds
 * and PR #1107 were burned trying to separate a scope fence from a retraction,
 * and no further lexical rule will settle it. So the gate WILL keep missing a
 * real instruction sometimes. A reply that merely declines to write survives
 * that; a reply that also asserts the user never spoke turns every residual
 * predicate miss into an insult. Removing the assertion makes the residual
 * error BENIGN IN BOTH DIRECTIONS, and costs no new predicate.
 *
 * WHAT MUST SURVIVE, pinned as TWIN A in the spec: the no-write disclosure
 * still fires ("Nothing has been changed." first), and the change is still
 * OFFERED rather than applied. TWIN B pins the other direction — the copy
 * asserts nothing about what the user did or did not ask for. The estate had
 * already ratified this rule elsewhere and simply never applied it here:
 * `coaching/pick-defaulted-assumptions.ts:217`.
 *
 * ── INV-2 (ROADMAP 2.659 rider) ───────────────────────────────────────────
 * `residualDisclosure` carries the second sentence for the REPAIR shape: the
 * `add_constraint` idempotency key is `(node_id, operator)`, so a proposal
 * whose operator differs from an existing constraint on the same node CANNOT
 * update it — it can only append, leaving the defective row in place. The
 * walk witnessed exactly that (one unevaluable constraint became two, both
 * blamed on "conditions you set"). Where the product cannot repair, it must
 * SAY SO rather than let the user believe the old row is gone. The
 * remove/replace capability itself is ROADMAP 2.659, not this fix.
 */
/**
 * The closing PROMISE, named once so no reader has to re-spell it (trap 12).
 *
 * ⛔ IT IS HONOURABLE ONLY WHERE THE SAME TURN PERSISTS AN
 * `apply_proposed_change` PENDING. Acceptance is handled by
 * `tryShortConfirmResume`, which replays a STORED `inline_patch`; with nothing
 * stored, a "yes" has nothing to resume and the user has been told the product
 * was ready to act. Use `withdrawUnresumableOfferClose` wherever the emitting
 * branch has declined to persist one.
 */
export const MUTATION_OFFER_CLOSING_PROMISE = 'Say the word and I will make it.';

/**
 * What the product says instead when it has decided NOT to keep the change.
 *
 * It still opens with the no-write disclosure (INV-3 above is untouched), still
 * asserts nothing about what the user did or did not ask for, and closes on a
 * move the user can actually make rather than on a promise nothing can honour.
 * The estate already ratified this shape for the sibling branch that refuses an
 * under-specified offer — `buildIncompleteOfferRefusalText`, PR #1491.
 *
 * ⛔⛔ IT MAKES NO CLAIM ABOUT SESSION STATE, AND THAT IS THE LOAD-BEARING PART.
 * The first version of this constant closed "…so nothing is waiting on your
 * reply…". That is a claim about the pendings THE COMMIT PERSISTS, and the only
 * set the caller can see is `demotionPending` — the pendings THIS BRANCH minted.
 * They are not the same set:
 *
 *   `turn-executor.ts:1695`    every `commitTurn` threads
 *                              `priorPendingActions: context.most_recent_pending_actions`
 *   `commit.ts:1289-1310`      `finalPendings = [...chipDerivedPending, ...survivingPrior]`
 *   `commit.ts:565-571`        the hash-invalidation rule requires a NON-EMPTY
 *                              `currentGraphHash`; the `no_graph_hash` branch
 *                              has none, so a prior proposal is never
 *                              invalidated there
 *
 * MEASURED, three-turn journey, one instrument: T1 offers with a graph and mints
 * an `apply_proposed_change` · T2 has no usable graph, hits
 * `emit_refused:no_graph_hash`, persists `["apply_proposed_change"]` and SAID
 * "nothing is waiting on your reply" · T3's bare "yes" returned "Applying: Add
 * this limit. Added constraint: Customer Churn Rate must be at most 7%." and
 * wrote the graph. A denial with a write behind it — which moves the user's
 * model of what the product will do, where the promise it replaced merely did
 * nothing.
 *
 * ⛔ AND FEEDING THE GUARD THE PERSISTED SET IS WORSE, not better. MEASURED on
 * the same journey with `[...demotionPending, ...context.most_recent_pending_actions]`
 * passed to `withdrawUnresumableOfferClose`: the length test then passes, so the
 * promise is KEPT — turn 2 said "a limit keeping "Customer Churn Rate" at or
 * below 7 … Say the word and I will make it." and the "yes" returned "Added
 * constraint: Customer Acquisition Cost must be at most 500 GBP." A promise
 * about one change, honoured by writing another, with a receipt. That is the
 * `d8a908b3` class exactly. The guard's boolean answers "is anything resumable?"
 * and the sentence's referent is "THIS change" (trap 21) — do not reconcile them
 * by widening the set. Widening it would also have to re-derive
 * `computeSurvivingPriorPendingsDetailed` (five rules, `nowMs` and
 * `consumedPendingRefs` included) at a site that runs BEFORE the commit, which
 * is the hand-maintained mirror this module exists to avoid (trap 12).
 *
 * A sentence that makes no claim about a set cannot be wrong about one. Pinned
 * by the discriminating pair and the journey in
 * `__tests__/offer-without-pending-wiring.test.ts`.
 */
export const MUTATION_OFFER_UNRESUMABLE_CLOSE =
  'I could not put it forward as something you can confirm — tell me what ' +
  'you would like changed and I will take another look.';

export function buildMutationWarrantDemotionText(
  changeDescription: string,
  residualDisclosure: string | null,
): string {
  const opening =
    `Nothing has been changed. I want to confirm this with you before I edit ` +
    `the model, and ${changeDescription} looks like it would help. ` +
    `${MUTATION_OFFER_CLOSING_PROMISE}`;
  return residualDisclosure === null ? opening : `${opening} ${residualDisclosure}`;
}

/**
 * Withdraw the closing promise from a demotion text whose branch persisted no
 * resumable pending.
 *
 * ⭐ DERIVED, NEVER MIRRORED — and the reason is measured history. PR #1491
 * ruled this exact class for ONE branch and hand-wrote the remedy into it; the
 * three siblings beside it kept the promise for another three weeks. A caller
 * that decides the copy by restating the persistence decision will drift from
 * it again the next time a branch is added. Callers pass the PENDINGS THEY ARE
 * ABOUT TO COMMIT, so the copy cannot disagree with what was kept.
 *
 * ⛔ NOT A WIDER RECOGNISER. Commit `d8a908b3` withdrew that recommendation: a
 * held change replays entirely from its stored patch and never re-reads the
 * message, so widening the confirmation predicate would apply the OFFER's value
 * and silently discard one the user restated — with a receipt. The defect is
 * that the offer was made, not that the acceptance was refused.
 *
 * ⚠ SCOPED TO THE V5 DEMOTION GATE BY ITS CALLERS, deliberately. Two lanes, two
 * questions (trap 21) — this must not be applied globally.
 *
 * ⛔ `persistedPendings` IS THIS BRANCH'S SET, NOT THE COMMIT'S. Callers pass
 * `demotionPending`. The commit persists `demotionPending ∪ survivors(prior)`,
 * so a non-empty result here does NOT mean the session holds nothing. That is
 * exactly why `MUTATION_OFFER_UNRESUMABLE_CLOSE` states nothing about session
 * state — see its docblock for the measurement, and for why widening this
 * parameter makes the product promise one change and write another.
 *
 * ── EVERY CALLER OF `buildMutationWarrantDemotionText`, AND ITS STATUS ──────
 * Derived at this tip with `rg -a` over `src/` (contrast control:
 * `buildWarrantDemotion`, 4 files — the instrument is not blind).
 *
 *   `turn-executor.ts:11476`        `!demotion.ok` — GUARDED by this function
 *   `turn-executor.ts:11486`        `no_graph_hash` — GUARDED by this function
 *   `turn-executor.ts:11510`        emit success / refused — GUARDED (a success
 *                                   keeps the promise: `demotionPending` is
 *                                   non-empty, so the guard is a no-op)
 *   `edit-graph-dispatch.ts:3873`   EMITTER, deliberately LEFT ALONE. Ruled
 *                                   (PR #1583) and pinned by
 *                                   `edit-graph-dispatch-ordinary-text-authority.test.ts:177`:
 *                                   there the handler really did produce a
 *                                   mutation the gate withheld, so a restated
 *                                   instruction IS honourable through the
 *                                   ordinary edit path.
 *   `explicit-constraint-edit.ts:72` NOT AN EMITTER — a RECOGNISER. It rebuilds
 *                                   the offer text and grants a write on
 *                                   `message.startsWith(rendered)`
 *                                   (`:64-79`), needing no stored pending
 *                                   because it rebuilds the proposal from the
 *                                   message. It therefore renders the text WITH
 *                                   the promise, and a user who copies back a
 *                                   WITHDRAWN offer can no longer match it —
 *                                   which is correct, since a withdrawn offer
 *                                   was never put forward. Nothing here changes
 *                                   what it renders. ⚠ STATUS: coupled,
 *                                   correct-by-construction, UNWITNESSED — it
 *                                   needs a granted warrant, a single resolved
 *                                   target and a matching quantity/unit on the
 *                                   restating turn. Recorded, not fixed.
 */
export function withdrawUnresumableOfferClose(
  text: string,
  persistedPendings: readonly unknown[],
): string {
  if (persistedPendings.length > 0) return text;
  if (!text.includes(MUTATION_OFFER_CLOSING_PROMISE)) return text;
  return text.replace(MUTATION_OFFER_CLOSING_PROMISE, MUTATION_OFFER_UNRESUMABLE_CLOSE);
}

/**
 * The INV-2 residual sentence, when a proposed constraint cannot replace the
 * one already on the same node.
 *
 * Deliberately names what SURVIVES, not what is added: the user's complaint
 * in the walk was not that a constraint appeared, it was that the broken one
 * stayed and nothing said so.
 */
export function buildResidualConstraintDisclosure(existingLabel: string | null): string {
  const subject =
    existingLabel === null || existingLabel.trim().length === 0
      ? 'the limit already on that factor'
      : `"${existingLabel.trim()}"`;
  return (
    `Note that this would be a second limit: I cannot yet change or remove ` +
    `${subject}, so it would stay in place alongside the new one.`
  );
}
