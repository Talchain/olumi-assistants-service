# Olumi OpenAI AI Architecture — canonical entry point

**Updated:** 24 September 2026  
**Status:** Navigation pointer; the earlier 22 September architecture is historical.

## Current architecture

[Olumi OpenAI Technical Architecture — Canonical SSOT v2.0](./architecture/Olumi_OpenAI_Technical_Architecture_SSOT_v2_0.md) is the current consolidated architecture. It supersedes conflicting OpenAI architecture, routing and prompt-topology directions in this older document while preserving governing graph/state, boundary, quality and scientific contracts.

OpenAI Architecture owns the architecture. Release Control retains programme priorities, integration, current serving configuration, candidate acceptance and promotion. Issue `Talchain/olumi-programme-docs#63` is the live coordination channel. Source/PR/served evidence, not an old task snapshot, establishes current implementation.

## Preserved history and evidence

[Read the complete 22 September architecture and banked evidence](https://github.com/Talchain/olumi-programme-docs/blob/4961b2d174e32baaef0bf0aad8443e08ec74e563/openai/OPENAI_AI_ARCHITECTURE_SSOT.md).

Historical blob: `cca708827db2b60f198cd4a4c2c5bd7580c8049e`.

This pointer prevents competing active architecture documents. It does not restart workstreams, change provider or production configuration, authorise paid tests, or declare a candidate released.
