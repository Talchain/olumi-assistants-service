import { goalScopeAnalysisMeaning } from '../../schemas/goal-scope.js';
/**
 * V5 Phase 1.5 — deterministic graph hash.
 *
 * Computes a stable 16-char hex hash of a graph's node + edge identity, for
 * routing-log telemetry and future staleness-comparison work. The hash input
 * is the sorted list of node IDs and (from, to) edge pairs — not the full
 * structural data — so additive fields (observed_state drift, strength
 * refinements) do NOT change the hash. That is deliberate: Phase 1.5 uses the
 * hash only as a stable identity marker for a given graph shape; downstream
 * staleness logic compares identity against analysis-time snapshots and
 * should not trip on cosmetic edits.
 *
 * The hash is kept OUT of ContextPack (plan correction #3). Consumers that
 * need it — routing log, future staleness comparator — read it from the
 * TurnExecutor scope where this helper is called.
 */

import { createHash } from 'node:crypto';

import { stableStringify } from '../../orchestrator/context/stable-stringify.js';
import type { GraphStateIngress } from '../boundary/request-extensions.js';
import { CANONICAL_GRAPH_HASH_NESTED_PROJECTION as VOCABULARY } from '@talchain/schemas/boundary';
import { resolveGoalDirection, resolveGoalThresholdStrict } from '../goal-target/goal-direction.js';

/** Length of the returned hex prefix. 16 gives collision odds ~1 in 2^64. */
const HASH_HEX_LENGTH = 16;

/**
 * Compute a deterministic 16-char hex hash of graph identity. Returns null
 * when the graph is null, undefined, or structurally empty (no nodes AND no
 * edges) — a null hash is indistinguishable from "no graph present" for the
 * routing-log consumer.
 *
 * Canonicalisation:
 *   1. Copy nodes + edges into plain identity records (strip passthrough
 *      fields — we hash identity, not structure)
 *   2. Sort nodes by id, edges by (from, to)
 *   3. stableStringify (recursive key sort)
 *   4. SHA-256, take first 16 hex chars
 */
export function computeDeterministicGraphHash(
  graph: GraphStateIngress | null | undefined,
): string | null {
  if (!graph) return null;

  const nodes = graph.nodes;
  const edges = graph.edges;
  if (nodes.length === 0 && edges.length === 0) return null;

  const nodeIdentity = nodes
    .map((n) => ({ id: n.id }))
    .sort((a, b) => a.id.localeCompare(b.id));

  const edgeIdentity = edges
    .map((e) => ({ from: e.from, to: e.to }))
    .sort((a, b) => {
      const fromCmp = a.from.localeCompare(b.from);
      return fromCmp !== 0 ? fromCmp : a.to.localeCompare(b.to);
    });

  const canonical = stableStringify({ nodes: nodeIdentity, edges: edgeIdentity });
  return createHash('sha256').update(canonical).digest('hex').slice(0, HASH_HEX_LENGTH);
}

/**
 * Compute a deterministic 16-char hex hash of all graph fields that AFFECT
 * analysis output. Used by V5 freshness derivation: comparing the hash at
 * `run_analysis` time against the hash on the current turn determines whether
 * the prior analysis is still valid.
 *
 * Distinct from `computeDeterministicGraphHash` (above), which deliberately
 * hashes only topology for routing-log identity. This function MUST capture
 * any field whose mutation would change analysis results, while excluding
 * cosmetic / provenance / display fields so label-only edits do not trigger
 * false-stale freshness.
 *
 * Canonical input projection (whitelist — anything not listed is excluded):
 *
 *   nodes: sorted by id, each → {
 *     id, kind, category, factor_type, is_baseline,
 *     observed_state: { value, baseline, cap, source, unit, raw_value, std },
 *     goal_threshold, goal_threshold_raw, goal_threshold_cap,
 *     intercept,
 *     prior: { distribution, range_min, range_max },
 *     encoding_map,
 *     nonlinear_identity (C46 carrier, as stored),
 *     scale_frame, goal_threshold_frame, goal_direction, quantity_frame, analysis_participation,
 *     interventions: per-factor { value, value_type, encoding_map,
 *                                  target_match: { node_id } }
 *   }
 *   edges: sorted by (from, to), each → {
 *     from, to, edge_type,
 *     strength: { mean, std },
 *     exists_probability, effect_direction,
 *     provenance: { source, magnitude, natural_effect: { amount_unit } }
 *   }
 *   options: sorted by id, each → {
 *     id, status, is_baseline,
 *     interventions: per-factor (as above),
 *     raw_interventions: per-factor (only when status !== 'ready')
 *   }
 *   goal_node_id
 *   goal_constraints: passed through stableStringify
 *   run_semantics: { goal_direction, goal_direction_provenance, goal_threshold_strict } — DERIVED
 *                  (`resolveGoalDirection`, `resolveGoalThresholdStrict`): the direction and strictness the run sends
 *
 * Excluded (cosmetic / provenance / display):
 *   labels, descriptions, display_value, provenance, provenance_display,
 *   origin, observed_state.{extractionType, reviewed_by_user, elicited_from},
 *   intervention.{unit, source, reasoning, value_confidence, display_value},
 *   target_match.{match_type, confidence}, edge.validation, edge.defaulted,
 *   option.{description, unresolved_targets, user_questions, brief_quote}.
 *
 * Also intentionally EXCLUDED — Monte Carlo configuration parameters
 * passed to PLoT alongside the graph (`seed`, `n_samples`, request_id):
 * these tune the simulation reproducibility / sample count, not the
 * model itself. Two analyses against the same graph with different
 * seeds should be considered freshness-equivalent. Including them
 * would over-trigger `stale` on every rerun-with-new-seed without
 * any user-visible model change.
 */
export function computeAnalysisAffectingGraphHash(
  graph: GraphStateIngress | null | undefined,
): string | null {
  const full = computeAnalysisAffectingGraphHashSha256(graph);
  return full === null ? null : full.slice(0, HASH_HEX_LENGTH);
}

/**
 * Full SHA-256 content address of the SAME analysis-affecting projection.
 *
 * Freshness keeps its established 16-hex token above. Durable model-version
 * identities use this collision-resistant 64-hex form. Both delegate to one
 * projection implementation below, so there is no second normaliser.
 */
export function computeAnalysisAffectingGraphHashSha256(
  graph: GraphStateIngress | null | undefined,
): string | null {
  if (!graph) return null;

  const nodes = graph.nodes;
  const edges = graph.edges;
  const options = (graph as { options?: unknown }).options;
  const goalNodeId = (graph as { goal_node_id?: unknown }).goal_node_id;
  const goalConstraints = (graph as { goal_constraints?: unknown }).goal_constraints;

  if (
    nodes.length === 0 &&
    edges.length === 0 &&
    !Array.isArray(options) &&
    goalNodeId === undefined
  ) {
    return null;
  }

  const canonical = stableStringify({
    nodes: nodes.map(projectNode).sort((a, b) => a.id.localeCompare(b.id)),
    edges: edges
      .map(projectEdge)
      .sort((a, b) => {
        const fromCmp = a.from.localeCompare(b.from);
        return fromCmp !== 0 ? fromCmp : a.to.localeCompare(b.to);
      }),
    options: Array.isArray(options)
      ? options.map(projectOption).sort((a, b) => a.id.localeCompare(b.id))
      : [],
    goal_node_id: typeof goalNodeId === 'string' ? goalNodeId : null,
    goal_constraints: Array.isArray(goalConstraints) ? goalConstraints : [],
    // ⭐ THE DERIVED RUN SEMANTICS (AIQ #72 5881600412, R3 5881451910): the direction the run SENDS is derived — the
    // user's held comparator for a proven ceiling, else the goal LABEL's classifier. `label` stays out of the stored
    // vocabulary, so a growth→reduce rename would flip the objective under an unchanged hash; hashing the derived
    // answer (not the label) moves the hash exactly when the sent direction moves, and a cosmetic rename does not.
    run_semantics: runSemantics(graph, goalNodeId),
  });
  return createHash('sha256').update(canonical).digest('hex');
}

function runSemantics(graph: unknown, goalNodeId: unknown): Record<string, unknown> {
  const direction = typeof goalNodeId === 'string' ? resolveGoalDirection(graph, goalNodeId) : undefined;
  return {
    goal_direction: direction?.direction ?? null,
    goal_direction_provenance: direction?.provenance ?? null,
    // R3 5881451910 / AIQ 5881600412: whether the run counts reaching the target itself as NOT met (ISL #209, CEE #2260).
    goal_threshold_strict: typeof goalNodeId === 'string' ? resolveGoalThresholdStrict(graph, goalNodeId) : false,
  };
}

function pickDefined<T extends Record<string, unknown>>(
  source: Record<string, unknown>,
  keys: readonly string[],
): T {
  const out: Record<string, unknown> = {};
  for (const key of keys) {
    const value = source[key];
    if (value !== undefined) out[key] = value;
  }
  return out as T;
}

function projectObservedState(raw: unknown): Record<string, unknown> | undefined {
  if (!raw || typeof raw !== 'object') return undefined;
  // ⭐ THE PUBLISHED VOCABULARY, IMPORTED — never re-spelled here (schemas 0.62.0, projection version 3; Shared Data
  // row 1, #72 5881225605). `source` (whose a value is: ISL's base owner, CEE's per-limit verdict), `unit` / `raw_value`
  // (the PLoT wire: `level-limit-baseline.ts`) and `std` (a stated spread) all decide the run. Live on served f79119b the
  // same 3.2% moving from Olumi's estimate to the user's left the old hand-kept list's hash unchanged, so a Run whose
  // verdict was `estimate_only` stayed CURRENT while a rerun gave `scored`.
  return pickDefined(raw as Record<string, unknown>, VOCABULARY.node.observed_state_fields);
}

function projectPrior(raw: unknown): Record<string, unknown> | undefined {
  if (!raw || typeof raw !== 'object') return undefined;
  return pickDefined(raw as Record<string, unknown>, [
    'distribution',
    'range_min',
    'range_max',
  ]);
}

/**
 * `RawInterventionValue` admits `number | string | boolean`, so one quantity can
 * arrive spelled two ways (`95000` and `"95000"`). Two spellings of the SAME
 * figure must hash alike, or the product reports a change nobody made.
 *
 * ⚠ NUMERIC STRINGS ONLY, AND ONLY ON AN EXACT ROUND TRIP. A categorical raw
 * is a CODE, not a magnitude (`"UK"`, `"enterprise"`), and coercing one would
 * either produce `NaN` or collapse two categories into one identity. Anything
 * that does not round-trip is preserved verbatim.
 */
function normaliseRawValueForIdentity(raw: unknown): unknown {
  if (typeof raw !== 'string') return raw;
  const trimmed = raw.trim();
  if (trimmed === '') return raw;
  const asNumber = Number(trimmed);
  return Number.isFinite(asNumber) && String(asNumber) === trimmed ? asNumber : raw;
}

function projectIntervention(raw: unknown): Record<string, unknown> | undefined {
  if (!raw || typeof raw !== 'object') return undefined;
  const r = raw as Record<string, unknown>;
  const out: Record<string, unknown> = {};
  if (r.value !== undefined) out.value = r.value;
  if (r.value_type !== undefined) out.value_type = r.value_type;
  if (r.encoding_map !== undefined) out.encoding_map = r.encoding_map;
  // ⭐ THE NATIVE QUANTITY AND ITS UNIT — in the identity because a consumer
  // reads them for a DISPLAYED verdict.
  //
  // Measured before this line existed, with a live positive control in the
  // same run: an option's `raw_value` moving 95,000 -> 250,000 produced a
  // BYTE-IDENTICAL hash (`d4384a59464a5724` both times), while a `value`
  // change 0.7 -> 0.85 moved it. So a cost could cross a £200,000 limit and
  // the product would still report the stored analysis as current.
  //
  // Tolerable only while nothing consumes the native. A limit check does, so
  // the identity has to account for it BEFORE that consumer is enabled rather
  // than after — otherwise the freshness line on screen is asserting over a
  // verdict it cannot see change.
  //
  // ⚠ ONE-TIME COST, DISCLOSED: a stored graph already carrying `raw_value`
  // hashes differently from here on, so those scenarios read STALE once. That
  // is the honest direction; they were being called fresh on an identity that
  // ignored a real field.
  //
  // ⚠⚠ `unit` ENTERS ONLY BESIDE A NATIVE VALUE, AND THE EXISTING SPEC IS WHY.
  // `graph-hash.test.ts` asserts "intervention unit / source / reasoning /
  // display_value / target_match.confidence → hash unchanged", and that
  // decision is CORRECT for the encoded case it was written for: beside an
  // encoded `value: 100`, the unit is metadata ABOUT the number the engine
  // computes on, so GBP→USD changes no result. Beside a NATIVE `raw_value` the
  // unit is part of the quantity itself — 95,000 GBP and 95,000 USD are
  // different amounts to a limit check. Two meanings of one field name
  // (trap 21), so the projection distinguishes them rather than overriding the
  // older rule. A unit with no native beside it still hashes to nothing.
  if (r.raw_value !== undefined) {
    out.raw_value = normaliseRawValueForIdentity(r.raw_value);
    if (r.unit !== undefined) out.unit = r.unit;
  }
  if (r.target_match && typeof r.target_match === 'object') {
    const tm = r.target_match as Record<string, unknown>;
    if (tm.node_id !== undefined) out.target_match = { node_id: tm.node_id };
  }
  return out;
}

function projectInterventionRecord(
  raw: unknown,
): Record<string, Record<string, unknown> | undefined> | undefined {
  if (!raw || typeof raw !== 'object') return undefined;
  const r = raw as Record<string, unknown>;
  const out: Record<string, Record<string, unknown> | undefined> = {};
  for (const factorId of Object.keys(r)) {
    const projected = projectIntervention(r[factorId]);
    if (projected !== undefined) out[factorId] = projected;
  }
  return out;
}

interface NodeProjection {
  id: string;
  [key: string]: unknown;
}

function projectNode(raw: unknown): NodeProjection {
  const r = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
  const out: NodeProjection = { id: typeof r.id === 'string' ? r.id : '' };
  const scope = goalScopeAnalysisMeaning(r.goal_scope);
  if (scope !== undefined) out.goal_scope = scope;

  // The published node vocabulary (schemas 0.62.0): the 0.61.0 frame / direction / quantity fields, `scale_frame`
  // (read with `unit` / `raw_value` by `percentLimitFrameProvable`), the C46 `nonlinear_identity` carrier and
  // `analysis_participation` (`retained_excluded` removes the node from the run). `id` is set above.
  for (const key of VOCABULARY.node.fields) {
    if (key !== 'id' && r[key] !== undefined) out[key] = r[key];
  }

  const observed = projectObservedState(r.observed_state);
  if (observed !== undefined && Object.keys(observed).length > 0) {
    out.observed_state = observed;
  }

  const prior = projectPrior(r.prior);
  if (prior !== undefined && Object.keys(prior).length > 0) {
    out.prior = prior;
  }

  const interventions = projectInterventionRecord(r.interventions);
  if (interventions !== undefined && Object.keys(interventions).length > 0) {
    out.interventions = interventions;
  }

  return out;
}

interface EdgeProjection {
  from: string;
  to: string;
  [key: string]: unknown;
}

function projectEdge(raw: unknown): EdgeProjection {
  const r = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
  const out: EdgeProjection = {
    from: typeof r.from === 'string' ? r.from : '',
    to: typeof r.to === 'string' ? r.to : '',
  };

  if (r.edge_type !== undefined) out.edge_type = r.edge_type;
  if (r.exists_probability !== undefined) out.exists_probability = r.exists_probability;
  if (r.effect_direction !== undefined) out.effect_direction = r.effect_direction;

  if (r.strength && typeof r.strength === 'object') {
    const s = r.strength as Record<string, unknown>;
    const strength: Record<string, unknown> = {};
    if (s.mean !== undefined) strength.mean = s.mean;
    if (s.std !== undefined) strength.std = s.std;
    if (Object.keys(strength).length > 0) out.strength = strength;
  }

  // schemas 0.62.0 (AIQ 5881815357): who sized the link and the unit of its natural size decide withhold vs score in
  // the placeholder-parts predicate (DL 5881593118); `source: 'user_specified'` wins over `magnitude` at read time.
  if (r.provenance && typeof r.provenance === 'object') {
    const p = r.provenance as Record<string, unknown>;
    const provenance: Record<string, unknown> = pickDefined(p, VOCABULARY.edge.provenance_fields);
    if (p.natural_effect && typeof p.natural_effect === 'object') {
      const ne = pickDefined((p.natural_effect as Record<string, unknown>), VOCABULARY.edge.provenance_natural_effect_fields);
      if (Object.keys(ne).length > 0) provenance.natural_effect = ne;
    }
    if (Object.keys(provenance).length > 0) out.provenance = provenance;
  }

  return out;
}

interface OptionProjection {
  id: string;
  [key: string]: unknown;
}

function projectOption(raw: unknown): OptionProjection {
  const r = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
  const out: OptionProjection = { id: typeof r.id === 'string' ? r.id : '' };

  if (r.status !== undefined) out.status = r.status;
  if (r.is_baseline !== undefined) out.is_baseline = r.is_baseline;

  const interventions = projectInterventionRecord(r.interventions);
  if (interventions !== undefined && Object.keys(interventions).length > 0) {
    out.interventions = interventions;
  }

  // Only include raw_interventions when option is not yet ready — that signals
  // the encoding state still affects analysis preconditions.
  if (r.status !== 'ready' && r.raw_interventions && typeof r.raw_interventions === 'object') {
    out.raw_interventions = r.raw_interventions;
  }

  return out;
}
