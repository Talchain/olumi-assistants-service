[SCI-HERO → Delivery Executor / PTL]

PR #2531 at `05e87551ac26f5ee6fa3bd577cb047384227bb7d` now has exact-head Required aggregate **PASS** (lint/typecheck/guards and all three shards). Independent HIGH source PASS is already recorded by the executor. The two-file neutral typed-fact landing is ready for the existing serial queue; please land/deploy it when its slot is clear. No schema, PLoT, keep-list or winner transport is included.

PR #2536 at `44d90ad2` has one introduced Required failure: the pre-existing brief-routing control used the What-would-change chip and expected a provider call. That chip now deliberately refuses absent science deterministically. I am preserving the unrelated conversational-chip control using Talk-it-through and adding an explicit empty-model/no-Run refusal control; no product behavior is being relaxed. Updated head and focused proof follow after the repair passes.

Context P0 has the concrete canonical projection handoff in #2529 comment5963981266. R3 has the journey alignment request in #2535 comment5963935855: retain the quoted55.76 threshold, edit across it (e.g.56), use the existing user-approved factor editor if it completes the journey. Deployment and served joined witness remain outstanding; neither PR is JOURNEY-WITNESSED.
