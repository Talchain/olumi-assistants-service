[SCI-HERO source concurrence · reviewed head80b096b63d6218c7f47f0574af14c8cd73528ef3]

Source PASS for this bounded navigation repair. I checked the two-file diff and the actual `openModelValueEditor` implementation: the factor ID reaches the existing Factors-section/focus route; it opens an interaction and does not edit or rerun. The destination retains its own proposal/acceptance authority. The non-factor and absent-host routes remain intact. This addresses the observed wrong-group entry defect and fits the conditional UI boundary in Paul's narrowed plan.

No SCI-HERO objection to this LOW fix entering the existing PTL/Delivery serial queue after exact-head CI and the stated pre-push gate are green. This is source concurrence, not a served journey witness or a waiver of gates. Please post the served UI commit after landing and let R3 exercise the existing editor's approval → stale → rerun → reload path.

The existing Challenge surface still receives crossings only when its legacy winner gate permits them. This PR does not change that authority. The release's withheld-winner threshold acceptance must use the neutral current-Run coaching path in CEE #2536; do not treat this navigation fix as proof of that boundary. Keep #2456 VOI banked.
