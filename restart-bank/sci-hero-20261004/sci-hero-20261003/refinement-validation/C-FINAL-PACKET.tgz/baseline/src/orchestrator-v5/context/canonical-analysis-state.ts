/**
 * V5 Canonical Analysis State — the single composed verdict on
 * "is there usable analysis, and is it current?".
 *
 * ## Why this module exists
 *
 * Today the same question is answered by independent code paths that can
 * disagree:
 *   - `deriveAnalysisFreshness(priorFacts, hash)` — graph-hash-aware
 *     verdict, but consumes prior-turn facts only.
 *   - the chip floor's `hasAnyRunAnalysisFact` — presence check that ORs
 *     current-turn handlerFacts AND priorFacts.
 *   - canonical analysis-ready payload — status + blockers, graph-projected.
 *
 * Concrete symptom: on the turn `run_analysis` just ran,
 * `hasAnyRunAnalysisFact === true` while `deriveAnalysisFreshness` returns
 * `'none'` — the new fact is in `handlerFacts`, which freshness never
 * sees. Chips, prose, reload and diagnostics can therefore contradict one
 * another ("no analysis yet" vs "analysis is stale").
 *
 * ## Composition, not duplication
 *
 * This module introduces NO new status/freshness vocabulary. The enums
 * come verbatim from `src/schemas/analysis-ready.ts`. The verdict is
 * COMPOSED from the existing canonical primitives:
 *   - `deriveAnalysisFreshness` / `selectRunAnalysisFact` /
 *     `selectDegradedRunAnalysisFact` (context/freshness.ts) for the
 *     fact-driven freshness verdict, the selected fact and degraded
 *     detection;
 *   - the canonical readiness payload for status + blockers.
 *
 * The unification fix for the documented split: current-turn handlerFacts
 * and prior-turn facts are merged into ONE ordered chain (current first =
 * newest) BEFORE deriving freshness, so the selector, the chip floor and
 * the freshness verdict all read one fact set and cannot disagree.
 *
 * ## Side-effect split
 *
 * `selectCanonicalAnalysisState` is a PURE function — no I/O, no
 * telemetry, no reads from disk or env. It mirrors `deriveAnalysisFreshness`
 * exactly: replacing it in tests is a function call, not a mock. The
 * CALLER decides when to emit the `v5.canonical_state.contradiction`
 * telemetry event (most call once per derivation; tests skip emitting).
 *
 * ## Usability is status-driven, contradictions fail loud
 *
 * Usability predicates derive from `status` + `freshness` + hashes, never
 * from raw blocker presence. `status === 'ready'` carrying advisory
 * `constraint_dropped` blockers is a BY-DESIGN combination on the shared
 * contract (the egress boundary injects informational constraint-drop
 * blockers onto an already-ready payload without recomputing status — see
 * src/cee/unified-pipeline/stages/boundary.ts and
 * src/cee/transforms/analysis-ready.ts). It must NOT downgrade usability.
 * Only ACTIONABLE blocker types co-occurring with `ready` (which a correct
 * producer would have already reflected as a non-ready status) are treated
 * as an integrity contradiction.
 */

import type { HandlerFact } from '@talchain/schemas/orchestrator';

import type {
  AnalysisFreshnessT,
  AnalysisReadyStatusT,
} from '../../schemas/analysis-ready.js';
import {
  deriveAnalysisFreshness,
  selectDegradedRunAnalysisFact,
  selectRunAnalysisFact,
  type FreshnessDerivation,
  type FreshnessReason,
} from './freshness.js';
import {
  compareAnalysedOptionIdentity,
  extractAnalysedLeaderId,
  extractAnalysedOptionIds,
  type OptionIdentityReason,
} from './option-identity.js';

/**
 * Contract version for the canonical analysis-state object. Bump on any
 * shape change. Internal/diagnostic only — NOT a UI-governed wire field.
 */
export const CANONICAL_ANALYSIS_STATE_VERSION = '1.0.0';

/**
 * Observable contradictions in the persisted analysis state. Carried in
 * `CanonicalAnalysisState.contradictions` and surfaced via the diagnostic
 * `_context_summary` + a caller-emitted telemetry event. Contradictions
 * are NEVER silently reconciled — predicates fail toward rerun/caveat.
 *
 *   scenario_claims_analysis_no_fact
 *     Persisted scenario state asserts an analysis exists, yet no
 *     successful run_analysis fact is selectable. Blocks (unusable).
 *
 *   status_ready_with_actionable_blockers
 *     Readiness reports `ready`, yet an ACTIONABLE blocker
 *     (missing_value / ambiguous_value / missing_connection) is present.
 *     A correct producer forces a non-ready status for actionable
 *     blockers, so this is a should-never-happen integrity violation.
 *     Advisory `constraint_dropped` blockers do NOT trigger it.
 *     Downgrades chips + forces rerun; prose stays usable (caveated).
 *
 *   fact_status_success_but_degraded_newer
 *     A newer run_analysis fact arrived in a non-success state while an
 *     older success would otherwise be presented as current. Downgrades
 *     chips + forces rerun; prose stays usable (caveated).
 *
 * NOT a contradiction: a successful fact whose run hash exists while the
 * current graph could not be hashed this turn (freshness
 * `current_graph_hash_unavailable`). That is a NORMAL, recoverable state —
 * an ordinary no-graph follow-up turn ("explain the result"), or
 * turn-executor's deliberate null-hash on a persisted-graph parse failure
 * ("stale-aware explain recovery"). At this layer we cannot distinguish it
 * from genuine corruption, and the benign case dominates, so it is handled
 * as freshness `unknown` (prose + follow-up usable, chips not, no rerun) —
 * SYMMETRIC with the `legacy_fact_missing_hash` flavour of `unknown`, never
 * a hard block.
 */
export type CanonicalContradiction =
  | 'scenario_claims_analysis_no_fact'
  | 'status_ready_with_actionable_blockers'
  | 'fact_status_success_but_degraded_newer';

/**
 * Blocker types that represent an ACTIONABLE gap the user must resolve
 * before analysis is trustworthy. `constraint_dropped` is intentionally
 * excluded — it is informational/advisory and rides along on otherwise
 * ready payloads by design.
 */
const ACTIONABLE_BLOCKER_TYPES: ReadonlySet<string> = new Set([
  'missing_value',
  'ambiguous_value',
  'missing_connection',
]);

/** The canonical analysis-ready status values (mirrors AnalysisReadyStatus). */
const ANALYSIS_READY_STATUSES: ReadonlySet<string> = new Set([
  'ready',
  'needs_user_mapping',
  'needs_encoding',
  'needs_user_input',
  'blocked',
]);

/**
 * Coerce a producer-supplied readiness status string to a known
 * AnalysisReadyStatus, or null for absent / unrecognised values. Different
 * producers type `status` differently (the canonical readiness projection uses
 * the enum; the egress-emit payload widens it to `string`), so we validate
 * here rather than trusting the inbound type.
 */
function coerceReadyStatus(raw: string | null | undefined): AnalysisReadyStatusT | null {
  if (raw != null && ANALYSIS_READY_STATUSES.has(raw)) {
    return raw as AnalysisReadyStatusT;
  }
  return null;
}

/**
 * Closed set of degraded (non-success) analysis statuses. The upstream PLoT
 * `analysis_status` is an OPEN string (run-analysis accepts any non-empty
 * value and still persists a fact), so we allowlist before the value enters
 * the redacted summary / any LLM-facing surface — an unrecognised upstream
 * token cannot inject free text. Unrecognised → 'other'; null → null.
 */
const KNOWN_DEGRADED_STATUSES: ReadonlySet<string> = new Set([
  'partial',
  'blocked',
  'failed',
  'degraded',
  'incomplete',
  'inconclusive',
  'error',
  'timeout',
  'cancelled',
  'unknown',
  'refused',
]);

function normaliseDegradedStatus(raw: string | null): string | null {
  // Defensive type guard: the declared input is `string | null`, but this
  // value originates from an upstream PLoT status read — guard against any
  // non-string slipping through an `as` cast so `.trim()` can never throw.
  if (typeof raw !== 'string') return null;
  const trimmed = raw.trim().toLowerCase();
  if (trimmed === '') return null;
  return KNOWN_DEGRADED_STATUSES.has(trimmed) ? trimmed : 'other';
}

/**
 * Minimal structural view of the readiness payload the selector reads.
 * Canonical and boundary `AnalysisReadyPayload` carriers satisfy it — the selector only needs status,
 * blockers, model adjustments and the goal node id. Kept structural so
 * the selector does not couple to any one producer's concrete type.
 */
/**
 * Read a blocker's `blocker_type` defensively. Blockers arrive either as
 * schema-typed `AnalysisBlocker[]` (from canonical readiness) or as
 * `unknown[]` (the egress-emit payload types them that way). This is the
 * single place that normalises both — returns null for any shape that does
 * not carry a string `blocker_type`.
 */
function readBlockerType(blocker: unknown): string | null {
  if (blocker !== null && typeof blocker === 'object' && 'blocker_type' in blocker) {
    const raw = (blocker as { blocker_type?: unknown }).blocker_type;
    return typeof raw === 'string' ? raw : null;
  }
  return null;
}

export interface ReadinessLike {
  /** Producer-supplied status; coerced to a known AnalysisReadyStatus (or
   *  null) internally, so a wider `string` from the egress payload is fine. */
  readonly status?: string | null;
  /** Blockers pass through verbatim; the selector only reads `blocker_type`
   *  (via readBlockerType), so any producer shape — schema `AnalysisBlocker`
   *  or the egress payload's `unknown[]` — is accepted without a cast. */
  readonly blockers?: readonly unknown[];
  /** Carried through verbatim; the selector never introspects adjustments. */
  readonly model_adjustments?: readonly unknown[];
  readonly goal_node_id?: string | null;
  /** The run-admission verdict (`admission.willProceed`) when the producer
   *  supplied it. `false` means a NEW run is not currently permitted — it says
   *  nothing about whether an EARLIER result exists or is usable. */
  readonly may_run?: boolean | null;
}

/**
 * The single composed canonical analysis state. Internal/full shape —
 * carries blocker + adjustment objects for consumers that need detail.
 * The redacted, leak-safe projection for diagnostics/harness is
 * {@link AnalysisStateSummary} (see {@link summariseCanonicalAnalysisState}).
 */
export interface CanonicalAnalysisState {
  readonly version: typeof CANONICAL_ANALYSIS_STATE_VERSION;

  // ── Vocabulary reused verbatim (no new enums) ──
  /** Structural readiness status, or null when no readiness was supplied. */
  readonly status: AnalysisReadyStatusT | null;
  /** Freshness verdict from `deriveAnalysisFreshness`. */
  readonly freshness: AnalysisFreshnessT;
  /** Stable reason code from `deriveAnalysisFreshness`. */
  readonly freshness_reason: FreshnessReason;

  // ── Selected-fact provenance (single source = the freshness derivation) ──
  readonly selected_fact_index: number | null;
  readonly computed_at: string | null;
  readonly graph_hash_at_run: string | null;
  readonly current_graph_hash: string | null;

  // ── Readiness detail where available ──
  readonly blockers: readonly unknown[];
  readonly model_adjustments: readonly unknown[];
  readonly goal_node_id: string | null;

  // ── Degraded/failed observability ──
  /** Status of the CURRENT degradation only: the latest run_analysis fact
   *  when it is a non-success that is NOT superseded by a newer success
   *  (i.e. no success exists, OR the degraded run is newer than the selected
   *  success). Null otherwise — an older failure sitting behind a newer
   *  success is historical, not current, so the field never reads as
   *  "currently degraded" when the most recent run actually succeeded. */
  readonly degraded_fact_status: string | null;

  // ── Contradictions (fail-loud, never silently reconciled) ──
  readonly contradictions: readonly CanonicalContradiction[];

  // ── Deterministic NAMED predicates (no vague single `usable`) ──
  /** Analysis exists and may be referenced in prose (stale → caveat). */
  readonly usableForProse: boolean;
  /** Analysis is fresh + trustworthy enough for result-exploration chips. */
  readonly usableForChips: boolean;
  /** Analysis exists to reference for follow-up handlers (fresh OR stale). */
  readonly usableForFollowupContext: boolean;
  /** A rerun affordance should be surfaced (stale or trust-downgraded). */
  readonly requiresRerun: boolean;
  /** Analysis is unusable — blocked status or a hard contradiction. */
  readonly blockedUnusable: boolean;

  // ── Option-identity guard observability (diagnostic only) ──
  /**
   * The option-identity comparison the freshness guard performed this turn, or
   * undefined when the guard did not run (flag off, or no selected fact to
   * compare). Counts + closed enums only — never option IDs or labels. Surfaced
   * via {@link AnalysisStateSummary}/`_context_summary` so debug evidence can
   * show whether option identity was checked, matched or diverged. Diagnostic
   * only — the verdict's EFFECT on freshness is already in `freshness` /
   * `freshness_reason`; this never drives behaviour.
   */
  readonly option_identity?: OptionIdentitySummary;
}

/**
 * Redacted record of the option-identity comparison (see option-identity.ts).
 * Counts + closed enums only — never the option IDs/labels themselves — so it
 * is safe on the diagnostic boundary.
 */
export interface OptionIdentitySummary {
  /** True when the guard ran (current graph option IDs supplied + a fact). */
  readonly checked: boolean;
  /** Verdict: true ⇒ analysed option identities consistent with the graph. */
  readonly match: boolean;
  readonly reason: OptionIdentityReason;
  readonly analysed_option_count: number;
  readonly current_option_count: number;
}

/**
 * Inputs to the canonical selector. All optional except the current graph
 * hash, which the caller computes via `computeAnalysisAffectingGraphHash`
 * on this turn's graph (null when no graph / unparseable).
 */
export interface SelectCanonicalAnalysisStateInput {
  /** Current-turn handler facts (may hold the run_analysis that JUST ran). */
  readonly handlerFacts?: readonly HandlerFact[];
  /** Prior-turn facts, newest-first per build-turn-context's loader. */
  readonly priorFacts?: readonly HandlerFact[];
  /** Structural readiness payload (status + blockers). */
  readonly readiness?: ReadinessLike;
  /** Hash of this turn's analysis-affecting graph fields, or null. */
  readonly currentGraphHash: string | null;
  /** Same current graph as the hash, for the selected Run's goal-unit snapshot. */
  readonly currentGraph?: unknown;
  /**
   * Current graph's option IDs for the option-identity freshness guard. Only
   * threaded by callers when `cee.optionIdentityFreshnessGuard` is on; left
   * `undefined` otherwise so the freshness derivation is byte-identical to the
   * pre-guard behaviour. See {@link deriveAnalysisFreshness}.
   */
  readonly currentGraphOptionIds?: readonly string[] | null;
  /** True when persisted scenario state asserts an analysis exists. */
  readonly scenarioClaimsAnalysis?: boolean;
  /**
   * CONTEXT/MEMORY V5 defect 4 — did the PRIOR-fact read succeed?
   *
   * `false` ONLY when `fetchPriorFacts` threw, in which case an empty unified
   * fact chain is uninformative rather than evidence of "never analysed".
   * Omitted ⇒ byte-identical to the pre-fix derivation, so an unwired caller
   * cannot be silently changed.
   *
   * Note the interaction with `handlerFacts`: the unified chain puts
   * current-turn facts FIRST, so a run_analysis that just ran is selected
   * regardless of this flag. The degraded branch is reachable only when
   * NEITHER source yielded a usable fact — which is exactly the ambiguous case.
   */
  readonly priorFactsReadOk?: boolean;
  /**
   * The DB-stamped restore marker, threaded verbatim to `deriveAnalysisFreshness` (see
   * `DeriveAnalysisFreshnessOptions.analysisInvalidatedAt`). Supplied by the scenario read route, which builds its
   * verdict through this function so it gets the same degraded-fact detection as a turn. Omitted ⇒ byte-identical.
   */
  readonly analysisInvalidatedAt?: string | null;
}

/** Defensive read of a fact's run-time `computed_at`. */
function readComputedAt(fact: HandlerFact): string | null {
  const result = (fact as { result?: { computed_at?: unknown } }).result;
  return result && typeof result.computed_at === 'string' ? result.computed_at : null;
}

/**
 * Compose the canonical analysis state. Pure — no I/O, no telemetry.
 *
 * The verdict is built entirely from the existing canonical primitives
 * over a UNIFIED fact chain (current-turn facts first, then prior facts),
 * so the freshness verdict, the selected fact and the chip floor all agree
 * on one fact set. See module header for the design rationale.
 */
export function selectCanonicalAnalysisState(
  input: SelectCanonicalAnalysisStateInput,
): CanonicalAnalysisState {
  // Unify current-turn + prior facts. Current first so the freshly-run
  // run_analysis fact is newest — this is the fix for the documented
  // chip-floor / freshness divergence.
  const unifiedFacts: readonly HandlerFact[] = [
    ...(input.handlerFacts ?? []),
    ...(input.priorFacts ?? []),
  ];

  // Freshness verdict (also yields selected_fact_index / hashes /
  // computed_at — the single source for those fields here). Threads the
  // option-identity guard inputs verbatim: undefined (flag off) → byte-
  // identical to the pre-guard derivation.
  const derivation = deriveAnalysisFreshness(
    unifiedFacts,
    input.currentGraphHash,
    input.currentGraphOptionIds,
    // Defect 4: distinguishes "the store says no analysis" from "the store
    // could not be read". Absent => pre-fix behaviour, by construction.
    // The restore marker rides the same options object; absent => unchanged.
    input.priorFactsReadOk === undefined && input.analysisInvalidatedAt === undefined && input.currentGraph === undefined
      ? undefined
      : {
          ...(input.priorFactsReadOk === undefined ? {} : { priorFactsReadOk: input.priorFactsReadOk }),
          ...(input.analysisInvalidatedAt === undefined ? {} : { analysisInvalidatedAt: input.analysisInvalidatedAt }),
          ...(input.currentGraph === undefined ? {} : { currentGraph: input.currentGraph }),
        },
  );
  const selected = selectRunAnalysisFact(unifiedFacts);
  const degraded = selectDegradedRunAnalysisFact(unifiedFacts);

  // A newer run failed/partial while an older success would be presented
  // as current. Only provable when both timestamps are present. (Needs the
  // raw facts, so it is computed here, not in the shared assembler.)
  const degradedComputedAt = degraded ? readComputedAt(degraded.fact) : null;
  const degradedNewerThanSelectedSuccess =
    degraded !== null &&
    selected !== null &&
    degradedComputedAt !== null &&
    selected.computed_at !== null &&
    degradedComputedAt > selected.computed_at;

  // Option-identity observability (diagnostic only). Recompute the verdict the
  // guard saw — a trivial set comparison — when the caller supplied current
  // graph option IDs (flag on) and a fact exists. Its EFFECT on freshness is
  // already in `derivation`; this records the inputs/outcome for `_context_summary`.
  let optionIdentity: OptionIdentitySummary | undefined;
  if (input.currentGraphOptionIds !== undefined && selected !== null) {
    const analysedIds = extractAnalysedOptionIds(selected.fact);
    const verdict = compareAnalysedOptionIdentity(
      analysedIds,
      extractAnalysedLeaderId(selected.fact),
      input.currentGraphOptionIds ?? null,
    );
    optionIdentity = {
      checked: true,
      match: verdict.match,
      reason: verdict.reason,
      analysed_option_count: analysedIds?.length ?? 0,
      current_option_count: input.currentGraphOptionIds?.length ?? 0,
    };
  }

  return assembleCanonicalState({
    derivation,
    readiness: input.readiness,
    degradedStatus: degraded?.status ?? null,
    degradedNewerThanSelectedSuccess,
    scenarioClaimsAnalysis: input.scenarioClaimsAnalysis === true,
    optionIdentity,
  });
}

/**
 * Build a canonical analysis state from an already-computed freshness
 * derivation + readiness, WITHOUT the raw fact chain. Used at the route
 * seam (`sendFinalised200`) where the turn's `FreshnessDerivation` and
 * readiness payload are available but the handler-fact array is not.
 *
 * Limitation vs `selectCanonicalAnalysisState`: degraded-fact detection
 * (`degraded_fact_status` + the `fact_status_success_but_degraded_newer`
 * contradiction) needs the fact chain, so this path reports
 * `degraded_fact_status = null` and never raises that contradiction. Every
 * freshness / readiness / predicate field is identical to the fact-based
 * selector. The full canonical state (with degraded detection) is threaded
 * from turn-executor in M5.
 */
export function canonicalStateFromFreshness(
  derivation: FreshnessDerivation,
  opts: { readonly readiness?: ReadinessLike; readonly scenarioClaimsAnalysis?: boolean } = {},
): CanonicalAnalysisState {
  return assembleCanonicalState({
    derivation,
    readiness: opts.readiness,
    degradedStatus: null,
    degradedNewerThanSelectedSuccess: false,
    scenarioClaimsAnalysis: opts.scenarioClaimsAnalysis === true,
  });
}

interface AssembleCanonicalStateParams {
  readonly derivation: FreshnessDerivation;
  readonly readiness?: ReadinessLike;
  readonly degradedStatus: string | null;
  readonly degradedNewerThanSelectedSuccess: boolean;
  readonly scenarioClaimsAnalysis: boolean;
  readonly optionIdentity?: OptionIdentitySummary;
}

/**
 * Shared predicate + contradiction core. Both `selectCanonicalAnalysisState`
 * (fact-based) and `canonicalStateFromFreshness` (derivation-based) funnel
 * through here so the usability rules have exactly ONE implementation.
 */
function assembleCanonicalState(params: AssembleCanonicalStateParams): CanonicalAnalysisState {
  const { derivation } = params;
  const status: AnalysisReadyStatusT | null = coerceReadyStatus(params.readiness?.status);
  const blockers: readonly unknown[] = params.readiness?.blockers ?? [];
  const modelAdjustments: readonly unknown[] = params.readiness?.model_adjustments ?? [];
  const goalNodeId: string | null = params.readiness?.goal_node_id ?? null;

  const hasFact = derivation.selected_fact_index !== null;

  // ── Contradictions (fail-loud, never silently reconciled) ──
  const contradictions: CanonicalContradiction[] = [];

  if (params.scenarioClaimsAnalysis && !hasFact) {
    contradictions.push('scenario_claims_analysis_no_fact');
  }

  // NOTE: a fact with a run hash + current_graph_hash === null
  // (freshness `current_graph_hash_unavailable`) is intentionally NOT a
  // contradiction — it is a benign no-graph / parse-recovery follow-up
  // turn, handled as freshness `unknown` (see CanonicalContradiction doc).

  // Actionable blockers on a 'ready' payload are a should-never-happen
  // integrity violation. Advisory constraint_dropped blockers do NOT count.
  const actionableBlockerCount = blockers.filter((b) => {
    const type = readBlockerType(b);
    return type !== null && ACTIONABLE_BLOCKER_TYPES.has(type);
  }).length;
  if (status === 'ready' && actionableBlockerCount > 0) {
    contradictions.push('status_ready_with_actionable_blockers');
  }

  if (params.degradedNewerThanSelectedSuccess) {
    contradictions.push('fact_status_success_but_degraded_newer');
  }

  // `degraded_fact_status` reports CURRENT degradation only: a non-success
  // run that is the latest analysis state — either no success exists
  // (!hasFact) or the degraded run is newer than the selected success. An
  // older degraded fact superseded by a newer success is historical and
  // reported as null, so the field is never misread as "currently degraded"
  // when the most recent run actually succeeded.
  const degradedIsCurrent = !hasFact || params.degradedNewerThanSelectedSuccess;

  // ── Predicates ──
  // Hard block: nothing is usable.
  // ⭐ (B) — ADMISSION IS ABOUT THE MODEL, NOT THE RESULT (#70; schemas
  // `AnalysisReadinessSchema`: "a model can have a complete result while
  // readiness has since regressed"). A blocked model that HAS a prior run keeps
  // that run usable as stale/current context; only a blocked model with NO run
  // has nothing to show. Before (B) `status === 'blocked'` alone made the prior
  // result unusable for every purpose — Paul's 17:45Z replies lost their run.
  const runAdmitted = params.readiness?.may_run !== false && status !== 'blocked';
  const blockedUnusable =
    (status === 'blocked' && !hasFact) ||
    contradictions.includes('scenario_claims_analysis_no_fact');

  // Trust downgrade: a fact exists but is not chip-safe; surface a rerun.
  const trustDowngrade =
    contradictions.includes('status_ready_with_actionable_blockers') ||
    contradictions.includes('fact_status_success_but_degraded_newer');

  // Prose may reference fresh / stale / (legacy) unknown analysis with a
  // caveat. 'none' has no fact to reference.
  const usableForProse =
    hasFact &&
    !blockedUnusable &&
    (derivation.freshness === 'fresh' ||
      derivation.freshness === 'stale' ||
      derivation.freshness === 'unknown');

  // Result-exploration chips require fresh, trustworthy analysis. Stale or
  // trust-downgraded analysis offers only a rerun chip (via requiresRerun).
  const usableForChips =
    hasFact && derivation.freshness === 'fresh' && !blockedUnusable && !trustDowngrade;

  // Follow-up handlers (e.g. explain_results) treat fresh OR stale as
  // "analysis exists to reference".
  const usableForFollowupContext = hasFact && !blockedUnusable;

  // (B) — a rerun is offered only when one is currently PERMITTED. Offering it
  // beside a blocking admission told the Agent "a fresh analysis is the next
  // valid step" while the Run control refused (Paul, 17:45Z).
  const requiresRerun =
    hasFact && (derivation.freshness === 'stale' || trustDowngrade) && runAdmitted;

  return {
    version: CANONICAL_ANALYSIS_STATE_VERSION,
    status,
    freshness: derivation.freshness,
    freshness_reason: derivation.reason,
    selected_fact_index: derivation.selected_fact_index,
    computed_at: derivation.computed_at,
    graph_hash_at_run: derivation.graph_hash_at_run,
    current_graph_hash: derivation.current_graph_hash,
    blockers,
    model_adjustments: modelAdjustments,
    goal_node_id: goalNodeId,
    degraded_fact_status: degradedIsCurrent
      ? normaliseDegradedStatus(params.degradedStatus)
      : null,
    contradictions,
    usableForProse,
    usableForChips,
    usableForFollowupContext,
    requiresRerun,
    blockedUnusable,
    // Omitted entirely when the guard did not run — keeps the verdict
    // byte-identical for callers that do not thread option IDs (flag off).
    ...(params.optionIdentity !== undefined
      ? { option_identity: params.optionIdentity }
      : {}),
  };
}

/**
 * Redacted, leak-safe projection of the canonical state for the
 * diagnostic `_context_summary` surface and Harness A1/A2. Carries only
 * statuses, predicates, counts and hashes — NEVER raw blocker messages,
 * option labels, prose or user text. This is the ONLY shape that should
 * cross the diagnostic boundary; the full {@link CanonicalAnalysisState}
 * (with blocker/adjustment objects) stays server-internal.
 */
export interface AnalysisStateSummary {
  readonly status: AnalysisReadyStatusT | null;
  readonly freshness: AnalysisFreshnessT;
  readonly freshness_reason: FreshnessReason;
  readonly usable_for_prose: boolean;
  readonly usable_for_chips: boolean;
  readonly usable_for_followup_context: boolean;
  readonly requires_rerun: boolean;
  readonly blocked_unusable: boolean;
  readonly blocker_count: number;
  readonly actionable_blocker_count: number;
  readonly selected_fact_index: number | null;
  readonly graph_hash_at_run: string | null;
  readonly current_graph_hash: string | null;
  readonly degraded_fact_status: string | null;
  readonly contradiction_codes: readonly CanonicalContradiction[];
  /** Option-identity guard decision (counts + closed enums), or undefined when
   *  the guard did not run this turn. See {@link OptionIdentitySummary}. */
  readonly option_identity?: OptionIdentitySummary;
}

/**
 * Project the full canonical state to its redacted summary. Counts only —
 * blocker objects (which carry user-facing messages and labels) are
 * reduced to `blocker_count` / `actionable_blocker_count`.
 */
export function summariseCanonicalAnalysisState(
  state: CanonicalAnalysisState,
): AnalysisStateSummary {
  const actionableBlockerCount = state.blockers.filter((b) => {
    const type = readBlockerType(b);
    return type !== null && ACTIONABLE_BLOCKER_TYPES.has(type);
  }).length;
  return {
    status: state.status,
    freshness: state.freshness,
    freshness_reason: state.freshness_reason,
    usable_for_prose: state.usableForProse,
    usable_for_chips: state.usableForChips,
    usable_for_followup_context: state.usableForFollowupContext,
    requires_rerun: state.requiresRerun,
    blocked_unusable: state.blockedUnusable,
    blocker_count: state.blockers.length,
    actionable_blocker_count: actionableBlockerCount,
    selected_fact_index: state.selected_fact_index,
    graph_hash_at_run: state.graph_hash_at_run,
    current_graph_hash: state.current_graph_hash,
    degraded_fact_status: state.degraded_fact_status,
    contradiction_codes: state.contradictions,
    // Pass through verbatim (counts + enums only); omitted when the guard did
    // not run so the summary stays byte-identical for flag-off callers.
    ...(state.option_identity !== undefined
      ? { option_identity: state.option_identity }
      : {}),
  };
}

/**
 * Coaching state pack — the NARROWEST, hash-free projection of the canonical
 * state, intended as the foundation for a future, separately-approved LLM-facing
 * coaching surface. It projects WHATEVER canonical state the caller holds (full
 * turn-executor verdict OR the route's partial fallback — the `_context_summary`
 * `canonical_state_source` field records which); it is NOT non-execute-specific.
 *
 * It is strictly narrower than {@link AnalysisStateSummary}: it deliberately
 * OMITS `graph_hash_at_run` / `current_graph_hash` (opaque digests),
 * `selected_fact_index` (a raw index), `degraded_fact_status` and
 * `contradiction_codes`. Only closed enums, booleans and counts remain, so the
 * pack carries no hashes, indices, raw values, units, free text, graph content
 * or scientific claims — narrow enough to sit even on a prompt boundary (the
 * `buildUserMessage` behaviour-10 leak contract bars hash-bearing state).
 *
 * This lane uses it ONLY as a diagnostic `_context_summary` sub-block, gated by
 * BOTH `contextSummaryEnabled` and `coachingStatePackEnabled`. It is NOT wired
 * to any prompt / PMS / chip / UI / product path here.
 */
export interface CoachingStatePack {
  /** A selectable run_analysis fact exists (boolean — never the index/value). */
  readonly analysis_present: boolean;
  /** Freshness verdict (closed enum). */
  readonly freshness: AnalysisFreshnessT;
  /** Structural readiness status (closed enum), or null when none supplied. */
  readonly readiness_status: AnalysisReadyStatusT | null;
  /** A rerun affordance is warranted (stale or trust-downgraded). */
  readonly rerun_required: boolean;
  /** Analysis may be referenced in prose (with a caveat when stale). */
  readonly usable_for_prose: boolean;
  /** Analysis is fresh + trustworthy enough for result-exploration chips. */
  readonly usable_for_chips: boolean;
  /** Analysis is unusable — blocked status or a hard contradiction. */
  readonly blocked: boolean;
  /** Count of ACTIONABLE blockers (number only — never the blocker objects). */
  readonly actionable_blocker_count: number;
  /**
   * Present only when the newest non-success run_analysis fact records a
   * refusal and no newer successful run supersedes it. Optional-true keeps the
   * ready/no-attempt prompt shape unchanged while carrying refusal continuity.
   */
  readonly latest_run_attempt_refused?: true;
}

/**
 * Project the canonical state to the redacted, hash-free coaching pack. Pure.
 * Reuses the SAME predicates the rest of the system reads, so the pack can
 * never disagree with chips / prose / `_context_summary` about freshness or
 * usability.
 */
export function summariseCoachingStatePack(
  state: CanonicalAnalysisState,
): CoachingStatePack {
  const actionableBlockerCount = state.blockers.filter((b) => {
    const type = readBlockerType(b);
    return type !== null && ACTIONABLE_BLOCKER_TYPES.has(type);
  }).length;
  return {
    analysis_present: state.selected_fact_index !== null,
    freshness: state.freshness,
    readiness_status: state.status,
    rerun_required: state.requiresRerun,
    usable_for_prose: state.usableForProse,
    usable_for_chips: state.usableForChips,
    blocked: state.blockedUnusable,
    actionable_blocker_count: actionableBlockerCount,
    ...(state.degraded_fact_status === 'refused'
      ? { latest_run_attempt_refused: true as const }
      : {}),
  };
}
