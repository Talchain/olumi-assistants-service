[SCI-HERO Codex → existing SCI-HERO owner / successor PTL / Context P0 / Shared Data / SCIENCE-DSK]

Paul has explicitly authorised implementation of the narrowed tipping-point-only plan in this Codex chat. Continuing the existing SCI-HERO lease and PR #2531, not opening a duplicate builder lane.

Verified baseline: CEE staging + served health = 752c487b4392cb1ccd299d0ebae4a039e6696ade. Existing PR/checkpoint = cb2206bfd85cf3e0d218dc042a9f1270ad78a63b; its local /private/tmp/scihero-cee-1790984347 tree is clean with no active cwd holder found. I will preserve that checkpoint and use fast-forward pushes only. Existing SCI-HERO writer: please bank at this checkpoint and avoid overlapping edits; report any newer unpublished work immediately.

First boundary being fixed: typed projection currently rounds 55.76 to about 56, selects the first crossing before checking display eligibility, carries optional winner fields, and has only a model instruction rather than the RC checker/fallback finish.

Leaf lease: agent-lane/decision-sensitivity.ts + its tipping-point specs; coach-route-v0_2.ts + byte-pinned wiring spec; turn-context/guidance-signals.ts + direct specs. Deterministic coaching will reuse the existing RC-WHAT-CHANGES selector/checker/fallback machinery, with a minimal policy re-pin coordinated through the existing HARNESS/Context owner (#2521); priority/order remain unchanged. No edits to leader-licence.ts or a SCI-HERO permission/currentness authority.

Context P0: please own the same typed-fact integration into withSavedRunCertainty/current canonical read; no second writer on agent-capabilities.ts. I will provide an exact leaf interface/test expectation. Any route/action hotspot will be submitted as a bounded hunk to the serial landing owner before integration. Existing factor-ID refinement path is assessed before adding a chip.

Parked: schemas/PLoT changes, keep-list/status transport, VOI interactions, baseline winner, stability bands, ranks 2+, broad science validation. VOI scientifically available; product-positive case not currently demonstrated on served model shape.

SCIENCE/DSK, separately commissioned by Paul: Is introducing a legitimate stated-level uncertain root operand or a no-level option node scientifically and product-wise correct for these models? Please assess validity, not how to engineer a non-zero demo. This answer does not block tipping-point delivery.

Acceptance: existing served positive 0e19bb82 (49 → 55.76 GBP/month), served no-signal 17d1cd3a, withheld winner retains threshold, stale refusal, factor-ID action with user approval, rerun, canonical cold reload. Inherited 127-row science validation; focused exact-head checks + Required CI + one served joined journey. No JOURNEY-WITNESSED claim before that sequence is observed.
