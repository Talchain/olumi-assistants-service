Runtime L1 — frozen source handoff; independent review pending

Owner: Runtime01a0fec3. Priority lease: PTL87/5970644626 + connected-sink correction5970837342, executable ACK5970852660. Paul requested lead alignment: posted and exact-readback verified87/5971499519. No current priority/file-scope override consumed.

State: LOCAL_SOURCE_FROZEN / focused GREEN / independent Codex pre-review RUNNING. No PR, push, merge, deployment, current-turn measurement or signed-in witness.

Source: 75218ba18150518134d101228073267933d4e6d1
Tree: 373bc555b62f5a6ca95ea905c3acdc3f5ea44b4f
Parent/base: 3b888e49f3deef3b4a800b83311e8906c01e5c86
Branch: runtime/l1-connected-call-capture-20261003
Checkout: /private/tmp/olumi-b3-delta-20261003.62tEvb/cee
Portable one-commit patch: RUNTIME-L1.patch (SHA256c737939c0cdf872cce19127f82d51637bcd344bc1e8a4d4c37ff7324c6885040)
SOURCE-MANIFEST.json records all seven exact files and before/after blob+SHA256 identities. Source is clean. Current staging at17:21UTC is b31389c7d828dd3e1d25f4542661f73d1f15d2e9; all four leased product blobs are exactly identical to the author base. This is leased-file compatibility, not current-base integration/gate/serving proof.

What changed:
- Actual five OpenAI withRetry groups, seven Anthropic withRetry groups and one existing Anthropic draft-completion request now join to their actual SDK fetch attempts through ephemeral AsyncLocalStorage. Native SDK retries and existing repository retries are nested observations under their invocation identity.
- One existing TelemetryEvents.LlmCall terminal event per observed group contains the explicit numeric policy handle or null; Anthropic transport handles remain separate, including capped/unknown handles. Distinct generated logical/physical IDs and actual returned request-id headers are observations only.
- Actual serialized sent provider/model/effort/thinking/prompt-payload/tools/body hashes are retained. Registry prompt version/source/hash are copied only at calls where those actual values are already available; no registry identity borrowed for custom completion.
- Returned SDK usage is explicitly scoped to returned_sdk_result, including the draft finalMessage envelope. Failed terminal throws, runaway aborts and recoverable structured-output rejections remain distinguishable. Missing tokens and absent cost/quality stay null. This is not total billed usage across retries.
- Telemetry and metadata-reading failures cannot replace original values/errors or create retries. Original TimingSummary helpers and logical call_count are byte-identical.

Evidence:
- Initial omission RED:7FAIL/43PASS, all five specs collected; exact body/effort/refusal controls retained.
- Policy-cap + response-observer RED:2FAIL/28PASS.
- Final streamed-usage/rejection/request-metadata RED:3FAIL/19PASS.
- Frozen source GREEN:56PASS/0FAIL across the five exact offline specs, one worker, duration10.07seconds; no live transport. focused-GREEN-frozen.log.
- Frozen file ESLint:exit0. Typecheck ratchet:exit0,100files/290inherited errors vs baseline103files/291; baseline unchanged. Initial ratchet missing ignored generated OpenAPI was preserved as failed, then the existing local generator ran and final ratchet passed.
- SOURCE-COMPATIBILITY.json proves normalized AST arguments/counts unchanged for every original withRetry, provider assertion and SDK request, plus old timing helper/summary bytes unchanged.
- Historical fixture SHA2568f3da924736431bd6305cd0ec2f1b8fcf33b2c294e6c78b7c38a2969fc67c03d matches the captured bank derivative. Original bank d864eeb26ef480d31dddd65dcfb44ee35f41ad800e94f60ead2058a7295cbf52 has18receipts/9recorded policy calls; historical physical IDs/count remain null. Those raw Agent captured receipts do not become covered adapter turns.
- Earlier first-control cold-load timeout and next-case fake-request count failure are retained in focused-GREEN-2.log. Move cold transform to test setup; do not alter SDK or provider retry behaviour to suppress those failures.

Review: existing independent /root/b3_codex_buddy reviewing this exact source. Final verdict and unresolved P1 count pending; do not label REVIEW_READY yet.

Coverage limits:
Direct raw Agent Responses and public async-generator Anthropic stream-chat are excluded. All source paths not covered by the connected adapter groups stay unmeasured. Physical duration stops at response headers; logical duration covers existing SDK/retry callback, including stream work/retry delays. No new canonical ledger, request-id map, DB/schema/route, permission authority or model/prompt policy. No calls/turn, ordinary-turn repeat, dominant latency, speedup, persistence or browser acceptance claim.

Landing and ownership:
Executor01a0ff01 receives this exact head/patch after the one independent pre-review reaches zero unresolved P1. Root owns actual current-base integration and hot files; publisher/release allocation, independent HIGH/MG/current Required CI/normal prepush gates and serving remain separately owed. No L2/L3 authoring or publication here. CoreB3 B/Action, Accounts Builder, SCI-CHANGE ScienceUI and sole Harness/account setup retain their accepted owners. CEE2522 later hot-seam integration stays with root. The current unrelated CEE prompt independent finding remains an existing-owner issue, not a programme-wide stop.
