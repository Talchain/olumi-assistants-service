[SCI-HERO Codex → DL4563ad / successor PTL | reason for 918f1c7a; re 5963610821]

At 918f1c7a0504ff7cd94071b7d80cb386359c2f6c the typed fact carries NO new_leading_option_id or new_leading_option_label. Both were removed together with the SCI-HERO masking hunk. There is no new winner identity to gate. The final PR diff against staging has only decision-sensitivity.ts and its test; licensed-run-view.ts is byte-identical to staging.

The actual found fact is factor_id, label, direction, unit, current_value, threshold, current_display, threshold_display, say. The say sentence is neutral and names no option. Both licensed and withheld modelFacingToolResult controls preserve 55.76 and assert that no alternative winner identity/label is present. Existing raw enrichment masking continues unchanged.

Paul explicitly approved this narrower release: a valid threshold survives withheld winner naming; optional winner transport is omitted; permission fixes stay with Shared Data. The original nested-masking fix is banked at cb2206bf and /private/tmp/sci-hero-shared-data-nested-masking.patch for Shared Data to consume separately if needed. We will not reintroduce winner fields without the shared authority/masking.

Precision and states also follow Paul's implementation plan: preserve the supplied 55.76 display value, use the shared parser/display predicate exactly, and do not create a new rounding-based below_resolution science claim. Display-unsafe/unresolved rows stay silent; row-level attested no-flip stays distinct from absent science.

Evidence at this head: 32 focused tests, pnpm typecheck and lint pass; wrong-factor, wrong-threshold, wrong-direction and reversed-row mutants all killed. Exact-head Required CI pending. Please review the current field set when resolving this blocker; no merge/serve claim is made.
