import type {
  CqeParameterOperator,
  QuantityExtractionResult,
} from './schema-types.js';
import {
  overlapsWordNumberReplacement,
  type WordNumberReplacement,
} from './word-numbers.js';

// CQE pattern rules P1-P13 per CQE Design v1.1 §4.2.
//
// Construction principles:
//  - Each rule owns a bounded regex plus a parse function mapping a match to
//    Partial<QuantityExtractionResult>. Rules are authored to avoid
//    catastrophic backtracking by construction (no unbounded nested
//    quantifiers, no overlapping alternations without anchors). The 50ms
//    timeout in extract-quantities.ts is defence-in-depth, not control flow.
//  - P11 (from_to) is implemented as two anchored sub-patterns and merged in
//    code per cqe-investigation-proposal.md §3.3 Gate 3.
//  - All rules use the `i` flag for case-insensitive matching; the
//    normalisation layer preserves case so raw_text stays faithful.

// ---- shared token fragments -------------------------------------------------

/**
 * Exported as `CQE_NUMERIC_SOURCE` for the same reason as
 * `CURRENCY_SYMBOL_SOURCE` / `NUMERIC_SUFFIX_SOURCE` below: a consumer
 * outside CQE that needs to locate a numeric token in the user's message
 * (the calibration threshold anchor, `routing/calibration-semantics.ts`)
 * must share this grammar rather than re-implement it. Every previous
 * local copy of a CQE fragment drifted (bare-`b` suffix, `¥` currency).
 */
export const CQE_NUMERIC_SOURCE = String.raw`(?:-|minus\s+)?\d+(?:\.\d+)?`;
const NUM = CQE_NUMERIC_SOURCE;
const APPROX = String.raw`roughly|about|approximately|around|nearly|circa`;
const DIRECTION_UP_VERB = String.raw`increas(?:e|ing|es|ed)|rais(?:e|ing|es|ed)|grow(?:ing|s)?|grew|boost(?:ing|s|ed)?|add(?:ing|s|ed)?`;
const DIRECTION_DOWN_VERB = String.raw`reduc(?:e|ing|es|ed)|cut(?:ting|s)?|lower(?:ing|s|ed)?|decreas(?:e|ing|es|ed)|drop(?:ping|s|ped)?|bring(?:ing|s)?(?:\s+(?:down|it\s+down))?`;
const DIRECTION_SET_VERB = String.raw`set(?:ting|s)?|change(?:s|d)?|changing|updat(?:e|ing|es|ed)|mak(?:e|ing|es)|made`;
const DIRECTION_VERB = `(?:${DIRECTION_UP_VERB}|${DIRECTION_DOWN_VERB}|${DIRECTION_SET_VERB})`;
// Exported as `CURRENCY_SYMBOL_SOURCE` so consumers outside CQE (e.g.
// the V5 routing `FROM_TO_NUMERIC_ANCHOR_PATTERN`) can share the exact
// same grammar without re-implementing it. PR #192 review feedback
// (round 4, 2026-05-22) identified a ¥ accept bug in the local copy of
// this grammar — same drift class as the bare-`b` suffix bug closed in
// round 3. Sharing the source eliminates this class of bug.
export const CURRENCY_SYMBOL_SOURCE = String.raw`£|\$|€`;
const CURRENCY_SYMBOL = CURRENCY_SYMBOL_SOURCE;
const CURRENCY_CODE = String.raw`GBP|USD|EUR`;
const CURRENCY_COLLOQUIAL = String.raw`grand|quid`;
/**
 * The colloquial tokens that also carry a MAGNITUDE, and what they multiply by
 * (ROADMAP 2.330).
 *
 * `CURRENCY_COLLOQUIAL` above admits exactly `grand|quid`. Both imply GBP (see
 * `normaliseCurrencyUnit`), but only `grand` is also a magnitude: "five grand"
 * is 5,000, "five quid" is 5. That fact used to live as an inline ternary in
 * rule P8 — the only statement of `grand` → ×1000 anywhere in `src/`, and
 * therefore invisible to the canonical alphabet's union guard, which is how
 * `$50 grand` extracted as 50 on the goal-card path while this rule read the
 * same words as 50,000.
 *
 * A token absent from this map carries no magnitude and multiplies by 1. That
 * is a real statement about `quid`, not a silent fallback: the regex admits no
 * third token, and `COLLOQUIAL_MAGNITUDE_TOKENS_ARE_KNOWN` in the union guard
 * REDs if `CURRENCY_COLLOQUIAL` ever grows one this map has not ruled on.
 */
export const COLLOQUIAL_MAGNITUDE_MULTIPLIERS: Readonly<Record<string, number>> = {
  grand: 1_000,
};
/** The colloquial currency tokens P8 admits, as data — see the map above. */
export const CURRENCY_COLLOQUIAL_SOURCE = CURRENCY_COLLOQUIAL;
const TIME_UNIT = String.raw`months?|weeks?|days?|years?|hours?|minutes?`;
const METRIC_UNIT = String.raw`kg|km|miles?`;
// Suffix tokens MUST be followed by a non-letter (word boundary via
// negative lookahead). Otherwise "4 months" would parse the "m" in
// "months" as a million suffix.
//
// Exported as `NUMERIC_SUFFIX_SOURCE` so consumers outside CQE (e.g.
// the V5 routing `FROM_TO_NUMERIC_ANCHOR_PATTERN`) can share the exact
// same grammar without re-implementing it. PR #192 review feedback
// (2026-05-22) identified a bare-`b` accept bug caused by a divergent
// suffix pattern (`bn?`) that accepted "1b" / "2b" while CQE rejected
// them — the deterministic branch then attributed CQE's bare-number
// extraction as the target, silently mis-mutating the graph. Sharing
// the source string eliminates that drift class.
export const NUMERIC_SUFFIX_SOURCE = String.raw`(?:k|m|bn|million|billion|thousand)(?![a-z])`;
const SUFFIX = NUMERIC_SUFFIX_SOURCE;

/**
 * ⭐⭐ THE SPELLED-OUT PERCENT TOKENS. A USER WHO WRITES THE WORD HAS STATED THE
 * SCALE JUST AS EXPLICITLY AS ONE WHO TYPES THE SYMBOL.
 *
 * Until this constant existed, this grammar's percent vocabulary was `%` and
 * nothing else, so "12 percent" extracted as `{value: 12, unit: null}` while
 * "12%" extracted as `{value: 0.12, unit: 'percentage'}`. Every hop downstream
 * then carried the unitless 12 faithfully: `mapCqeQuantityToProposalValue`
 * returns `{value: 12, unit: undefined}`, `set-factor-value`'s
 * `parseProposalValue` sets `inputHasUnit: false`, and `normaliseFactorValue`
 * writes `{value: 12, raw_value: 12}` — a pair that positively asserts "12 is
 * already on the analysis scale", false by 100x. The analysis seam's baseline
 * gate (`findScaleIncoherentBaselineFactorIds`) then correctly refused the run
 * with `baseline_scale_unresolved` — "recorded as a bare amount with no range".
 *
 * ⚠ THE GATE WAS RIGHT AND IS NOT TOUCHED. The pair it was handed genuinely
 * encodes no frame. The loss was here, at the FIRST hop: the user stated the
 * scale in their own words and this grammar threw the words away. #1236 taught
 * the WRITER to honour a stated unit; the unit never arrived.
 *
 * ⚠ THE ESTATE ALREADY KNEW. `routing/value-unit-resolution.ts:77-78` carries
 * `['percent', 'percent'], ['percentage', 'percent']` under the comment
 * "the words CQE's grammar omits" — a sibling module compensating for this
 * omission for its own guard while the omission itself stayed unrepaired at
 * the source. That is the hand-maintained-mirror defect: two vocabularies for
 * one concept, and the reader was wider than the writer.
 *
 * ⚠ EVERY TOKEN ENDS `(?![a-z])`, AND THAT IS THE WHOLE SAFETY ARGUMENT FOR THE
 * SHAPE. It is what keeps `percent` out of "percentile" and out of the
 * "percent" PREFIX of "percentage"/"percentage points" — so `percentage
 * points` cannot be silently re-read as a percent (a 100x lie in the opposite
 * direction, and the exact "closed the gap, opened the lie" trade this must
 * avoid). `pp` / `percentage points?` keep their existing ownership: P13 runs
 * FIRST in `PATTERN_RULES` and masks its span, and this lookahead means the
 * outcome does not DEPEND on that ordering.
 *
 * ⚠ BARE `percentage` IS DELIBERATELY ABSENT, and this is a decision, not an
 * oversight. As a quantity suffix it is not idiomatic English on its own —
 * "12 percentage" is only ever the head of "12 percentage points", which P13
 * owns. `classifyUnitScaleClass` DOES classify the token "percentage" as the
 * percent family, and that is not an inconsistency to tidy away (trap 21): it
 * answers "which scale family is this stored unit LABEL in?", while this
 * constant answers "which words did the user type as a quantity suffix?".
 * Suppress rather than guess; a bare "12 percentage" falls through to the
 * unitless write and the gate keeps refusing it, visibly.
 *
 * `per cent` is here because this is a British-English estate — the same
 * spelling an adversarial review had to supply to `classifyUnitScaleClass`
 * from outside its corpus, where "3 per cent" was silently read as 0.6.
 */
const PERCENT_WORD = String.raw`percent(?![a-z])|per\s+cent(?![a-z])|pct(?![a-z])`;

// UNIT token for patterns that accept a trailing unit.
// `percentage\s+points?` precedes PERCENT_WORD so the longer, more specific
// token wins the alternation even before the lookaheads are consulted.
const UNIT = `(?:%|pp|percentage\\s+points?|${PERCENT_WORD}|${TIME_UNIT}|${METRIC_UNIT}|${CURRENCY_SYMBOL}|${CURRENCY_CODE}|${CURRENCY_COLLOQUIAL})`;

// Word fractions (handled by P5; values from §4.3 cross-cutting modifiers).
// Order matters: longer phrases must precede shorter ones so the alternation
// picks up "two thirds" before "third".
const WORD_FRACTIONS: ReadonlyArray<{ phrase: string; value: number }> = [
  { phrase: 'two thirds', value: 0.667 },
  { phrase: 'two-thirds', value: 0.667 },
  { phrase: 'three quarters', value: 0.75 },
  { phrase: 'three-quarters', value: 0.75 },
  { phrase: 'one third', value: 0.333 },
  { phrase: 'one-third', value: 0.333 },
  { phrase: 'a third', value: 0.333 },
  { phrase: 'a quarter', value: 0.25 },
  { phrase: 'a half', value: 0.5 },
  { phrase: 'third', value: 0.333 },
  { phrase: 'quarter', value: 0.25 },
  { phrase: 'half', value: 0.5 },
];

// ---- types ------------------------------------------------------------------

export interface RuleContext {
  readonly wordNumberReplacements: readonly WordNumberReplacement[];
  /**
   * The text BEFORE any rule masked a span (same length and positions: a mask writes spaces). A rule that must read what
   * stood beside its match reads it here, because by its turn an earlier figure is blank ("£100-£500" → "     -£500").
   */
  readonly unmaskedText?: string;
}

export interface CqePatternMatch {
  readonly spanStart: number;
  readonly spanEnd: number;
  readonly raw: string;
  readonly result: Partial<QuantityExtractionResult>;
  readonly patternId: string;
}

export interface PatternRule {
  readonly id: string;
  readonly priority: number;
  readonly apply: (text: string, ctx: RuleContext) => CqePatternMatch[];
}

// ---- helpers ----------------------------------------------------------------

function parseNum(raw: string): number {
  const trimmed = raw.trim().replace(/^minus\s+/i, '-');
  const n = Number.parseFloat(trimmed);
  return Number.isFinite(n) ? n : NaN;
}

function applySuffix(base: number, suffix: string | undefined): number {
  if (!suffix) return base;
  const s = suffix.toLowerCase();
  if (s === 'k' || s === 'thousand') return base * 1_000;
  if (s === 'm' || s === 'million') return base * 1_000_000;
  if (s === 'bn' || s === 'billion') return base * 1_000_000_000;
  return base;
}

function normaliseCurrencyUnit(token: string): string {
  const t = token.toLowerCase();
  if (t === '£' || t === 'gbp' || t === 'grand' || t === 'quid') return 'GBP';
  if (t === '$' || t === 'usd') return 'USD';
  if (t === '€' || t === 'eur') return 'EUR';
  return t;
}

function normaliseUnit(token: string | undefined): string | null {
  if (!token) return null;
  const t = token.trim().toLowerCase();
  if (!t) return null;
  // `percentage_points` is tested FIRST: the spelled-out percent test below
  // would otherwise never see it (its own regex is anchored and cannot match
  // "percentage points"), but ordering it first makes that independent of the
  // percent pattern's shape rather than a consequence of it.
  if (t === 'pp' || /^percentage\s+points?$/.test(t)) return 'percentage_points';
  if (t === '%') return 'percentage';
  // The spelled-out forms admitted by `PERCENT_WORD`. Anchored at both ends so
  // this cannot classify a longer token by prefix — "percentile" and
  // "percentage" reach the plural-collapse fallback below and stay themselves.
  if (/^(?:percent|per\s+cent|pct)$/.test(t)) return 'percentage';
  if (/^(£|\$|€|gbp|usd|eur|grand|quid)$/.test(t)) return normaliseCurrencyUnit(t);
  // Collapse plurals for duration/metric units (months -> month, etc).
  return t.replace(/s$/u, '');
}

function directionFromVerb(verb: string): 'up' | 'down' | 'set' {
  const v = verb.toLowerCase();
  if (new RegExp(`^(?:${DIRECTION_UP_VERB})$`, 'i').test(v)) return 'up';
  if (new RegExp(`^(?:${DIRECTION_DOWN_VERB})$`, 'i').test(v)) return 'down';
  return 'set';
}

function isApproximatelyPrefixed(text: string, spanStart: number): boolean {
  const windowStart = Math.max(0, spanStart - 40);
  const before = text.slice(windowStart, spanStart);
  return new RegExp(`(?:\\b(?:${APPROX})\\b)\\s*\\S*\\s*$`, 'i').test(before);
}

function matchContainsApprox(raw: string): boolean {
  return new RegExp(`\\b(?:${APPROX})\\b`, 'i').test(raw);
}

function makeResult(
  raw: string,
  result: Partial<QuantityExtractionResult>,
): Partial<QuantityExtractionResult> {
  return {
    raw_text: raw,
    value: null,
    unit: null,
    direction: null,
    multiplier: null,
    operator: null,
    comparator: null,
    range_min: null,
    range_max: null,
    approximate: false,
    source: 'cqe',
    ...result,
  };
}

function emit(
  match: RegExpExecArray,
  text: string,
  result: Partial<QuantityExtractionResult>,
  ctx: RuleContext,
): CqePatternMatch {
  const spanStart = match.index;
  const spanEnd = match.index + match[0].length;
  const raw = match[0];
  const approximate =
    result.approximate === true ||
    isApproximatelyPrefixed(text, spanStart) ||
    matchContainsApprox(raw);
  const merged = makeResult(raw, { ...result, approximate });
  const originIsWord = overlapsWordNumberReplacement(
    ctx.wordNumberReplacements,
    spanStart,
    spanEnd,
  );
  if (originIsWord && merged.value_origin === undefined) {
    merged.value_origin = 'word_number';
  }
  return {
    spanStart,
    spanEnd,
    raw,
    result: merged,
    patternId: '',
  };
}

function scanAll(
  text: string,
  regex: RegExp,
  onMatch: (m: RegExpExecArray) => CqePatternMatch | null,
): CqePatternMatch[] {
  const out: CqePatternMatch[] = [];
  let m: RegExpExecArray | null;
  const cloned = new RegExp(regex.source, regex.flags.includes('g') ? regex.flags : regex.flags + 'g');
  while ((m = cloned.exec(text)) !== null) {
    const res = onMatch(m);
    if (res) out.push(res);
    if (m.index === cloned.lastIndex) cloned.lastIndex++;
  }
  return out;
}

// ---- P1 range_between ------------------------------------------------------

const P1_REGEX = new RegExp(
  `\\bbetween\\s+(${NUM})\\s*(${UNIT})?\\s+and\\s+(${NUM})\\s*(${UNIT})?`,
  'gi',
);

const rule_P1: PatternRule = {
  id: 'P1',
  priority: 1,
  apply: (text, ctx) =>
    scanAll(text, P1_REGEX, (m) => {
      const rangeMin = parseNum(m[1]);
      const perSideUnitA = m[2];
      const rangeMax = parseNum(m[3]);
      const perSideUnitB = m[4];
      if (!Number.isFinite(rangeMin) || !Number.isFinite(rangeMax)) return null;
      const unitA = normaliseUnit(perSideUnitA);
      const unitB = normaliseUnit(perSideUnitB);
      const unit = unitB ?? unitA;
      if (perSideUnitA && perSideUnitB && unitA !== unitB) return null;
      const isPercentUnit = unit === 'percentage';
      return emit(
        m,
        text,
        {
          range_min: isPercentUnit ? rangeMin / 100 : rangeMin,
          range_max: isPercentUnit ? rangeMax / 100 : rangeMax,
          comparator: 'between',
          unit,
          value_origin: 'literal',
        },
        ctx,
      );
    }),
};

// ---- P2 range_dash ---------------------------------------------------------
// Hyphen/en-dash variant AND "X to Y unit" variant. Guards: must NOT be
// preceded by `from` (P11 territory) or by a directional verb (P12 territory).

const P2_HYPHEN_REGEX = new RegExp(
  `(${NUM})\\s*[-–]\\s*(${NUM})(?:\\s*(${UNIT}))?`,
  'gi',
);
const P2_TO_REGEX = new RegExp(
  `\\b(${NUM})\\s+to\\s+(${NUM})(?:\\s*(${UNIT}))?`,
  'gi',
);

function p2GuardsPass(text: string, matchIndex: number): boolean {
  const windowStart = Math.max(0, matchIndex - 40);
  const before = text.slice(windowStart, matchIndex);
  if (/\bfrom\s+$/i.test(before)) return false;
  if (new RegExp(`\\b(?:${DIRECTION_VERB})\\b[^\\n]*?\\s+$`, 'i').test(before)) return false;
  return true;
}

const rule_P2: PatternRule = {
  id: 'P2',
  priority: 2,
  apply: (text, ctx) => {
    const out: CqePatternMatch[] = [];
    const process = (regex: RegExp): void => {
      for (const m of scanAllExec(text, regex)) {
        if (!p2GuardsPass(text, m.index)) continue;
        const rangeMin = parseNum(m[1]);
        const rangeMax = parseNum(m[2]);
        const rawUnit = m[3];
        if (!Number.isFinite(rangeMin) || !Number.isFinite(rangeMax)) continue;
        const unit = normaliseUnit(rawUnit);
        const isPercentUnit = unit === 'percentage';
        out.push(
          emit(
            m,
            text,
            {
              range_min: isPercentUnit ? rangeMin / 100 : rangeMin,
              range_max: isPercentUnit ? rangeMax / 100 : rangeMax,
              comparator: 'between',
              unit,
              value_origin: 'literal',
            },
            ctx,
          ),
        );
      }
    };
    process(P2_HYPHEN_REGEX);
    process(P2_TO_REGEX);
    return out;
  },
};

// Typed filter guard. Lets parse callbacks return `CqePatternMatch | null`
// without resorting to `as unknown` bypasses (brief §13).
function isMatch(x: CqePatternMatch | null | undefined): x is CqePatternMatch {
  return x !== null && x !== undefined;
}

function scanAllExec(text: string, regex: RegExp): RegExpExecArray[] {
  const out: RegExpExecArray[] = [];
  const cloned = new RegExp(regex.source, regex.flags.includes('g') ? regex.flags : regex.flags + 'g');
  let m: RegExpExecArray | null;
  while ((m = cloned.exec(text)) !== null) {
    out.push(m);
    if (m.index === cloned.lastIndex) cloned.lastIndex++;
  }
  return out;
}

// ---- P3 comparator_value ---------------------------------------------------

/**
 * ⭐ EXPORTED (2026-08-05) so the calibration semantic layer can assert a
 * UNION property against them rather than keeping a second hand-written
 * copy — CLAUDE.md trap 12d: deriving a guard from a list moves the risk,
 * so the routing-side threshold-marker list must be a SUPERSET of these,
 * checked by an importable assertion.
 *
 * ⚠ MEASURED GAP, and it is the mechanism of the 5 Aug calibration defect:
 * `below` and `above` are ABSENT here. `extractQuantities('...staying
 * below 3%...')` therefore returns `comparator: null`, while the identical
 * sentence with `under` returns `comparator: 'at_most'`. The threshold
 * marker in the WITNESSED prompt was invisible to CQE, so `3%` arrived at
 * routing indistinguishable from a plain value and was stored as one.
 *
 * The gap is deliberately NOT closed here. Adding words to this lexicon
 * moves which rule claims the span (P3 vs P6/P6b), which changes
 * `raw_text` and span offsets for every downstream consumer of a shape
 * that has been stable for months. The calibration layer instead carries
 * its own SUPERSET and this export makes the superset property provable.
 * Closing the CQE gap itself is a separate, rowed change.
 */
export const COMPARATOR_ATMOST_SOURCE = String.raw`at\s+most|no\s+more\s+than|up\s+to|under|less\s+than|maximum(?:\s+of)?|max(?:\s+of)?`;
export const COMPARATOR_ATLEAST_SOURCE = String.raw`at\s+least|no\s+less\s+than|over|more\s+than|minimum(?:\s+of)?|min(?:\s+of)?`;
const COMPARATOR_ATMOST = COMPARATOR_ATMOST_SOURCE;
const COMPARATOR_ATLEAST = COMPARATOR_ATLEAST_SOURCE;
const P3_REGEX = new RegExp(
  `\\b(?<cmp>${COMPARATOR_ATMOST}|${COMPARATOR_ATLEAST})\\s+(?<currSym>${CURRENCY_SYMBOL})?(?<num>${NUM})(?:\\s*(?<suffix>${SUFFIX}))?(?:\\s*(?<unit>${UNIT}))?`,
  'gi',
);

const rule_P3: PatternRule = {
  id: 'P3',
  priority: 3,
  apply: (text, ctx) =>
    scanAllExec(text, P3_REGEX).map((m) => {
      const cmpRaw = m.groups?.cmp?.toLowerCase() ?? '';
      const currSym = m.groups?.currSym;
      const num = parseNum(m.groups?.num ?? '');
      const suffix = m.groups?.suffix;
      const rawUnit = m.groups?.unit;
      if (!Number.isFinite(num)) return null;
      const comparator: 'at_least' | 'at_most' = new RegExp(`^(?:${COMPARATOR_ATLEAST})$`, 'i').test(cmpRaw)
        ? 'at_least'
        : 'at_most';
      let unit = normaliseUnit(rawUnit);
      let value = applySuffix(num, suffix);
      const hasSuffix = Boolean(suffix);
      if (currSym) {
        unit = normaliseCurrencyUnit(currSym);
      }
      if (unit === 'percentage') value = value / 100;
      return emit(
        m,
        text,
        {
          value,
          comparator,
          unit,
          value_origin: hasSuffix ? 'suffix_expansion' : 'literal',
        },
        ctx,
      );
    }).filter(isMatch),
};

// ---- P4 multiplier_verb ----------------------------------------------------

const MULTIPLIER_LEXICON: ReadonlyArray<{ phrase: string; multiplier: number; direction: 'up' | 'down' }> = [
  { phrase: 'quadruple', multiplier: 4, direction: 'up' },
  { phrase: 'quadrupling', multiplier: 4, direction: 'up' },
  { phrase: 'triple', multiplier: 3, direction: 'up' },
  { phrase: 'tripling', multiplier: 3, direction: 'up' },
  { phrase: 'double', multiplier: 2, direction: 'up' },
  { phrase: 'doubling', multiplier: 2, direction: 'up' },
  { phrase: 'halve', multiplier: 0.5, direction: 'down' },
  { phrase: 'halving', multiplier: 0.5, direction: 'down' },
];
const P4_REGEX = new RegExp(
  `\\b(${MULTIPLIER_LEXICON.map((e) => e.phrase).join('|')})\\b`,
  'gi',
);

const rule_P4: PatternRule = {
  id: 'P4',
  priority: 4,
  apply: (text, ctx) =>
    scanAllExec(text, P4_REGEX).map((m) => {
      const word = m[1].toLowerCase();
      const entry = MULTIPLIER_LEXICON.find((e) => e.phrase === word)!;
      return emit(
        m,
        text,
        {
          multiplier: entry.multiplier,
          operator: 'multiply',
          direction: entry.direction,
          value_origin: 'literal',
        },
        ctx,
      );
    }),
};

// ---- P5 word_fraction ------------------------------------------------------

const P5_REGEX = new RegExp(
  `\\b(${DIRECTION_UP_VERB}|${DIRECTION_DOWN_VERB})\\s+by\\s+(?:(?:${APPROX})\\s+)?(${WORD_FRACTIONS.map((e) => e.phrase.replace(/\s+/g, '\\s+')).join('|')})\\b`,
  'gi',
);

const rule_P5: PatternRule = {
  id: 'P5',
  priority: 5,
  apply: (text, ctx) =>
    scanAllExec(text, P5_REGEX).map((m) => {
      const verb = m[1];
      const phraseRaw = m[2];
      const direction = directionFromVerb(verb) === 'up' ? 'up' : 'down';
      const entry = WORD_FRACTIONS.find((e) =>
        new RegExp(`^${e.phrase.replace(/\s+/g, '\\s+')}$`, 'i').test(phraseRaw),
      );
      if (!entry) return null;
      return emit(
        m,
        text,
        {
          value: entry.value,
          operator: direction === 'up' ? 'increment' : 'decrement',
          direction,
          value_origin: 'word_fraction',
        },
        ctx,
      );
    }).filter(isMatch),
};

// ---- P6 directional_percent -------------------------------------------------

const P6_REGEX = new RegExp(
  `\\b(${DIRECTION_UP_VERB}|${DIRECTION_DOWN_VERB})(?:\\s+[a-z][a-z\\s-]{0,30}?)?\\s+by\\s+(?:(?:${APPROX})\\s+)?(${NUM})\\s*%`,
  'gi',
);

const rule_P6: PatternRule = {
  id: 'P6',
  priority: 6,
  apply: (text, ctx) =>
    scanAllExec(text, P6_REGEX).map((m) => {
      const verb = m[1];
      const num = parseNum(m[2]);
      if (!Number.isFinite(num)) return null;
      const direction = directionFromVerb(verb) === 'up' ? 'up' : 'down';
      return emit(
        m,
        text,
        {
          value: num / 100,
          direction,
          operator: direction === 'up' ? 'increment' : 'decrement',
          unit: 'percentage',
          value_origin: 'literal',
        },
        ctx,
      );
    }).filter(isMatch),
};

// ---- P6b directional_absolute ----------------------------------------------
//
// PERCENTAGE OWNERSHIP — read before touching the trailing `(?!\s*%)`.
//
// The lookahead was evidently written to keep percentages out of P6b and
// leave them to P6, per CQE Design v1.1 §4.2's "Must NOT contain % (P6
// territory)" guard. IT DOES NOT DO THAT, because it sits AFTER the optional
// `(${UNIT})` group and UNIT itself includes `%`. When UNIT consumes the `%`
// the lookahead is evaluated past it, is trivially satisfied, and P6b matches
// the percentage anyway. (It is not entirely inert — it still rejects a
// doubled "5%%" — so it is left in place rather than deleted on a
// coverage-only argument.)
//
// P6b therefore DOES own a real slice of percentage territory, and the fix is
// to normalise rather than to decline, because P6 cannot take that slice:
// P6_REGEX requires a mandatory `\s+by\s+`, whereas P6b's `by` is optional.
// So "grew 5%" / "raise it 5%" / "grow revenue 5%" are outside P6 by
// construction, and P9's guard (see rule_P9) explicitly refuses any `N%`
// preceded by a direction verb. Making the lookahead work as intended would
// hand those strings to the compromise backstop, which returns the right
// NUMBER but drops `operator` and `direction` and downgrades `source` to
// 'compromise' — the exact "lower-fidelity substitute re-claims the span"
// failure that extract-quantities.ts §5 exists to prevent. Measured both
// ways; see PR for the table.
//
// CONVENTION (uniform across every rule that emits `unit: 'percentage'`):
// the VALUE is always stored as a FRACTION and `unit` is metadata. The
// consumer depends on this — `mapCqeQuantityToProposalValue` in
// routing/deterministic-value-update.ts multiplies by 100 to recover user
// units ("CQE pre-divides by 100"). `percentage_points` is the deliberate
// exception and stays a raw count; the same consumer passes it through
// unscaled.
const P6B_REGEX = new RegExp(
  `\\b(${DIRECTION_UP_VERB}|${DIRECTION_DOWN_VERB})(?:\\s+[a-z][a-z\\s-]{0,30}?)?\\s+(?:by\\s+)?(?:(?:${APPROX})\\s+)?(?:(${CURRENCY_SYMBOL}))?(${NUM})\\s*(${SUFFIX})?(?:\\s*(${UNIT}))?(?!\\s*%)`,
  'gi',
);

const rule_P6b: PatternRule = {
  id: 'P6b',
  priority: 7,
  apply: (text, ctx) =>
    scanAllExec(text, P6B_REGEX).map((m) => {
      const verb = m[1];
      const currSym = m[2];
      const num = parseNum(m[3]);
      const suffix = m[4];
      const rawUnit = m[5];
      if (!Number.isFinite(num)) return null;
      const direction = directionFromVerb(verb);
      if (direction === 'set') return null;
      let unit = normaliseUnit(rawUnit);
      if (currSym) unit = normaliseCurrencyUnit(currSym);
      let value = applySuffix(num, suffix);
      // Fraction convention, as every sibling that can emit `percentage`
      // does (P1, P2, P3, P6, P7, P7c, P9, P11, P12). P6b was the only
      // rule emitting `unit: 'percentage'` with an un-normalised value —
      // a silent 100x that survived into `parsed_quantities` and was
      // deterministically appliable to the user's graph. NOT applied to
      // `percentage_points`, which is a raw count by design.
      if (unit === 'percentage') value = value / 100;
      const isCut = direction === 'down';
      const verbLower = verb.toLowerCase();
      const isAddVerb = /^add/i.test(verbLower);
      const operator: CqeParameterOperator = isAddVerb
        ? 'add'
        : isCut
        ? 'decrement'
        : 'increment';
      const valueOrigin: QuantityExtractionResult['value_origin'] = suffix
        ? 'suffix_expansion'
        : 'literal';
      return emit(
        m,
        text,
        {
          value,
          direction,
          operator,
          unit,
          value_origin: valueOrigin,
        },
        ctx,
      );
    }).filter(isMatch),
};

// ---- P7 set_verb_value -----------------------------------------------------

const P7_REGEX = new RegExp(
  `\\b(${DIRECTION_SET_VERB})\\b(?:\\s+(?:the\\s+)?[a-z][a-z\\s-]{0,40}?)?\\s+to\\s+(?:(?:${APPROX})\\s+)?(?:(${CURRENCY_SYMBOL}))?(${NUM})\\s*(${SUFFIX})?(?:\\s*(${UNIT}))?`,
  'gi',
);

// Continuation pattern: "... and X to N [unit]" where the preceding text is
// mostly whitespace (indicating an earlier P7 match was masked). Treats the
// continuation as an implicit set operation inheriting from the prior verb.
const P7_CONTINUATION_REGEX = new RegExp(
  `\\band\\s+(?:the\\s+)?[a-z][a-z\\s-]{0,30}?\\s+to\\s+(?:(${CURRENCY_SYMBOL}))?(${NUM})\\s*(${SUFFIX})?(?:\\s*(${UNIT}))?`,
  'gi',
);

const rule_P7: PatternRule = {
  id: 'P7',
  priority: 8,
  apply: (text, ctx) =>
    scanAllExec(text, P7_REGEX).map((m) => {
      const currSym = m[2];
      const num = parseNum(m[3]);
      const suffix = m[4];
      const rawUnit = m[5];
      if (!Number.isFinite(num)) return null;
      let unit = normaliseUnit(rawUnit);
      if (currSym) unit = normaliseCurrencyUnit(currSym);
      let value = applySuffix(num, suffix);
      if (unit === 'percentage') value = value / 100;
      const valueOrigin: QuantityExtractionResult['value_origin'] = suffix
        ? 'suffix_expansion'
        : 'literal';
      return emit(
        m,
        text,
        {
          value,
          operator: 'set',
          direction: 'set',
          unit,
          value_origin: valueOrigin,
        },
        ctx,
      );
    }).filter(isMatch),
};

// P7 continuation: "and X to N" after a preceding masked P7 clause.
const rule_P7_continuation: PatternRule = {
  id: 'P7c',
  priority: 8,
  apply: (text, ctx) =>
    scanAllExec(text, P7_CONTINUATION_REGEX).map((m) => {
      const windowStart = Math.max(0, m.index - 40);
      const before = text.slice(windowStart, m.index);
      const whitespaceRun = before.match(/\s{8,}$/);
      if (!whitespaceRun) return null;
      const currSym = m[1];
      const num = parseNum(m[2]);
      const suffix = m[3];
      const rawUnit = m[4];
      if (!Number.isFinite(num)) return null;
      let unit = normaliseUnit(rawUnit);
      if (currSym) unit = normaliseCurrencyUnit(currSym);
      let value = applySuffix(num, suffix);
      if (unit === 'percentage') value = value / 100;
      const valueOrigin: QuantityExtractionResult['value_origin'] = suffix
        ? 'suffix_expansion'
        : 'literal';
      return emit(
        m,
        text,
        {
          value,
          operator: 'set',
          direction: 'set',
          unit,
          value_origin: valueOrigin,
        },
        ctx,
      );
    }).filter(isMatch),
};

// ---- P8 currency -----------------------------------------------------------

// ⛔ A MINUS BEFORE THE SYMBOL IS THE FIGURE'S SIGN (AIQ on CEE #2247, 5871017629). "-£500" read as +500: measured on real
// CQE, "Set the margin to -£500." gave value 500, while "£-500" gave -500. The regex admits it only at a word start; the
// loop below then decides it on the UNMASKED text (`minusIsSign`), so a range's hyphen or a bullet is never a sign.
/**
 * Is the "-" at `at` the sign of the figure after it? Decided on the UNMASKED text (DL CHANGES_REQUIRED on #2247:
 * "£100-£500" read as (100, -500) because the first figure was already masked). Not a sign when a figure stands before
 * it: a range ("£100-£500", "£100 -£500", "10k -£5k"). A bullet never reaches here as "-£": `preNormalise` spaces it
 * off ("- £500") before whitespace is collapsed. Without the unmasked text it is never read as a sign: a write must not
 * invent a negative.
 */
function minusIsSign(unmasked: string | undefined, at: number): boolean {
  if (unmasked === undefined) return false;
  const before = unmasked.slice(0, at);
  return !(/[\d%)]\s*$/.test(before) || /\d\s*(?:k|m|bn|b|thousand|million|billion)\s*$/i.test(before));
}

/** The same match one character later: the leading "-" is not part of the figure. */
function withoutLeadingChar(m: RegExpExecArray): RegExpExecArray {
  // A single cast: `string[]` is a supertype of `RegExpExecArray`. The rejected minus leaves the span and its group.
  const next = m.slice() as RegExpExecArray;
  next[0] = m[0].slice(1);
  next[1] = '';
  next.index = m.index + 1;
  next.input = m.input;
  next.groups = m.groups;
  return next;
}

const P8_SYMBOL_REGEX = new RegExp(
  `(?:(?<=^|[\\s(:=])(-))?(${CURRENCY_SYMBOL})\\s?(${NUM})\\s*(${SUFFIX})?`,
  'gi',
);
const P8_CODE_REGEX = new RegExp(
  `\\b(${CURRENCY_CODE})\\s+(${NUM})\\s*(${SUFFIX})?`,
  'gi',
);
const P8_CODE_SUFFIX_REGEX = new RegExp(
  `(${NUM})\\s*(${SUFFIX})?\\s+(${CURRENCY_CODE})\\b`,
  'gi',
);
const P8_COLLOQUIAL_REGEX = new RegExp(
  `\\b(${NUM})\\s+(${CURRENCY_COLLOQUIAL})\\b`,
  'gi',
);

const rule_P8: PatternRule = {
  id: 'P8',
  priority: 9,
  apply: (text, ctx) => {
    const out: CqePatternMatch[] = [];

    for (const found of scanAllExec(text, P8_SYMBOL_REGEX)) {
      // A minus that is NOT the figure's sign (a range's hyphen, a bullet) is left out of the span, so it stays
      // readable by the range rule and the figure is read unsigned.
      const signed = found[1] === '-' && minusIsSign(ctx.unmaskedText, found.index);
      const m = found[1] === '-' && !signed ? withoutLeadingChar(found) : found;
      const unit = normaliseCurrencyUnit(m[2]);
      const num = parseNum(m[3]);
      const suffix = m[4];
      if (!Number.isFinite(num)) continue;
      // "-£-500" is not a double negative a person writes: the leading sign applies only to an unsigned figure.
      const value = signed && num > 0 ? -applySuffix(num, suffix) : applySuffix(num, suffix);
      out.push(
        emit(
          m,
          text,
          {
            value,
            unit,
            value_origin: suffix ? 'suffix_expansion' : 'literal',
          },
          ctx,
        ),
      );
    }

    for (const m of scanAllExec(text, P8_CODE_REGEX)) {
      const unit = normaliseCurrencyUnit(m[1]);
      const num = parseNum(m[2]);
      const suffix = m[3];
      if (!Number.isFinite(num)) continue;
      const value = applySuffix(num, suffix);
      out.push(
        emit(
          m,
          text,
          {
            value,
            unit,
            value_origin: suffix ? 'suffix_expansion' : 'literal',
          },
          ctx,
        ),
      );
    }

    for (const m of scanAllExec(text, P8_CODE_SUFFIX_REGEX)) {
      const num = parseNum(m[1]);
      const suffix = m[2];
      const unit = normaliseCurrencyUnit(m[3]);
      if (!Number.isFinite(num)) continue;
      const value = applySuffix(num, suffix);
      out.push(
        emit(
          m,
          text,
          {
            value,
            unit,
            value_origin: suffix ? 'suffix_expansion' : 'literal',
          },
          ctx,
        ),
      );
    }

    for (const m of scanAllExec(text, P8_COLLOQUIAL_REGEX)) {
      const num = parseNum(m[1]);
      const colloquial = m[2].toLowerCase();
      if (!Number.isFinite(num)) continue;
      const value = num * (COLLOQUIAL_MAGNITUDE_MULTIPLIERS[colloquial] ?? 1);
      const unit = 'GBP';
      out.push(
        emit(
          m,
          text,
          {
            value,
            unit,
            value_origin: 'suffix_expansion',
          },
          ctx,
        ),
      );
    }

    return out;
  },
};

// ---- P9 bare_percentage ----------------------------------------------------

// The catch-all bare percentage. It admits the spelled-out forms on the same
// terms as the symbol (see `PERCENT_WORD`): this is the rule that owns
// "record 12 percent as the current measured coverage", the exact native
// utterance whose rerun was refused as "a bare amount with no range".
const P9_REGEX = new RegExp(`(${NUM})\\s*(?:%|${PERCENT_WORD})`, 'gi');

const rule_P9: PatternRule = {
  id: 'P9',
  priority: 10,
  apply: (text, ctx) =>
    scanAllExec(text, P9_REGEX).map((m) => {
      const spanStart = m.index;
      const windowStart = Math.max(0, spanStart - 20);
      const before = text.slice(windowStart, spanStart);
      if (new RegExp(`\\b(?:${DIRECTION_VERB})\\b[^%]*$`, 'i').test(before)) {
        return null;
      }
      const num = parseNum(m[1]);
      if (!Number.isFinite(num)) return null;
      return emit(
        m,
        text,
        {
          value: num / 100,
          unit: 'percentage',
          value_origin: 'literal',
        },
        ctx,
      );
    }).filter(isMatch),
};

// ---- P10 vague_quantifier --------------------------------------------------

const VAGUE_QUANTIFIERS: ReadonlyArray<{ phrase: string; value: number | null }> = [
  { phrase: 'a couple of', value: 2 },
  { phrase: 'a couple', value: 2 },
  { phrase: 'a few', value: null },
  { phrase: 'several', value: null },
  { phrase: 'many', value: null },
  { phrase: 'a handful of', value: null },
  { phrase: 'a handful', value: null },
];
const P10_REGEX = new RegExp(
  `\\b(${VAGUE_QUANTIFIERS.map((e) => e.phrase.replace(/\s+/g, '\\s+')).join('|')})\\b(?:\\s+(?:percent|%))?`,
  'gi',
);

const rule_P10: PatternRule = {
  id: 'P10',
  priority: 11,
  apply: (text, ctx) =>
    scanAllExec(text, P10_REGEX).map((m) => {
      const raw = m[0];
      const phraseRaw = m[1].toLowerCase();
      const entry = VAGUE_QUANTIFIERS.find((e) => e.phrase === phraseRaw);
      if (!entry) return null;
      const hasPercent = /\bpercent|%$/i.test(raw);
      return emit(
        m,
        text,
        {
          value: entry.value,
          approximate: true,
          value_origin: 'lexical_quantifier',
          ...(hasPercent ? { unit: 'percentage' } : {}),
        },
        ctx,
      );
    }).filter(isMatch),
};

// ---- P11 from_to (split per Gate 3) ----------------------------------------

// P11 is structurally split into two anchored sub-patterns per brief §6
// Gate 3 and investigation proposal §3.3 (avoid one mega-regex with optional
// per-side unit alternation, which carries high backtracking risk).
//
//   P11_WITH_UNITS:    each side must carry a unit. Top-level alternation
//                      per side: currency-symbol form OR trailing UNIT form.
//                      Mandatory one-of-two, NOT optional. Bounded
//                      backtracking: at most two branches per side.
//                      Covers "from 50 to 70" with implicit currency
//                      symbols, "from 3% to 5%", and "from 5 months to
//                      10 months".
//
//   P11_WITHOUT_UNITS: neither side carries a unit. Numbers plus optional
//                      multiplier suffix only; optional trailing UNIT at
//                      the end applies to both bounds. Covers "from 200k
//                      to 150k" and "from 3 to 5 months".
//
// The apply() function runs both, masks matched spans from the shared
// working text, and merges results in code. Neither regex contains an
// optional per-side UNIT group; SUFFIX (the k/m/bn multiplier marker) is
// allowed optional because it does not define the unit.
//
// Group numbering in P11_WITH_UNITS:
//   Side A currency branch: 1=SYM, 2=NUM, 3=SUFFIX?
//   Side A unit branch:     4=NUM, 5=SUFFIX?, 6=UNIT
//   Side B currency branch: 7=SYM, 8=NUM, 9=SUFFIX?
//   Side B unit branch:     10=NUM, 11=SUFFIX?, 12=UNIT
// Side X matched the currency branch iff group (6X-5) is defined.
const P11_WITH_UNITS_REGEX = new RegExp(
  `\\bfrom\\s+(?:` +
    `(${CURRENCY_SYMBOL})(${NUM})(?:\\s*(${SUFFIX}))?` +
    `|` +
    `(${NUM})(?:\\s*(${SUFFIX}))?\\s*(${UNIT})` +
  `)\\s+to\\s+(?:` +
    `(${CURRENCY_SYMBOL})(${NUM})(?:\\s*(${SUFFIX}))?` +
    `|` +
    `(${NUM})(?:\\s*(${SUFFIX}))?\\s*(${UNIT})` +
  `)`,
  'gi',
);

const P11_WITHOUT_UNITS_REGEX = new RegExp(
  `\\bfrom\\s+(${NUM})(?:\\s*(${SUFFIX}))?\\s+to\\s+(${NUM})(?:\\s*(${SUFFIX}))?(?:\\s*(${UNIT}))?`,
  'gi',
);

interface P11Parsed {
  numA: number;
  numB: number;
  suffixA: string | undefined;
  suffixB: string | undefined;
  unit: string | null;
}

function emitP11(
  m: RegExpExecArray,
  text: string,
  parsed: P11Parsed,
  ctx: RuleContext,
): CqePatternMatch {
  const { numA, numB, suffixA, suffixB, unit } = parsed;
  const valueA = applySuffix(numA, suffixA);
  const valueB = applySuffix(numB, suffixB);
  const isPercentUnit = unit === 'percentage';

  const windowStart = Math.max(0, m.index - 40);
  const before = text.slice(windowStart, m.index);
  const verbMatch = before.match(
    new RegExp(`\\b(${DIRECTION_VERB})\\b(?=[^\\n]*$)`, 'i'),
  );
  const verbDirection = verbMatch ? directionFromVerb(verbMatch[1]) : null;
  const trajectoryDirection: 'up' | 'down' | 'set' =
    valueB > valueA ? 'up' : valueB < valueA ? 'down' : 'set';
  const direction = verbDirection ?? trajectoryDirection;

  const hasSuffix = Boolean(suffixA || suffixB);
  return emit(
    m,
    text,
    {
      value: isPercentUnit ? valueB / 100 : valueB,
      range_min: isPercentUnit ? valueA / 100 : valueA,
      range_max: isPercentUnit ? valueB / 100 : valueB,
      operator: 'set',
      direction,
      unit,
      value_origin: hasSuffix ? 'suffix_expansion' : 'literal',
    },
    ctx,
  );
}

const rule_P11: PatternRule = {
  id: 'P11',
  priority: 12,
  apply: (text, ctx) => {
    const out: CqePatternMatch[] = [];
    const masked = new Set<string>();
    const addMatch = (m: RegExpExecArray, parsed: P11Parsed): void => {
      const span = `${m.index}:${m.index + m[0].length}`;
      if (masked.has(span)) return;
      // Also skip if the current span overlaps any prior span.
      for (const prev of masked) {
        const [ps, pe] = prev.split(':').map(Number) as [number, number];
        if (ps < m.index + m[0].length && pe > m.index) return;
      }
      masked.add(span);
      out.push(emitP11(m, text, parsed, ctx));
    };

    // Sub-pattern 1 (WITH-UNITS): each side carries a unit via one of two
    // branches. Pick the branch that matched based on which capture group
    // is defined; reject mixed currency-vs-unit-suffix pairings by
    // requiring both normalised units to match.
    for (const m of scanAllExec(text, P11_WITH_UNITS_REGEX)) {
      const currA = m[1];
      const numACurr = m[2];
      const suffixACurr = m[3];
      const numAUnit = m[4];
      const suffixAUnit = m[5];
      const unitA = m[6];

      const currB = m[7];
      const numBCurr = m[8];
      const suffixBCurr = m[9];
      const numBUnit = m[10];
      const suffixBUnit = m[11];
      const unitB = m[12];

      const sideANum = parseNum((currA ? numACurr : numAUnit) ?? '');
      const sideASuffix = currA ? suffixACurr : suffixAUnit;
      const sideAUnit = currA
        ? normaliseCurrencyUnit(currA)
        : unitA
          ? normaliseUnit(unitA)
          : null;

      const sideBNum = parseNum((currB ? numBCurr : numBUnit) ?? '');
      const sideBSuffix = currB ? suffixBCurr : suffixBUnit;
      const sideBUnit = currB
        ? normaliseCurrencyUnit(currB)
        : unitB
          ? normaliseUnit(unitB)
          : null;

      if (!Number.isFinite(sideANum) || !Number.isFinite(sideBNum)) continue;
      if (!sideAUnit || !sideBUnit || sideAUnit !== sideBUnit) continue;

      addMatch(m, {
        numA: sideANum,
        numB: sideBNum,
        suffixA: sideASuffix,
        suffixB: sideBSuffix,
        unit: sideAUnit,
      });
    }

    // Sub-pattern 2 (WITHOUT-UNITS): no per-side unit on either side;
    // optional trailing unit applies to both.
    for (const m of scanAllExec(text, P11_WITHOUT_UNITS_REGEX)) {
      const numA = parseNum(m[1] ?? '');
      const suffixA = m[2];
      const numB = parseNum(m[3] ?? '');
      const suffixB = m[4];
      const trailingUnit = m[5];
      if (!Number.isFinite(numA) || !Number.isFinite(numB)) continue;
      const unit = trailingUnit ? normaliseUnit(trailingUnit) : null;
      addMatch(m, { numA, numB, suffixA, suffixB, unit });
    }

    return out;
  },
};

// ---- P12 to_value ----------------------------------------------------------

const P12_REGEX = new RegExp(
  `\\b(${DIRECTION_UP_VERB}|${DIRECTION_DOWN_VERB}|${DIRECTION_SET_VERB})(?:\\s+(?:it|them|[a-z][a-z\\s-]{0,30}?))?\\s+(?:down\\s+)?to\\s+(?:(?:${APPROX})\\s+)?(?:(${CURRENCY_SYMBOL}))?(${NUM})\\s*(${SUFFIX})?(?:\\s*(${UNIT}))?`,
  'gi',
);

const rule_P12: PatternRule = {
  id: 'P12',
  priority: 13,
  apply: (text, ctx) =>
    scanAllExec(text, P12_REGEX).map((m) => {
      const verb = m[1];
      const currSym = m[2];
      const num = parseNum(m[3]);
      const suffix = m[4];
      const rawUnit = m[5];
      if (!Number.isFinite(num)) return null;
      const direction = directionFromVerb(verb);
      let unit = normaliseUnit(rawUnit);
      if (currSym) unit = normaliseCurrencyUnit(currSym);
      let value = applySuffix(num, suffix);
      if (unit === 'percentage') value = value / 100;
      const hasSuffix = Boolean(suffix);
      return emit(
        m,
        text,
        {
          value,
          operator: 'set',
          direction,
          unit,
          value_origin: hasSuffix ? 'suffix_expansion' : 'literal',
        },
        ctx,
      );
    }).filter(isMatch),
};

// ---- P13 percentage_points -------------------------------------------------

const P13_REGEX = new RegExp(
  `\\b(?:(${DIRECTION_UP_VERB}|${DIRECTION_DOWN_VERB})\\s+by\\s+)?(${NUM})\\s*(?:pp|percentage\\s+points?)\\b`,
  'gi',
);

const rule_P13: PatternRule = {
  id: 'P13',
  priority: 14,
  apply: (text, ctx) =>
    scanAllExec(text, P13_REGEX).map((m) => {
      const verb = m[1];
      const num = parseNum(m[2]);
      if (!Number.isFinite(num)) return null;
      const direction = verb ? directionFromVerb(verb) : null;
      const operator: CqeParameterOperator | null = verb
        ? direction === 'up'
          ? 'increment'
          : direction === 'down'
          ? 'decrement'
          : null
        : null;
      return emit(
        m,
        text,
        {
          value: num,
          unit: 'percentage_points',
          direction: direction === 'set' ? null : direction,
          operator,
          value_origin: 'literal',
        },
        ctx,
      );
    }).filter(isMatch),
};

// ---- rule ordering ---------------------------------------------------------

// Execution order prioritises most-specific rules first so masking claims
// territory before less-specific rules run. This differs from the priority
// numbers in CQE Design v1.1 §4.2 (which describe decision precedence for
// overlapping surface forms). Both produce the same deterministic outcome;
// execution order is chosen to minimise false matches from the catch-all
// rules (P2, P9) after specific ones have consumed their text.
export const PATTERN_RULES: readonly PatternRule[] = Object.freeze([
  rule_P13, // "N pp" / "N percentage points" (most specific suffix)
  rule_P11, // "from X to Y" (requires leading `from`)
  rule_P12, // "(verb) to N" (requires directional verb)
  rule_P1, // "between X and Y"
  rule_P5, // word fractions with directional verb
  rule_P7, // "set X to N"
  rule_P7_continuation, // "...and X to N" after masked P7 clause
  rule_P6, // "(verb) by N%"
  rule_P3, // "at least/most N". Must precede P8 so "under £50k" gets at_most
  rule_P6b, // "(verb) by N [unit]" (no %)
  rule_P8, // currency (£/$/€/GBP/USD/EUR/grand/quid)
  rule_P4, // double/triple/halve
  rule_P2, // generic "X-Y" / "X to Y" range
  rule_P10, // vague quantifiers
  rule_P9, // bare N% (catch-all)
]);
