When a served Run contains a valid factor crossing, the Agent receives one typed tipping-point fact with the original factor identity, display values, direction and unit. The existing positive remains Pro plan price 49 → 55.76 GBP/month, with neutral wording and no winner or EVPPI dependency.

This is PR 1 of Paul's narrowed tipping-point journey. It reuses the existing flip parser and display predicate, selects the first valid row in producer order, and keeps no-signal, unresolved and absent science distinct. The enclosing selected analysis result retains its existing Run hash/identity; no new currentness authority is introduced.

The final diff is only `decision-sensitivity.ts` and `tipping-point-for-agent.test.ts`. The prior prompt/ranking change and nested permission-masking change have been removed. Shared Data retains permission ownership; Context P0 owns the canonical follow-up projection. PR 2 adds deterministic coaching/checker/fallback; a targeted action is conditional on the existing refinement path failing the journey.

Validation at 918f1c7a0504ff7cd94071b7d80cb386359c2f6c:
- 32 focused tests pass, including the real served positive/control, withheld winner, display-safe row selection and unchanged EVPPI semantics.
- `pnpm typecheck` and changed-file lint pass.
- Four mutants killed: wrong factor, wrong threshold, wrong direction, reversed crossings.
- Exact-head Required CI is pending and remains the release gate. The 127-row science validation is inherited; no new broad science run.

No schemas, PLoT, shared keep-list/status transport, VOI actions, winner transport, stability bands or UI changes. VOI is scientifically available; a product-positive case is not currently demonstrated on the served model shape.

HIGH: model-facing interpretation changes. Independent exact-head review and the serial DL/successor merge slot are required. This is source/fixture evidence; it is not yet served or JOURNEY-WITNESSED.
