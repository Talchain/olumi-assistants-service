import { readFileSync } from 'node:fs';
import { defineConfig, mergeConfig } from '/private/tmp/olumi-b3-delta-20261003.62tEvb/cee/node_modules/vitest/dist/config.js';
import baseline from '/private/tmp/olumi-b3-delta-20261003.62tEvb/cee/vitest.config.ts';
// Verification-only overlay: original module identity/import paths, without editing DL's shared file.
export default mergeConfig(baseline, defineConfig({
  plugins: [{ name: 'banked-DL-carrier-verification', enforce: 'pre', load(id) {
    if (id.split('?')[0] === '/private/tmp/olumi-b3-delta-20261003.62tEvb/cee/src/orchestrator-v5/agent-lane/saved-run-context-facts.ts') return readFileSync('/Users/paulslee/Documents/GitHub/output/olumi-runtime-l1-20261003/selected-run-delta-20261004/mutant-stale-context.ts', 'utf8');
    if (id.split('?')[0] === '/private/tmp/olumi-b3-delta-20261003.62tEvb/cee/src/orchestrator-v5/agent-lane/runtime/agent-capabilities.ts') {
      return readFileSync('/Users/paulslee/Documents/GitHub/output/olumi-runtime-l1-20261003/selected-run-delta-20261004/agent-capabilities.verify-source.ts', 'utf8');
    }
  } }],
}));
