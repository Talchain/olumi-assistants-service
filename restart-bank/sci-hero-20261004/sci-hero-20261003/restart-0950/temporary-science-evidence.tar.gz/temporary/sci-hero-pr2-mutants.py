from pathlib import Path
import subprocess,json
root=Path('/private/tmp/scihero-cee-1790984347')
leaf='src/orchestrator-v5/agent-lane/tipping-point-coaching.ts'
route='src/routes/agent-v1-turn.ts'
leaf_test='src/orchestrator-v5/agent-lane/__tests__/tipping-point-coaching.test.ts'
route_test='src/orchestrator-v5/agent-lane/__tests__/tipping-point-coaching.route.test.ts'
mutants=[
 ('unchecked_elaboration',leaf,'reply: checked.pass ? draft : plan.reply','reply: draft',leaf_test),
 ('stale_consumer',leaf,'if (bound === null) return','if (false) return',leaf_test),
 ('cached_final_read',route,"fastPath === 'explain' || tippingTurn !== null","fastPath === 'explain'",route_test),
 ('reuse_competing_run',route,"if (tippingTurn?.kind === 'found' && !runExplanationMatches(tippingTurn.run_key, scenarioId, finalRead))","if (false)",route_test),
 ('replay_stored_threshold',route,"if (approvedProposal === undefined && explanationId === TIPPING_POINT_PRESS_ID)","if (false)",route_test),
]
results=[]
for name,path,old,new,test in mutants:
 file=root/path; original=file.read_text()
 if original.count(old)!=1: raise RuntimeError(name+' has no unique mutation site')
 log=Path('/private/tmp/sci-hero-pr2-mutant-'+name+'.log')
 try:
  file.write_text(original.replace(old,new))
  with log.open('w') as out:
   p=subprocess.run(['pnpm','exec','vitest','run',test,'--maxWorkers=1','--no-file-parallelism','--testTimeout=20000'],cwd=root,stdout=out,stderr=subprocess.STDOUT)
  body=log.read_text(); killed=p.returncode!=0 and 'AssertionError' in body
  results.append({'mutant':name,'killed':killed,'exit_code':p.returncode,'log':str(log)})
  print(name, 'KILLED' if killed else 'SURVIVED OR INCONCLUSIVE',flush=True)
 finally: file.write_text(original)
Path('/private/tmp/sci-hero-pr2-mutants.json').write_text(json.dumps(results,indent=2))
if not all(r['killed'] for r in results): raise SystemExit(1)
