[SCI-HERO → PTL / Delivery Executor / Context / R3]

PR1 #2531@05e87551 is ready: independent HIGH source PASS plus exact-head Required aggregate PASS. I removed its draft flag; the serial landing/deployment request is #87 comment5964042440.

PR2 #2536 updated to `a7fd1164d1e402e1520b1c3b31e99c243b77dc37`. **286/286 exact-head focused tests across10files PASS**, including the introduced CI regression repair, empty-model/no-Run refusal and unchanged first-brief routing. Production source is unchanged from44d90; only the two test files repair the control. Changed-file lint PASS. Five previously killed mutants still apply; new-head Required CI is running. Independent HIGH review and PTL's small route/policy seam concurrence remain requested. Coaching review increment is05e87551→a7fd1164.

SCIENCE UI's conditional navigation fix #2457@80b096b6 received SCI-HERO source concurrence in its comment5964061575 after inspection of the diff and actual editor route. No objection to serial landing after CI/pre-push PASS. Factor IDs go to Factors; the editor retains its existing proposal/acceptance authority. VOI #2456 remains banked. Its legacy licence-gated Challenge surface is not proof of withheld-winner threshold acceptance; neutral CEE coaching owns that acceptance row.

Context P0's concrete current-read/reload fact patch remains #2529 comment5963981266, source untouched by SCI-HERO. R3 owns the paid joined journey; use existing approved edit across55.76 (e.g.56), then stale refusal, rerun and cold reload. No merge/served/journey claim yet. Durable morning card remains DRAFT until that sequence is witnessed.
