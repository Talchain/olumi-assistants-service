# Olumi OpenAI Technical Architecture
## Canonical SSOT v2.0

**Date:** 24 September 2026  
**Status:** Consolidated canonical plan of record, not a release certificate  
**Scope:** OpenAI PoC and near-term AI experience architecture  
**Owners:** Paul and the OpenAI Architecture Owner  
**Implementation:** OpenAI Technical Architecture / Claude Code, with OpenAI Connected owning the live integration seam  
**Assurance:** Independent Review / Codex  
**Coordination:** `Talchain/olumi-programme-docs#63`  
**Canonical repository file:** `openai/architecture/Olumi_OpenAI_Technical_Architecture_SSOT_v2_0.md`

## Executive summary

Build **one reasoning system over one authoritative Living Model**, not a collection of agents. Preserve deterministic control of state, authorisation, computation and receipts. Use focused AI capability profiles to understand, explain, challenge and contextualise. [S1]

The immediate product outcome is a connected experience: **analyse → explain → expose uncertainty → optionally challenge or investigate → authorise an edit → rerun → understand what changed → reload coherently**. This is an acceptance journey, not a compulsory exercise or a requirement to finish every capability before releasing a useful increment. [S1, S2]

The next capability increment is the **Analysis Interpreter on the existing final-response call**, followed by honest before/after explanation and a validated disconfirmation journey. Shared actions, context, consent and persistence remain with their existing owners. Candidate 1 remains under Release Control. [S1, S2, S6]

**Evidence boundary:** Interpreter v0.2 is an implementation candidate supported by a small response-only benchmark. It is not established as a deployed product improvement. The legacy analysis-review skip and reload-attestation fixes are merged; a packaging PR is not a mounted capability. Appendix A records the checked evidence and its limits. [S3, S4, S5, S7]

### What v2.0 consolidates

- The v1.0 architecture and its repository revision 1.1, including lifecycle-complete capability contracts, research isolation, disconfirmation-first delivery and bounded call budgets.
- The actual Interpreter v0.2 profile and matched-screen evidence, without relabelling its unspecified reasoning effort as medium or claiming proven speed or cost gains.
- The later explicit-action design: deterministic approval without a surprise Run; direct Run followed by one answer-only interpretation call; no action-enabled recovery after interpretation failure.
- Current ownership, reachability-first implementation and the distinction between source, tests, merge, deployment and browser acceptance. [S1–S7, S11]

## 1. Authority and change control

This document supersedes the OpenAI Technical Architecture SSOT v1.0 **including revision 1.1**, the Multi-Prompt and Capability Architecture v0.1, and conflicting OpenAI routing or prompt-topology proposals. The earlier v1.0 filename contained revision 1.1; it was not evidence that those amendments were absent. [S1]

It does not supersede canonical graph/state contracts, the Boundary Contract, the Decision Model Schema, platform ownership, the PoC Quality Contract or validated scientific protocols. Those remain authoritative at their boundaries. [S1]

The governing principle is unchanged:

> LLMs handle language, interpretation, synthesis and contextual reasoning. Deterministic systems own truth, state, computation, authority and execution.

**Architecture, implementation and release are distinct authorities.** This document defines the architecture. Current source and test evidence establish implementation. Release Control owns candidate scope, integration order, serving configuration, acceptance and promotion. A later release instruction may narrow the next candidate without silently rewriting the architecture. [S1, S6]

Maintain one canonical architecture. Supporting prompts, fixtures, implementation handoffs and benchmark reports are versioned assets, not competing architecture documents. Changes require a concrete user-value, quality, latency, reliability, implementation-speed, cost or simplicity reason, together with evidence or an explicitly labelled hypothesis.

This consolidation does not restart stopped workstreams, authorise paid experiments, change provider configuration or grant deployment permission.

## 2. Product objective

Olumi is a reasoning-enhancement system, not an answer engine. Its job is to improve understanding, make reasoning visible, identify what matters or is weak, inspect evidence and disagreement, support useful reasoning methods, and accelerate well-founded committed action. [S1]

Humans own conclusions, judgements, commitments, decisions and actions. Olumi may understand, structure, explain, challenge, research, calculate, model and propose. It must not silently alter canonical state, invent user facts, turn AI assumptions into measured evidence, reinterpret explicit approval or present a model-relative result as an objective answer.

Every response should advance the user's actual task. Answer direct questions first. Avoid repetitive coaching, unnecessary mini-reports and decorative suggestions. A blocker must explain what is blocked, why, and the smallest supported next step. [S9]

## 3. Core architecture and runtime topology

Use a controller-first system with a short shared prompt kernel and six focused capability families:

1. Core Reasoning Coach.
2. Living Model Constructor.
3. Analysis Interpreter.
4. Evidence and Research.
5. Reasoning Method Contextualiser.
6. Challenge and Ideation.

An optional selective critic is outside the default response path. Six families do not imply six agents or six serial calls. [S1]

```text
Authenticated user / UI action
  → existing deterministic action gate
  → canonical context and capability eligibility
  → direct capability for explicit intent,
    or Core Coach for ambiguous conversation
  → existing tools / deterministic computation as needed
  → one final responding capability where possible
  → existing validation and deterministic UI rendering
```

Mutation is a branch of this flow, not an automatic step after reasoning. A read-only answer, research result or method exercise does not require or authorise a canonical write.

The existing Responses-based integration remains the implementation starting point. Do not introduce a new agent framework or transport as a prerequisite. Function-tool continuation may require further model requests; the one-response target is not a claim that every tool-using turn can complete in one API request. [S8, S13]

## 4. Deterministic action gate and fast paths

Known UI intent should not be sent through an LLM merely to rediscover the action. Reuse the existing typed action and mutation paths. Free-text requests remain conversational unless an existing, validated deterministic route applies. Do not introduce a broad word-matching approval shortcut. [S1, S6, S11]

| Explicit action | Required behaviour | Model-call rule |
|---|---|---|
| Approve an identified proposal | Authorise that exact proposal through existing server controls | Zero where possible; no implicit Run |
| Apply an explicit edit | Validate and mutate through the canonical path | No LLM intent reclassification |
| Retry an action | Recover the same operation and its receipt | No regenerated mutation |
| Run analysis | Execute the existing analysis capability, then explain its result | One answer-only interpretation call on the direct Run path |
| Construct from a supported fresh-brief action | Invoke the existing constructor directly | No extra routing call merely to select construction |
| Select a method | Apply the existing method gate, then contextualise if eligible | No new method authority |
| Research or read a document | Route to the permitted evidence capability | Read-only evidence, not a model write |

### Exact authority and recovery

An approval action carries the proposal identity and typed target. The server binds authenticated user, scenario, proposal, payload and applicable state preconditions. The model does not supply authority.

A missing or mismatched selected proposal must not fall through to a general Agent that might select another action. It must produce a truthful refusal or supported recovery, with no write and no surprise analysis. Replay identity must bind the typed target as well as the request. [S6]

A retry of the same authorised operation recovers its historical outcome without another mutation. A different stale operation must not reuse that authority. The historical receipt and the current reread answer different questions: what happened then, and what is true now. [S8]

Initial construction must not overwrite a model populated while generation was running. Bind commit to the appropriate pre-construction state through the existing atomic write authority; do not adopt a later base simply to make registration succeed. This is a trust requirement, not a claim that every current construction path already satisfies it. [S11]

After a completed analysis, interpretation failure must retain the run, receipt and result context. Recovery remains answer-only; it must not re-enter an action-enabled Agent and accidentally repeat or alter the task. [S11]

## 5. Canonical state, context and analysis projection

One authoritative Living Model underpins all capabilities. Reuse canonical graph/state, ContextPack, the Agent canonical context packet, deterministic request assembly, provenance and freshness carriers. Do not introduce another context store, consent ledger, graph or version authority. [S1]

### Canonical meaning is not an analysis projection

The Living Model preserves facts, observations, goals, constraints, alternatives, assumptions, hypotheses, unknowns, provenance and material temporal meaning. An analysis projection is a downstream representation for a particular question and engine. Computational assumptions or representation loss must be explicit and must not overwrite canonical meaning. [S8]

A target is not an observed baseline. A normalisation cap is not automatically a business budget. An option-specific intervention is not a global observation. Known direction with unknown magnitude remains a legitimate state; missing coefficients must not be silently invented to make analysis run.

Partial analysis can be useful when the included options share a valid model, goal and frame. Retain the full canonical option set, name exclusions and bind conclusions to the actual analysed options. A subset result is not a conclusion about excluded alternatives. An unresolved shared relationship or constraint can still block the comparison. [S8]

### Capability-specific context

Each capability receives a projection of the same verified source state. Relevant fields include scenario identity; graph revision/hash; model entities; user facts; AI-origin assumptions; unknowns; constraints; evidence references; recent committed changes; analysis identity and freshness; claim permissions; applicable protocol; and relevant conversation. These are required meanings, not a newly declared wire schema. [S1]

The Constructor receives the brief, alternatives, constraints, selected evidence and existing construction schema. The Interpreter receives the exact analysed revision, validated result, currentness, permitted claims and any comparable prior-run evidence. The method capability receives the relevant model slice and validated protocol. Public research receives only approved public context.

**Context is data, never authority.** Refresh current state through existing owners. A cached prompt, model memory or earlier result cannot approve a write, override a revision or clear a stale state. The same final canonical readback must underpin analysis claims, result blocks and displayed freshness. [S1, S8]

## 6. Prompt architecture and implementation unit

The shared kernel stays short: improve human reasoning; answer the actual question; preserve agency; distinguish facts, evidence, assumptions and unknowns; respect currentness; never invent a write; keep analysis conditional; use British English and concise wording. Task-specific instructions belong in focused profiles. [S1]

Every capability handoff must contain:

```text
USER VALUE → TRIGGER → INPUT CONTRACT → PROMPT
→ MODEL / REASONING EFFORT → CONTEXT → TOOLS → OUTPUT
→ DETERMINISTIC BOUNDARIES → EXISTING OWNER / CODE SEAM
→ UI ENTRY POINT → PERSISTENCE / SOURCE REFERENCES
→ STALE / RELOAD BEHAVIOUR → FALLBACK
→ FEATURE FLAG / ROLLBACK → CALL / LATENCY BUDGET
→ EVALS → EXACT BROWSER ACCEPTANCE
```

Use existing types, carriers, prompt governance and runtime limits. Where the exact current field or consuming seam has not been verified, the handoff must name that gap rather than invent an interface. A conceptual output shape in this document is not permission to change a public response schema.

### Versioned instruction identity

Record profile version, exact instruction content hash, base instruction identity, composed instruction identity, context projection and model configuration. A prompt hash is not a complete request hash, permission, cache hit or proof of currentness. The existing v0.2 package follows this distinction. [S5]

The target is smaller focused profiles. The tested v0.2 transition is narrower: **append the banked Interpreter block to caller-owned Agent instructions on the final analysis-response call**. Preserve that composition for the first integration comparison. Removing the base or converting to a standalone prompt is a separate change requiring evaluation. [S3–S5]

Keep stable instructions and tool definitions early and variable state later. Tool eligibility is primarily a security and capability restriction, not a reason to enlarge the callable surface for caching. Cache optimisation is not a release prerequisite. [S1]

## 7. Capability 1: Core Reasoning Coach

**User value:** understand messy strategic input and keep useful reasoning moving. **Triggers:** ordinary conversation, framing, clarification and ambiguous capability needs. **Inputs:** verified model summary, uncertainties, relevant conversation, provenance and current stage. [S1]

Answer first, then offer one important observation, why it matters and a useful next move when warranted. Do not force a next step when the answer is sufficient. Avoid inventing business activity, missing dimensions or a rationale for an arbitrary prior suggestion.

Use only currently eligible tools. The Coach may propose a change or method, but deterministic systems authorise actions and validate method eligibility. It must not duplicate the full instructions for construction, analysis, research, matrices or science exercises.

**Model:** Terra initially; low/medium is the design starting range, not a universal measured optimum. **Fallback:** a useful grounded answer, specific clarification or supported recovery. **Evals:** directness, relevance, grounding, concision, correct routing, non-repetition and progress for an uncertain user. [S1, S10]

## 8. Capability 2: Living Model Constructor

**User value:** turn a messy brief into a compact provisional model the user can inspect and improve. **Inputs:** the user's brief, named alternatives, constraints, quantities/units, selected evidence and existing schema. **Output:** the current constructor/admission contract, not a new canonical graph shape. [S1, S8]

Target one high-quality structured generation, followed by deterministic validation and targeted repair only for a concrete identified defect. Do not routinely add a second generative pass. Preserve user alternatives, intervention targets, strict operators, temporal meaning, unknown direction/magnitude and provenance. Do not merge distinct concepts solely because their labels resemble each other.

Compactness must not hide omitted constraints or manufacture connectivity through arbitrary signs or coefficients. Structural validity is necessary but insufficient: evaluate the final admitted model, not raw JSON alone. [S8]

**Model:** Terra medium remains the provisional construction default. The construction evidence is separate from the Interpreter benchmark. Existing samples support the choice but do not establish general semantic fidelity; recorded constraint-retention defects remain relevant at both efforts. [S12]

**Fallback:** the existing bounded repair, clarification or truthful blocked result, preserving the brief. **Escalation:** high effort or Sol only when a demonstrated defect and matched evaluation justify it. **Acceptance:** compact model rendered, intended meanings retained, canonical commit/receipt coherent, and a meaningful changed-input control handled correctly.

## 9. Capability 3: Analysis Interpreter

**User value:** explain what the current model and validated analysis imply, why, what remains unsettled and what is worth examining next. This replaces legacy `decision_review` reasoning on the OpenAI consumed path; it is not another model call beside it. [S1, S4]

### Input and output contract

Use the analysed graph revision, analysis identity, currentness, validated PLoT/ISL output, claim permissions, analysed option set, assumptions/provenance, uncertainty, actual sensitivity/robustness evidence and compatible prior-run changes.

The conceptual answer contains `finding`, `why_it_happens`, `important_drivers`, `uncertainty`, `what_could_change_it`, `not_settled` and `next_reasoning_step`. Only populate what is supported. Material uncertainty must remain visible; a next step is optional. Map this meaning into the existing answer/block contracts rather than adding a result schema by default. [S1, S3]

### Claim boundaries

- State a conditional model finding, not an objectively best option or Olumi recommendation.
- Preserve exact metric subject, scope, unit, polarity and permission. Outcome comparison, sensitivity, robustness and constraint satisfaction are different meanings.
- A point result is not a probability. One edge's switch probability is not aggregate stability; its complement must not be narrated as such.
- An edit was tested only when the analysed inputs include it. Identical-input repetition is repeatability, not new evidence or increased confidence.
- A first-tested assumption that flips an ordering does not establish validation priority, global importance, largest effect or the best investigation.
- Preserve strict operators and subset scope. A stale result may be explained as historical, not as a current ranking.
- Do not invent horizons, counts, business assumptions, thresholds, robustness or an explanation for an unsupported number. [S3]

### Before/after and sensitivity

Use **precomputed supplied deltas**. The Interpreter must not calculate new differences, ratios, annualisations, margins or unit conversions in prose. Deterministic computation remains with the existing analytical owner.

Attribute a delta to one edit only when the supplied comparison is compatible: units, option identities, analysis/projection semantics and relevant engine settings must support that attribution. Otherwise explain the limitation. A zero effect or unchanged option ordering is a valid outcome.

A two-run delta is not automatically sensitivity analysis or a what-would-flip threshold. Display existing supported sensitivity earlier in the experience, but do not imply a new sensitivity computation has happened. [S1, S3]

### Immediate implementation contract

**Profile:** `ANALYSIS_INTERPRETER_PROFILE_v0_2.md`, exact banked instruction block. **Seam:** OpenAI Connected's existing final response after canonical analysis, including the direct Run path. **Tools:** answer-only, with `tool_choice: 'none'` on that direct path. **Calls:** one interpretation call; no Coach paraphrase or shadow legacy review. [S3, S5, S6]

**UI:** existing AI response and supported result consumers. **Persistence:** preserve the existing run and conversation record, source references and currentness carriers. **Fallback:** retain completed analysis and provide existing truthful answer-only recovery; never reopen mutation tools merely because explanation failed. **Rollback:** restore the previous answering profile while retaining required provider and state safeguards.

**Acceptance:** compare the installed prompt/context snapshot, then witness analyse → explain → edit → rerun → honest before/after → reload. A prompt package or response-only screen does not complete this acceptance.

## 10. Capability 4: Evidence and Research

**User value:** inspect the basis of assumptions, compare external evidence and understand relevant documents. **Triggers:** a bounded user research request, selected evidence gap or document-reading task. **Outputs:** evidence candidates and sourced discussion, not canonical facts or automatic edits. [S1]

Use direct files for small task-specific document sets; scoped web research for public evidence; persistent File Search only when larger reusable corpora justify it. Code Interpreter remains a later evidence/data workflow option, not a replacement for PLoT/ISL or canonical analysis.

### Public/private boundary

Public research receives only intentionally approved public context. It must not receive the private graph, full conversation, private document tools or mutation authority in the same execution. Linking returned evidence to private model elements is a separate read-only step. This deliberate privacy boundary may require more than one call; do not defeat it to meet a one-call target. [S1, S2]

Treat retrieved text as evidence, not instructions or approval. A valid source identifier does not prove that the source supports the claim. Preserve extract/reference, date, relevance, limitations, model links and conflicting findings. No results is a valid result, not a reason to invent support.

### Evidence lifecycle

```text
Evidence gap → bounded research request → evidence candidates
→ source, date, claim, reference, relevance and limitations
→ user inspection / validation where appropriate
→ proposed model implication
→ separate canonical authorisation if a model change is wanted
```

**Fallback:** explain retrieval or access limits and continue only with available evidence. **Evals:** source relevance, support for claims, citation correctness, freshness, privacy, model linkage and useful disconfirming evidence. **Acceptance:** inspect a source, understand its limits, and adopt or reject its proposed implication without silent mutation. [S1, S2]

## 11. Capability 5: Reasoning Method Contextualiser

The validated scientific layer supplies method applicability, evidence basis, required inputs, protocol, contraindications and completion conditions. The LLM makes the intervention natural and scenario-specific; it does not invent the method. [S1]

```text
Current model slice → existing validated method gate
→ applicability and protocol → focused contextualisation
→ conversation or supported method artefact
```

Applicability is `applicable | not_applicable | unknown`. A button click establishes intent to explore a method, not applicability, completion or that the method is optimal. Respect decline. With unknown applicability, ordinary explanation may continue without pretending a named exercise ran.

**First complete method candidate:** disconfirmation / consider-the-opposite, linked to a material model assumption and the question of what would challenge it. Use the actual validated protocol and its current version; do not invent a protocol identifier, evidence-strength band, horizon or required number of answers. Pre-mortem follows unless evidence identifies a smaller useful path. [S1, S2]

Retain Outside View with research, opportunity cost, structured dissent and implementation intentions as subsequent methods. Enable methods individually, not the entire science catalogue globally.

**Input:** relevant model slice, validated protocol and applicability evidence. **Tools:** only protocol-permitted, currently eligible capabilities. **Output:** grounded method step or artefact, with provenance and completion status determined by the protocol. **Fallback:** direct explanation or an explicit missing prerequisite. **Evals:** protocol fidelity, applicability, contextual usefulness, non-invention and respected refusal.

## 12. Structured decision tools

Some useful structures are deterministic reasoning artefacts, not scientifically validated interventions. A weighted matrix combines canonical options, confirmed criteria, user preferences, scores and evidence, deterministic calculation and weight sensitivity. [S1]

Missing score means unknown, never zero. Hard constraints must not be traded away by weighted compensation. Surface overlapping criteria and explain scale semantics. Preserve the source of scores and weights; accepted AI suggestions do not become measured evidence. Matrix scores are conditional on inputs and preferences, not scientific proof or an Olumi recommendation.

Also retain unweighted/weighted pros and cons, assumption maps, evidence maps and supported what-would-flip/sensitivity views. Reuse the prototype's useful components where verified, but do not add matrices ahead of the connected Interpreter and before/after loop merely because a calculator exists. [S1, S2]

**Acceptance:** the user can inspect inputs, alter a supported preference, see a deterministic consequence and understand unresolved scores or constraints. A schema-valid table alone is insufficient.

## 13. Capability 6: Challenge and Ideation

**User value:** reveal materially different alternatives, missing perspectives and assumptions worth examining. **Modes:** alternative generation, reframing, devil's advocacy, missing stakeholder, assumption challenge, generic dissent and generic opportunity cost. [S1]

Read-only by default. Link the challenge to the current model, avoid semantic duplicates and distinguish speculative ideas from evidence. The usual output is a small set of useful challenges, not exhaustive brainstorming. Match quantity to the request and available material rather than manufacturing entries.

Generic challenge remains distinct from scientifically named protocols. Consider-the-opposite, structured dissent and opportunity-cost exercises use the Method Contextualiser when invoked as validated methods. Shared infrastructure does not confer scientific authority.

**Model:** Terra medium is the starting policy; Sol requires demonstrated additional value. **Fallback:** a grounded clarification or explain why no useful additional alternative was found. **Acceptance:** a useful alternative or challenge can be inspected and, where the product supports it, proposed for adoption through the normal authority path. Generating an idea is not evidence that add-option is implemented. [S1, S6]

## 14. Optional selective critic

A second model is not part of the default loop. Consider it only for consequential construction/synthesis, difficult evidence conclusions, explicit second-review requests or demonstrated failure classes that simpler checks do not resolve. [S1, S10]

Bind the candidate response, graph revision, analysis revision, evidence set and claim permissions. The critic returns either no material issue or a specific affected claim, issue type, reason and evidence reference. A late result must be checked against those bindings before it is shown.

The critic cannot mutate state, silently rewrite a user-visible response, manufacture probability from model agreement or block routine interactions. Prefer deterministic checks where they can establish the defect without another model call.

Sol remains a candidate, not a default. The earlier three-case screen was primed with known error classes and included a clean contrast. It demonstrated a targeted mechanism, not blind defect discovery or general product benefit. Legacy `decision_review`, graph critique and this optional critic are different capabilities. [S10]

## 15. Tool architecture and provider policy

Retain five tool classes: canonical state; analysis; evidence; validated methods/deterministic structures; and presentation. State, authorisation, receipts and analytical computation remain Olumi-owned. Evidence tools supply candidates. Presentation tools request supported deterministic components, not arbitrary UI. [S1]

Tool eligibility is enforced by the server and can narrow what the current mode allows; a context packet cannot grant new authority. Preserve the current function-call protocol, matching outputs to call identities and retaining required reasoning/continuation items. Do not treat a model's tool request as proof of execution. [S8, S13]

### OpenAI-only means the enabled, reachable candidate

Enforce provider policy on the consumed request path, including reachable generative subcalls. Global model defaults or the presence of an API credential do not prove which provider a user journey used. Keep attribution for allowed and refused attempts; a refused wrong-provider attempt is still a routing defect to fix. [S8]

Do not migrate every legacy adapter or change shared Conventional settings to demonstrate one OpenAI journey. For an optional route, compare the smallest request-scoped implementation against disabling it server-side in OpenAI mode and removing its affordance. UI hiding alone is not route protection. `explain_diff` is an example of this decision, not a prerequisite to port the legacy estate. [S2]

A new deployment is not inherently required by request-scoped isolation. Release Control must still verify actual serving routes, flags, provider assignments and rollback configuration before promotion. No architecture label substitutes for that check.

## 16. Visualisation and cross-surface lifecycle

The LLM may request a supported visualisation by type, question, canonical references, graph/analysis revision and presentation parameters. Olumi renders deterministic components. Do not generate arbitrary React, HTML or a new product surface as the default answer. [S1]

Retained grammar: causal map, option matrix, weighted pros and cons, assumption map, evidence map, sensitivity tornado, what-would-flip, scenario trajectory, pre-mortem structure and decision summary. This is roadmap vocabulary, not a demand to implement every view now.

Prioritise existing AI, Canvas and Reasoning surfaces for Interpreter findings, source links, changed assumptions and before/after consequences. They must agree on values, provenance, analysed options, freshness, blockers and available actions. The main finding stands alone; supporting and audit detail is progressively disclosed. [S9]

A capability is not complete until its visible entry point, persisted record, stale state, reload behaviour, flag and rollback are known. A discarded, refused or merely proposed change must never appear as a saved edit. A result that survives only in memory has not passed reload acceptance.

## 17. Model policy

Start simple and retain Olumi's evaluated configuration rather than introducing model tiers for their own sake. [S1]

| Capability | Starting policy | Evidence qualification |
|---|---|---|
| Construction | Terra medium | Provisional construction default; fidelity remains evaluated separately |
| Core Coach | Terra, initially low/medium design range | Per-task routing must be earned by Olumi tests |
| Interpreter v0.2 integration | Match the benchmarked caller configuration first | The 24-call screen omitted reasoning effort; it was not a medium-versus-low comparison |
| Methods, research and ideation | Terra first | Evaluate the specific task and context |
| Critic or difficult escalation | Sol selectively | Not enabled merely because it is the stronger tier |
| Bounded low-risk tasks | Luna experimental | Lower price alone is insufficient |

Model names in the evidence record identify project configurations. They do not prove access, current pricing, capabilities or a fixed provider default. Record the actual API model identifier/snapshot, reasoning effort including omission, output settings and prompt identity. Recheck compatibility before implementation; do not change models as part of this document update. [S3, S12]

## 18. Latency, budgets and failure recovery

Optimise in this order: remove unnecessary model calls; take deterministic fast paths; focus context and prompts; right-size effort; parallelise independent work; use caching; keep nonessential critic/research off the critical response path. [S1]

Explicit actions target zero model calls where possible. Ordinary reasoning targets one final responding call. Necessary tool/model continuation uses bounded existing hop and deadline limits. The direct Run design executes analysis first and uses one answer-only response; it must not create an extra routing or paraphrase call. [S6]

| Interaction | Existing target, not a proven service level |
|---|---|
| Ordinary coaching | Under 10 seconds p50 |
| Analysis Interpreter | Under 10 seconds p50 |
| Deterministic acknowledgement | Near-immediate |
| Existing analysis plus interpretation | Under 30 seconds target |
| First Living Model | Under 60 seconds target |

Measure end-to-end duration, stage timings, p50 and tail behaviour, sample size, failures, timeouts, provider/tool calls and outliers. A small screen does not establish production p95. Fewer answer tokens do not alone prove lower total cost, especially when input tokens increase. [S1, S4]

Propagate deadlines where practical. A timeout or disconnect is not evidence that no write happened. Preserve durable operation identity, distinguish historical receipt from current state and recover rather than regenerate. Preserve completed analysis through interpretation failure. Do not use an action-enabled fallback to repair an explanation. [S1, S11]

Paid experiments require a named authorised runner, a bounded call/token/time plan and a recorded reservation from an established remaining budget. Do not infer available budget from an older allocation or create another unprotected endpoint to bypass access problems. [S2]

## 19. Observability and evidence identity

Record capability and selection source; scenario/turn identity; profile/base/composed prompt hashes; actual model and effort; context revision/hash; eligible and executed tools; provider attempts; stage latency; input/output/reasoning/cache usage; analysis identity; write receipt; final graph revision; evidence references; method version; and any critic outcome. [S1]

Use existing diagnostics and privacy controls. Logs are not canonical state, and private chain-of-thought is not required. A measurement that is produced but has no reader must not be reported as operational observability.

A release witness binds UI, CEE, relevant PLoT/ISL identities, prompt/profile configuration, schema/config versions, flags, route and test scenario. Source, merged code and public health checks do not establish which complete experience the user received. [S8, S11]

## 20. Evaluation architecture and promotion

Evaluate successful reasoning outcomes rather than which answer sounds better. Retain known failures, richer numeric cases, fresh held-outs, adversarial state cases and complete user journeys. Preserve baselines and record all configuration changes. [S1, S14]

Use deterministic assertions for values, units, references, authority and permissions. Use human or independent/blinded semantic assessment where meaning cannot be reduced to those checks. Test expectations stay outside the responding model's input.

### Required distinctions

A response-only benchmark does not test tool selection, consent, persistence, rendering or reload. An instruction block extracted from current source is a stronger baseline than a manual reconstruction, but is not an on-wire capture of the installed request. A local unit test, mutation test, independently reviewed head, merged commit, deployed service and browser-witnessed capability are different evidence levels. [S4, S5]

Interpreter regression anchors cover: changed outcome without ordering change; null effect; identical-input repetition; state changing during explanation; incomparable frames; strict constraints with an excluded option; local probability/first-flip confusion; and declined method with unknown applicability. Add fresh cases, including a legitimate changed ordering and valid partial comparison. [S4]

Construction evals preserve options, quantities, units, constraints, intervention targets, provenance and causal meaning in the final admitted model. A changed input should produce the appropriate result, which may be unchanged; never optimise a demonstration for compulsory flips.

### Promotion sequence

**Prepared → locally checked → model-screened → independently reviewed → integrated → deployed → browser-witnessed.** These are reporting distinctions, not a second runtime state system.

Promote a profile only when exercised hard trust controls pass, the answer is useful, relevant regressions do not worsen, the changed implementation snapshot is tested and the consumed path is independently reviewed. Broader quality, latency and cost claims need matched repeatable evidence. Do not bundle an unrelated model sweep into promotion.

Interpreter v0.2 has reached **implementation candidate** status in its recorded response-only screen. Appendix A preserves the measurements and limitations; this document does not promote it into the product. [S4]

## 21. Delivery architecture and acceptance

### Track A: immediate testable candidate

Release Control retains the immediate PoC scope and integration decision. Required architectural qualities remain compact faithful construction, truthful authorisation/write/retry, genuine analysis, current final state, provider purity, reachable edits/reruns and coherent reload. [S1]

The later release instruction narrows the immediate staging checkpoint to fresh brief → graph → suggested assumptions → deterministic approval without implicit analysis → explicit Run with one Interpreter call → truthful partial/full result → reload/currentness → provider purity. This checkpoint is not a claim that every broader capability is finished. [S6]

FP2 approval, FP1 direct construction and FP3 Run/interpretation may be prepared and reviewed in parallel while respecting their actual integration dependencies. A source approval does not clear a moved head automatically. Record one exact served tuple for each acceptance run; development need not stop globally, but evidence cannot be attributed to a moving unnamed candidate. Current release cadence remains Release Control's decision. [S6, S11]

### Track B: connected capability acceleration

First acceptance loop:

**Analyse → explain → one material uncertainty → optional challenge/investigation → separately authorised edit → rerun → what changed and what did not → coherent reload.**

Deliver useful increments, not a multi-feature big bang:

1. Integrate and validate the banked Interpreter v0.2 on the actual final-response seam.
2. Add honest before/after explanation and surface existing supported sensitivity.
3. Complete a validated disconfirmation journey.
4. Add scoped public research, direct document reading and read-only evidence-to-model linking.
5. Follow with pre-mortem, generic challenge, structured comparisons and additional views as user value justifies them.
6. Add Outside View with research, implementation intentions, persistent knowledge, advanced data tools or selective critics only with the required evidence and available integration capacity. [S1, S2]

The original prepared prototype screen is not an instruction to rerun obsolete work blindly: v0.2 now has its own recorded screen. Reuse its evidence, verify the implemented request and evaluate the material delta. The exact prototype package must be transferred or located before relying on its source; a receipt or sandbox link from another conversation is not access. [S4, S10]

Shared runtime/state work has one implementing owner at each boundary. Limit contention for shared files and review capacity, not independent prompt, science and evidence work. Track B does not block Candidate 1. A small, reviewed, tested improvement may enter a candidate only through Release Control.

### Product-level completion

The joined witness must show a useful grounded finding; a supported next action; genuine user approval or rejection; the exact persisted change once; correct stale state; a current, properly scoped rerun; honest before/after; and coherent reload/retry. Check a small semantic perturbation separately from pristine and replay fixtures. No unintended writes, false success, invented inputs or hidden provider fallback are acceptable. [S8]

## 22. Explicit non-goals

Do not build an autonomous agent mesh, generic orchestration framework, new context/graph/consent authority, custom RAG platform, prompt per button, mandatory LLM router, arbitrary generated UI, compulsory second-model checking, universal Sol routing or global science-catalogue enablement. Image generation is not core PoC reasoning infrastructure. [S1]

Do not mistake implementing an unreachable adapter for completing a capability. Do not optimise caches, replace hosting, port optional legacy routes or expand a framework ahead of a smaller working connected experience without evidence that it removes the actual blocker. [S2]

## 23. Ownership and execution discipline

**OpenAI Architecture Owner with Paul:** canonical architecture, prompt content, model/effort policy, capability contracts, evals, scientific/evidence boundaries and capability acceptance criteria.

**OpenAI Technical Architecture / Claude Code:** inspect current code, classify requirements as ALREADY EXISTS / REUSE / ADAPT / BUILD / BLOCKER, identify the smallest implementation, challenge with code evidence and implement approved contracts. It does not independently redesign the architecture.

**OpenAI Connected:** sole owner of the live Agent integration seam unless a specific file lease says otherwise; mounts profiles and joins existing runtime capabilities.

**Programme Orchestrator / Release Control:** candidate scope, cross-lane priorities, shared dependencies, integration, serving, acceptance and promotion. Canvas, Panel and shared-state owners retain their surfaces.

**Independent Review / Codex:** falsification, benchmark scrutiny and exact-head assurance. A separately authorised, file-disjoint Codex implementation task is permitted, as demonstrated by the v0.2 package; its author cannot act as its own independent reviewer. This is not another architecture authority. [S1, S5, S6]

Before implementing, trace the user trigger → actual producer → persisted record → consuming UI. Name one writer, reused functions, no-touch files, contract deltas, a positive control, a negative control and the first consequential boundary to challenge. Prepare independent work while a review runs; do not repeatedly reopen settled findings or create coordination-only backlog.

A message posted to #63 is a request, not proof that a terminal received or acted on it. A scheduled task, running terminal and completed provider call are different things. Report actual execution, not background activity inferred from elapsed time. Preserve current artefact pointers and the next executable action for handover. [S2, S11]

## 24. Canonical product test

For every capability ask:

> Does this improve the user's understanding of the scenario, model or reasoning, reveal something material they should examine, and accelerate well-founded committed action, or does it merely generate another answer?

Do not add the latter. Report progress as complete user-visible capability, what is proven, what is being built or tested next, and a genuine blocker or decision. Avoid presenting a list of patches as product improvement. [S1]

## 25. North-star experience

Olumi should feel like **one intelligent reasoning partner**, not a collection of agents:

**Listen → understand → model → notice what is weak → choose useful reasoning → research or challenge where appropriate → make assumptions and evidence visible → analyse → explain what matters → let the user change it → show how the picture changes → support committed action.**

The architectural advantage is authoritative shared reasoning state, validated methods, analytical computation, evidence, specialised AI reasoning and transparent human control. No individual LLM or architecture diagram establishes that advantage; the connected experience must demonstrate it. [S1]

## Appendix A. Evidence and implementation snapshot

**Checked during this consolidation.** These observations are not evergreen release status. Repository metadata takes precedence over older queue summaries for whether a PR has merged. No new provider evaluation, signed-in journey or deployment was performed for this document.

| Item | Supported status | What must not be inferred |
|---|---|---|
| Prior architecture | v1.0 filename contains revision 1.1; blob `f2fccc9f7593fe9cf8d1db546739176f0eb5bc14` | The amendments were not merely unincorporated proposals |
| Capability prototype | Receipt reports 89 local tests and eight detected author-injected faults | Independent review, live integration or general prompt superiority |
| Coaching v0.10 | Known grounding/process failures; not promoted | A completed call is a semantic pass |
| Interpreter v0.2 | 24 response-only calls, 12 per arm; manual review reported no observed hard-rule failure in the 12 candidate cases | General correctness, tool-loop fidelity, deployed benefit or calibrated failure rate |
| Legacy review skip, CEE #1744 | Merged as `55b3ecf25e916dab367542e631633f63e010addd` | A universal 13.8-second end-to-end saving |
| Reload attestation, CEE #1773 | Merged as `f95db6022fe6cabe852b95d6cc103122a0b4d279` | A fresh joined browser witness or closure of every reload defect |
| Interpreter packaging, CEE #1787 | Draft/open at head `3ebe7bf83b225ee9d1286caee094df61d2128a7e`; five focused checks reported | Mounted profile, independent approval or full application CI |
| Direct Run / FP3, CEE #1786 | Open at observed head `ddcba71e89e61e43dd6c586f3f432475368b6a81` | Completed candidate delivery or resolution of every review finding |

Sources: [S1, S4, S5, S7, S10, S11].

### Interpreter matched-screen measurements

| Measure | Current Agent baseline | Baseline plus Interpreter v0.2 |
|---|---:|---:|
| Calls | 12 | 12 |
| Mean response time | 3,387.4 ms | 2,794.4 ms |
| Median response time | 3,273.0 ms | 2,358.5 ms |
| Input tokens | 19,756 | 26,368 |
| Output tokens | 1,427 | 932 |
| Mean answer length | 448.7 characters | 365.3 characters |

Configuration: `gpt-5.6-terra`; reasoning effort **omitted**, matching the source-derived current Agent call; concurrency two; no automatic retries; `store:false`. The baseline was extracted from Agent instructions, not captured as the full installed request. Cases were synthetic, with one sample per case and unsymmetrically controlled automatic caching. Assessment was manual, not blinded or a paid judge. [S4]

The candidate used more input tokens and fewer output tokens. The observed answer-length and semantic findings support integration as a candidate. They do not establish a causal latency reduction, total cost saving, production p95 or user-comprehension improvement.

## Appendix B. First integration handoff

**Outcome:** a concise, faithful explanation of the actual current analysis, with no additional model call or new state authority.

**Consume:** the exact banked v0.2 profile; the current caller-owned Agent instructions; the existing canonical analysis/context projection; the current eight-case Interpreter/delta regression pack; and fresh held-out cases. The source package is optional if the same approved profile can be mounted safely without waiting for it. [S3–S6]

**Implementing seam:** OpenAI Connected's final analysis-answer request. Preserve answer-only tool policy and current state/receipt handling. Packaging remains file-disjoint from the live route. Profile/base/composed hashes go into existing diagnostics, not a new permission mechanism.

**Review:** bind the exact head, actual instruction composition, real input projection and output consumers. Exercise current, stale, partial, absent sensitivity, no-change, incompatible-frame and interpretation-failure controls. Respect current branch dependencies and required checks.

**Witness:** explicit Run → finding and limits → authorised edit → rerun → supported delta or no effect → reload. Verify source references, analysed option scope and provider policy on the same named served tuple.

**Still required before a product claim:** exact mounted prompt/config identity, independent consumed-path review, applicable CI, actual deployment and the joined browser witness. This document alone closes none of those gates.

## Appendix C. Version and source record

**v1.0:** original canonical architecture, 23 September 2026.  
**Revision 1.1:** connected-experience delivery amendments in the same repository file, 23 September 2026.  
**v2.0:** consolidated architecture, evidence qualifications and later approved fast-path/ownership refinements, 24 September 2026.

Primary internal sources are listed below. They support the architecture and dated observations, not independent proof of user benefit. Existing source documents that describe older designs remain historical where superseded. Public API references support protocol/evaluation mechanics only; they do not change Olumi's model policy or prove capability efficacy.

### S1. Canonical architecture, revision 1.1

`openai/architecture/Olumi_OpenAI_Technical_Architecture_SSOT_v1_0.md`, observed blob `f2fccc9f7593fe9cf8d1db546739176f0eb5bc14`.

https://github.com/Talchain/olumi-programme-docs/blob/4961b2d174e32baaef0bf0aad8443e08ec74e563/openai/architecture/Olumi_OpenAI_Technical_Architecture_SSOT_v1_0.md

### S2. Agreed acceleration amendments and consumed-path correction

Issue #63 comments `5800797619` and `5800844451`.

https://github.com/Talchain/olumi-programme-docs/issues/63#issuecomment-5800797619

https://github.com/Talchain/olumi-programme-docs/issues/63#issuecomment-5800844451

### S3. Banked Interpreter profile v0.2

`openai/capability-v01/ANALYSIS_INTERPRETER_PROFILE_v0_2.md`, blob `344896ef92177b7308c1d632699bd98bae10c6b7`.

https://github.com/Talchain/olumi-programme-docs/blob/4961b2d174e32baaef0bf0aad8443e08ec74e563/openai/capability-v01/ANALYSIS_INTERPRETER_PROFILE_v0_2.md

### S4. Matched Interpreter screen

`openai/prompt-bench/2026-09-23-interpreter-v02/RESULTS.md`, blob `122671765ed1c63629f983eced546c77facbaf50`. Source Agent blob `814c2ce5d50cc53b928a654223a481289e057b8d`; regression blob `18c5bcf8ed56ca4efd119822fa997fc6102e5865`; fresh-case blob `84a3c413906d29f9c3252e0994735fc9b8f69951`.

https://github.com/Talchain/olumi-programme-docs/blob/4961b2d174e32baaef0bf0aad8443e08ec74e563/openai/prompt-bench/2026-09-23-interpreter-v02/RESULTS.md

### S5. Interpreter packaging PR

CEE #1787, observed head `3ebe7bf83b225ee9d1286caee094df61d2128a7e`; draft, unmerged at read.

https://github.com/Talchain/olumi-assistants-service/pull/1787

### S6. Later release-control fast-path and ownership instruction

Issue #63 comment `5804751968`, 23 September 2026 at 23:38 UTC. Its sprint deadline is historical, not a renewed deadline created by this document.

https://github.com/Talchain/olumi-programme-docs/issues/63#issuecomment-5804751968

### S7. Merged legacy-review and reload-attestation changes

CEE #1744 and #1773, merge identities recorded in Appendix A. The 13.8-second legacy-call observation belongs to the earlier served baseline in #1744.

https://github.com/Talchain/olumi-assistants-service/pull/1744

https://github.com/Talchain/olumi-assistants-service/pull/1773

### S8. Retained state/projection and provider-boundary contracts

Earlier OpenAI architecture and request-scoped provider-policy PR #1749. Architectural principles are retained; old task queues and serving snapshots are not current status.

https://github.com/Talchain/olumi-programme-docs/blob/4961b2d174e32baaef0bf0aad8443e08ec74e563/openai/OPENAI_AI_ARCHITECTURE_SSOT.md

https://github.com/Talchain/olumi-assistants-service/pull/1749

### S9. PoC Quality Contract

Project file `olumi-poc-quality-contract.md`, especially response quality, blocked states, post-analysis and cross-surface requirements. The document is a product constraint, not an implementation-status report.

### S10. Prototype receipt and earlier coaching/critic screen

https://github.com/Talchain/olumi-programme-docs/blob/4961b2d174e32baaef0bf0aad8443e08ec74e563/openai/capability-v01/IMPLEMENTATION-20260923.md

https://github.com/Talchain/olumi-programme-docs/blob/4961b2d174e32baaef0bf0aad8443e08ec74e563/openai/prompt-bench/2026-09-23-coach-v010/RESULTS.md

### S11. Fast-path implementation and independent review observations

CEE #1786 and issue #63's reviewed queue comment `5796618385`, updated 23 September 2026 at 23:43 UTC. Later direct PR metadata supersedes its older #1773 open-state entry.

https://github.com/Talchain/olumi-assistants-service/pull/1786

https://github.com/Talchain/olumi-programme-docs/issues/63#issuecomment-5796618385

### S12. Construction effort evidence

CEE #1761: provisional medium-effort default and bounded fidelity comparison; constraint-retention limitations were disclosed.

https://github.com/Talchain/olumi-assistants-service/pull/1761

### S13. Official OpenAI function-calling guide

Checked for tool-output identity and continuation mechanics, not to introduce a new runtime.

https://developers.openai.com/api/docs/guides/function-calling

### S14. Official OpenAI evaluation guidance

Checked for variability, held-out/edge-case coverage and production-relevant evaluation principles. No dependency on a new hosted evaluation platform is introduced.

https://developers.openai.com/api/docs/guides/evaluation-best-practices
